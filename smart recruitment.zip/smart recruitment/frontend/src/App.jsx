import React, { useState } from 'react';
import { useAuth } from './context/AuthContext';
import { Navbar } from './components/common/Navbar';
import { Sidebar } from './components/common/Sidebar';
import { TopHeader } from './components/common/TopHeader';
import { JobFormModal } from './components/jobs/JobFormModal';

// Pages
import { LandingPage } from './pages/LandingPage';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { BrowseJobsPage } from './pages/candidate/BrowseJobsPage';

// Recruiter Pages
import { RecruiterDashboard } from './pages/recruiter/RecruiterDashboard';
import { JobsManagementPage } from './pages/recruiter/JobsManagementPage';
import { CandidateRankingPage } from './pages/recruiter/CandidateRankingPage';
import { ApplicationsPage } from './pages/recruiter/ApplicationsPage';
import { CandidatesPoolPage } from './pages/recruiter/CandidatesPoolPage';
import { InterviewsPage } from './pages/recruiter/InterviewsPage';
import { AnalyticsPage } from './pages/recruiter/AnalyticsPage';

// Candidate Pages
import { CandidateDashboard } from './pages/candidate/CandidateDashboard';
import { MyApplicationsPage } from './pages/candidate/MyApplicationsPage';
import { CandidateInterviewsPage } from './pages/candidate/CandidateInterviewsPage';
import { CandidateResumePage } from './pages/candidate/CandidateResumePage';
import { CandidateProfilePage } from './pages/candidate/CandidateProfilePage';

// Admin Pages
import { AdminDashboard } from './pages/admin/AdminDashboard';

export const App = () => {
  const { user, isAuthenticated, role } = useAuth();
  const [currentView, setCurrentView] = useState('home');
  const [isJobModalOpen, setIsJobModalOpen] = useState(false);
  const [selectedJobIdForRanking, setSelectedJobIdForRanking] = useState(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // If user logs in or switches, default to their dashboard if on login/register/home
  React.useEffect(() => {
    if (isAuthenticated) {
      if (currentView === 'login' || currentView === 'register') {
        if (role === 'RECRUITER') setCurrentView('recruiter-dashboard');
        else if (role === 'ADMIN') setCurrentView('admin-dashboard');
        else setCurrentView('candidate-dashboard');
      }
    } else {
      if (currentView.startsWith('recruiter-') || currentView.startsWith('candidate-') || currentView.startsWith('admin-')) {
        setCurrentView('home');
      }
    }
  }, [isAuthenticated, role]);

  const handleNavigate = (view) => {
    setCurrentView(view);
    setMobileMenuOpen(false);
    window.scrollTo(0, 0);
  };

  const handleNavigateToRanking = (jobId) => {
    setSelectedJobIdForRanking(jobId);
    setCurrentView('recruiter-screening');
  };

  // Determine if in a Dashboard view or Public Marketing view
  const isDashboard = isAuthenticated && (
    currentView.startsWith('recruiter-') ||
    currentView.startsWith('candidate-') ||
    currentView.startsWith('admin-')
  );

  const getPageTitle = () => {
    switch (currentView) {
      case 'recruiter-dashboard': return 'Recruiter Overview';
      case 'recruiter-jobs': return 'Job Openings';
      case 'recruiter-screening': return 'AI Candidate Ranking';
      case 'recruiter-applications': return 'Applications Pipeline';
      case 'recruiter-candidates': return 'Talent Directory';
      case 'recruiter-interviews': return 'Interview Desk';
      case 'recruiter-analytics': return 'Recruitment Analytics';
      case 'candidate-dashboard': return 'Candidate Dashboard';
      case 'candidate-jobs': return 'Browse Open Positions';
      case 'candidate-applications': return 'My Applications';
      case 'candidate-interviews': return 'My Interviews';
      case 'candidate-resume': return 'Resume Management';
      case 'candidate-profile': return 'My Profile';
      case 'admin-dashboard': return 'System Administration';
      default: return 'RecruVexa AI';
    }
  };

  return (
    <div className="app-container">
      {!isDashboard ? (
        <>
          <Navbar onNavigate={handleNavigate} activeSection={currentView} />
          <main style={{ flex: 1 }}>
            {currentView === 'home' && <LandingPage onNavigate={handleNavigate} />}
            {currentView === 'browse-jobs' && (
              <div style={{ maxWidth: '1280px', margin: '2rem auto', padding: '0 2rem' }}>
                <BrowseJobsPage />
              </div>
            )}
            {currentView === 'demo-tour' && <LandingPage onNavigate={handleNavigate} />}
            {currentView === 'login' && <LoginPage onNavigate={handleNavigate} />}
            {currentView === 'register' && <RegisterPage onNavigate={handleNavigate} />}
          </main>
        </>
      ) : (
        <div className="dashboard-layout">
          <Sidebar
            currentTab={currentView}
            onSelectTab={handleNavigate}
            onNavigateHome={() => handleNavigate('home')}
          />
          <div className="dashboard-main">
            <TopHeader
              title={getPageTitle()}
              subtitle={`Signed in as ${user?.full_name} (${user?.role})`}
              actionLabel={role === 'RECRUITER' ? 'Post New Job' : null}
              onActionClick={() => setIsJobModalOpen(true)}
              onToggleMobileMenu={() => setMobileMenuOpen(!mobileMenuOpen)}
            />
            <div className="dashboard-content">
              {/* Recruiter Views */}
              {currentView === 'recruiter-dashboard' && (
                <RecruiterDashboard
                  onNavigate={handleNavigate}
                  onOpenJobModal={() => setIsJobModalOpen(true)}
                />
              )}
              {currentView === 'recruiter-jobs' && (
                <JobsManagementPage onNavigateToRanking={handleNavigateToRanking} />
              )}
              {currentView === 'recruiter-screening' && (
                <CandidateRankingPage initialJobId={selectedJobIdForRanking} />
              )}
              {currentView === 'recruiter-applications' && <ApplicationsPage />}
              {currentView === 'recruiter-candidates' && <CandidatesPoolPage />}
              {currentView === 'recruiter-interviews' && <InterviewsPage />}
              {currentView === 'recruiter-analytics' && <AnalyticsPage />}

              {/* Candidate Views */}
              {currentView === 'candidate-dashboard' && <CandidateDashboard onNavigate={handleNavigate} />}
              {currentView === 'candidate-jobs' && <BrowseJobsPage />}
              {currentView === 'candidate-applications' && <MyApplicationsPage />}
              {currentView === 'candidate-interviews' && <CandidateInterviewsPage />}
              {currentView === 'candidate-resume' && <CandidateResumePage />}
              {currentView === 'candidate-profile' && <CandidateProfilePage />}

              {/* Admin Views */}
              {currentView.startsWith('admin-') && <AdminDashboard />}
            </div>
          </div>
        </div>
      )}

      {/* Recruiter Job Modal */}
      {isJobModalOpen && (
        <JobFormModal
          isOpen={isJobModalOpen}
          onClose={() => setIsJobModalOpen(false)}
          onSaved={() => {}}
        />
      )}
    </div>
  );
};
