import React, { useState } from 'react';
import { api } from '../../services/api';
import { Calendar, Clock, Video, User, Link, X, AlertCircle } from 'lucide-react';

export const ScheduleInterviewModal = ({ isOpen, onClose, application, onScheduled }) => {
  if (!isOpen || !application) return null;

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState({
    interview_type: 'TECHNICAL',
    title: `Technical Interview: ${application.job_title}`,
    scheduled_date: new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0],
    scheduled_time: '14:00',
    duration_minutes: 45,
    interviewer_name: 'Sarah Jenkins',
    interviewer_email: 'sarah.recruiter@apextech.io',
    meeting_link: 'https://meet.google.com/rvx-interview',
    location: 'Google Meet Video Call',
    notes: 'Please review candidate GitHub portfolio and backend system design questions.'
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const timeFormatted = formData.scheduled_time.length === 5 ? `${formData.scheduled_time}:00` : formData.scheduled_time;
      await api.interviews.schedule({
        application_id: application.id,
        interview_type: formData.interview_type,
        title: formData.title,
        scheduled_date: formData.scheduled_date,
        scheduled_time: timeFormatted,
        duration_minutes: parseInt(formData.duration_minutes, 10),
        interviewer_name: formData.interviewer_name,
        interviewer_email: formData.interviewer_email,
        meeting_link: formData.meeting_link,
        location: formData.location,
        notes: formData.notes
      });
      onScheduled && onScheduled();
      onClose();
    } catch (err) {
      setError(err.message || 'Failed to schedule interview');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
            <Calendar size={20} color="var(--primary)" />
            <h3 style={{ fontSize: '1.15rem', color: '#FFF' }}>Schedule Candidate Interview</h3>
          </div>
          <button onClick={onClose} style={{ color: 'var(--text-muted)' }}><X size={20} /></button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            {error && (
              <div style={{ background: 'var(--danger-bg)', border: '1px solid rgba(244, 63, 94, 0.3)', padding: '0.75rem', borderRadius: '8px', color: 'var(--danger)', fontSize: '0.85rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <AlertCircle size={16} />
                {error}
              </div>
            )}

            <div style={{ background: 'var(--bg-primary)', padding: '0.85rem', borderRadius: '8px', border: '1px solid var(--border-subtle)', marginBottom: '1.25rem' }}>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>CANDIDATE & POSITION</div>
              <div style={{ fontSize: '0.95rem', fontWeight: 700, color: '#FFF' }}>
                {application.candidate_name} &bull; <span style={{ color: 'var(--cyan)' }}>{application.job_title}</span>
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Interview Stage / Type</label>
              <select
                className="form-select"
                value={formData.interview_type}
                onChange={e => setFormData({ ...formData, interview_type: e.target.value })}
              >
                <option value="TECHNICAL">Technical Interview</option>
                <option value="HR">HR / Culture Interview</option>
                <option value="MANAGERIAL">Managerial Interview</option>
                <option value="FINAL">Final Leadership Interview</option>
                <option value="VIDEO">Video Assessment</option>
                <option value="IN_PERSON">In-person Onsite Interview</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Interview Title</label>
              <input
                type="text"
                className="form-input"
                required
                value={formData.title}
                onChange={e => setFormData({ ...formData, title: e.target.value })}
              />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '0.75rem' }}>
              <div className="form-group">
                <label className="form-label">Date</label>
                <input
                  type="date"
                  className="form-input"
                  required
                  value={formData.scheduled_date}
                  onChange={e => setFormData({ ...formData, scheduled_date: e.target.value })}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Time</label>
                <input
                  type="time"
                  className="form-input"
                  required
                  value={formData.scheduled_time}
                  onChange={e => setFormData({ ...formData, scheduled_time: e.target.value })}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Duration</label>
                <select
                  className="form-select"
                  value={formData.duration_minutes}
                  onChange={e => setFormData({ ...formData, duration_minutes: e.target.value })}
                >
                  <option value={30}>30 Minutes</option>
                  <option value={45}>45 Minutes</option>
                  <option value={60}>60 Minutes</option>
                  <option value={90}>90 Minutes</option>
                </select>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
              <div className="form-group">
                <label className="form-label">Lead Interviewer</label>
                <input
                  type="text"
                  className="form-input"
                  required
                  value={formData.interviewer_name}
                  onChange={e => setFormData({ ...formData, interviewer_name: e.target.value })}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Interviewer Email</label>
                <input
                  type="email"
                  className="form-input"
                  value={formData.interviewer_email}
                  onChange={e => setFormData({ ...formData, interviewer_email: e.target.value })}
                />
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Virtual Meeting Link / Location</label>
              <input
                type="url"
                className="form-input"
                placeholder="https://meet.google.com/..."
                value={formData.meeting_link}
                onChange={e => setFormData({ ...formData, meeting_link: e.target.value })}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Internal Briefing Notes</label>
              <textarea
                className="form-textarea"
                rows={2}
                value={formData.notes}
                onChange={e => setFormData({ ...formData, notes: e.target.value })}
              />
            </div>
          </div>

          <div className="modal-footer">
            <button type="button" className="btn btn-outline btn-sm" onClick={onClose} disabled={loading}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary btn-sm" disabled={loading}>
              {loading ? 'Scheduling...' : 'Confirm & Send Invitation'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
