import React from 'react';
import { Sparkles } from 'lucide-react';

export const AIScoreMeter = ({ score, size = 'md', showLabel = true, onClick }) => {
  if (score === undefined || score === null) {
    return (
      <span className="badge badge-neutral" style={{ fontSize: '0.75rem' }}>
        Pending AI
      </span>
    );
  }

  const rounded = Math.round(score);
  let color = '#38BDF8';
  let badgeColor = 'rgba(56, 189, 248, 0.15)';
  let borderColor = 'rgba(56, 189, 248, 0.3)';
  let label = 'Match';

  if (rounded >= 88) {
    color = '#10B981';
    badgeColor = 'rgba(16, 185, 129, 0.15)';
    borderColor = 'rgba(16, 185, 129, 0.35)';
    label = 'Strong Match';
  } else if (rounded >= 75) {
    color = '#06B6D4';
    badgeColor = 'rgba(6, 182, 212, 0.15)';
    borderColor = 'rgba(6, 182, 212, 0.35)';
    label = 'Good Match';
  } else if (rounded >= 60) {
    color = '#F59E0B';
    badgeColor = 'rgba(245, 158, 11, 0.15)';
    borderColor = 'rgba(245, 158, 11, 0.35)';
    label = 'Moderate';
  } else {
    color = '#F43F5E';
    badgeColor = 'rgba(244, 63, 94, 0.15)';
    borderColor = 'rgba(244, 63, 94, 0.35)';
    label = 'Low Match';
  }

  if (size === 'ring') {
    return (
      <div
        className="ai-score-ring"
        style={{ '--score-pct': rounded, cursor: onClick ? 'pointer' : 'default' }}
        onClick={onClick}
        title="Click to view AI match breakdown"
      >
        <span className="ai-score-value" style={{ color }}>{rounded}%</span>
      </div>
    );
  }

  return (
    <div
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: '0.4rem',
        padding: size === 'sm' ? '0.2rem 0.5rem' : '0.35rem 0.75rem',
        borderRadius: '20px',
        background: badgeColor,
        border: `1px solid ${borderColor}`,
        cursor: onClick ? 'pointer' : 'default',
        transition: 'var(--transition-fast)'
      }}
      onClick={onClick}
      title={onClick ? "Click to view full AI match analysis" : undefined}
    >
      <Sparkles size={size === 'sm' ? 12 : 14} color={color} />
      <span style={{ fontWeight: 800, fontSize: size === 'sm' ? '0.78rem' : '0.88rem', color }}>
        {rounded}%
      </span>
      {showLabel && (
        <span style={{ fontSize: size === 'sm' ? '0.7rem' : '0.75rem', color: 'var(--text-secondary)', fontWeight: 500 }}>
          {label}
        </span>
      )}
    </div>
  );
};
