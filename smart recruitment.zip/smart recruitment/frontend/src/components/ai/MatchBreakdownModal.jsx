import React from 'react';
import { AIScoreMeter } from './AIScoreMeter';
import {
  Sparkles,
  X,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Briefcase,
  GraduationCap,
  Award,
  Layers,
  Info
} from 'lucide-react';

export const MatchBreakdownModal = ({ isOpen, onClose, scoreData, candidateName, jobTitle }) => {
  if (!isOpen || !scoreData) return null;

  let matchingSkills = [];
  let missingSkills = [];
  try {
    matchingSkills = typeof scoreData.matching_skills === 'string' ? JSON.parse(scoreData.matching_skills || '[]') : (scoreData.matching_skills || []);
  } catch (e) {
    matchingSkills = [];
  }

  try {
    missingSkills = typeof scoreData.missing_skills === 'string' ? JSON.parse(scoreData.missing_skills || '[]') : (scoreData.missing_skills || []);
  } catch (e) {
    missingSkills = [];
  }

  const breakdownPillars = [
    { label: 'Skills Match', score: scoreData.skills_match_score || 0, icon: Layers, weight: '35%' },
    { label: 'Experience Match', score: scoreData.experience_match_score || 0, icon: Briefcase, weight: '25%' },
    { label: 'Education Match', score: scoreData.education_match_score || 0, icon: GraduationCap, weight: '15%' },
    { label: 'Project Match', score: scoreData.project_match_score || 0, icon: FileText, weight: '15%' },
    { label: 'Certification Match', score: scoreData.certification_match_score || 0, icon: Award, weight: '10%' },
  ];

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-content" style={{ maxWidth: '780px' }} onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <div className="logo-icon-badge" style={{ width: '32px', height: '32px' }}>
              <Sparkles size={16} />
            </div>
            <div>
              <h3 style={{ fontSize: '1.15rem', color: '#FFF' }}>AI Match Intelligence</h3>
              <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                {candidateName} &bull; {jobTitle}
              </p>
            </div>
          </div>
          <button onClick={onClose} style={{ color: 'var(--text-muted)', padding: '0.25rem' }}>
            <X size={20} />
          </button>
        </div>

        {/* Body */}
        <div className="modal-body">
          {/* Responsible AI Notice */}
          <div className="ai-assistive-banner">
            <Info size={18} style={{ flexShrink: 0 }} />
            <div>
              <strong>Assistive Decision-Support Active:</strong> This evaluation is calculated via multi-factor heuristic scoring against job specifications. Final hiring decisions remain exclusively with human recruiters.
            </div>
          </div>

          {/* Overall Score Header Banner */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            background: 'linear-gradient(135deg, rgba(17, 28, 56, 0.9) 0%, rgba(22, 36, 71, 0.9) 100%)',
            border: '1px solid var(--border-cyan)',
            borderRadius: '12px',
            padding: '1.25rem',
            marginBottom: '1.5rem'
          }}>
            <div>
              <div style={{ fontSize: '0.8rem', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--cyan)', fontWeight: 700 }}>
                AI-Assisted Match Score
              </div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#FFF', fontFamily: 'var(--font-display)', marginTop: '0.2rem' }}>
                {Math.round(scoreData.overall_score || 0)}% Compatibility
              </div>
              <div style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: '0.2rem' }}>
                Classification: <strong style={{ color: '#FFF' }}>{scoreData.recommendation?.replace('_', ' ') || 'GOOD MATCH'}</strong>
              </div>
            </div>
            <AIScoreMeter score={scoreData.overall_score} size="ring" showLabel={false} />
          </div>

          {/* 5 Dimensional Pillars Breakdown */}
          <div style={{ marginBottom: '1.5rem' }}>
            <h4 style={{ fontSize: '0.9rem', color: '#FFF', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Layers size={16} color="var(--primary)" />
              Dimensional Scoring Breakdown
            </h4>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))', gap: '0.75rem' }}>
              {breakdownPillars.map((p, idx) => {
                const Icon = p.icon;
                return (
                  <div key={idx} style={{
                    background: 'var(--bg-primary)',
                    border: '1px solid var(--border-subtle)',
                    borderRadius: '10px',
                    padding: '0.85rem',
                    textAlign: 'center'
                  }}>
                    <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '0.4rem' }}>
                      <Icon size={16} color="var(--cyan)" />
                    </div>
                    <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>{p.label}</div>
                    <div style={{ fontSize: '1.2rem', fontWeight: 800, color: '#FFF', margin: '0.2rem 0' }}>
                      {Math.round(p.score)}%
                    </div>
                    <div style={{ fontSize: '0.68rem', color: 'var(--text-secondary)' }}>Weight {p.weight}</div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Matching & Missing Skills */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1.5rem' }}>
            <div style={{ background: 'var(--bg-primary)', padding: '1rem', borderRadius: '10px', border: '1px solid rgba(16, 185, 129, 0.2)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: '#34D399', fontWeight: 600, fontSize: '0.85rem', marginBottom: '0.75rem' }}>
                <CheckCircle2 size={16} /> Matching Skills ({matchingSkills.length})
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
                {matchingSkills.length > 0 ? (
                  matchingSkills.map((s, i) => (
                    <span key={i} className="skill-chip matching">{s}</span>
                  ))
                ) : (
                  <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>No exact matches identified</span>
                )}
              </div>
            </div>

            <div style={{ background: 'var(--bg-primary)', padding: '1rem', borderRadius: '10px', border: '1px solid rgba(244, 63, 94, 0.2)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: '#FB7185', fontWeight: 600, fontSize: '0.85rem', marginBottom: '0.75rem' }}>
                <AlertTriangle size={16} /> Missing Requirements ({missingSkills.length})
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
                {missingSkills.length > 0 ? (
                  missingSkills.map((s, i) => (
                    <span key={i} className="skill-chip missing">{s}</span>
                  ))
                ) : (
                  <span style={{ fontSize: '0.8rem', color: '#34D399' }}>Zero skill gaps! Full requirement coverage.</span>
                )}
              </div>
            </div>
          </div>

          {/* Qualitative Insights */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem', marginBottom: '1rem' }}>
            {scoreData.relevant_experience && (
              <div style={{ background: 'rgba(255,255,255,0.03)', padding: '0.85rem 1rem', borderRadius: '8px', borderLeft: '3px solid var(--primary)' }}>
                <div style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--text-secondary)', textTransform: 'uppercase' }}>Relevant Experience</div>
                <div style={{ fontSize: '0.85rem', color: '#FFF', marginTop: '0.2rem' }}>{scoreData.relevant_experience}</div>
              </div>
            )}

            {scoreData.relevant_projects && (
              <div style={{ background: 'rgba(255,255,255,0.03)', padding: '0.85rem 1rem', borderRadius: '8px', borderLeft: '3px solid var(--cyan)' }}>
                <div style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--text-secondary)', textTransform: 'uppercase' }}>Relevant Projects</div>
                <div style={{ fontSize: '0.85rem', color: '#FFF', marginTop: '0.2rem' }}>{scoreData.relevant_projects}</div>
              </div>
            )}

            {scoreData.potential_concerns && (
              <div style={{ background: 'rgba(245, 158, 11, 0.05)', padding: '0.85rem 1rem', borderRadius: '8px', borderLeft: '3px solid var(--warning)' }}>
                <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#FBBF24', textTransform: 'uppercase' }}>Potential Areas for Recruiter Verification</div>
                <div style={{ fontSize: '0.85rem', color: 'var(--text-primary)', marginTop: '0.2rem' }}>{scoreData.potential_concerns}</div>
              </div>
            )}

            {scoreData.ai_summary && (
              <div style={{ background: 'rgba(59, 130, 246, 0.06)', padding: '1rem', borderRadius: '8px', border: '1px solid rgba(59, 130, 246, 0.25)' }}>
                <div style={{ fontSize: '0.75rem', fontWeight: 700, color: 'var(--primary)', textTransform: 'uppercase', marginBottom: '0.35rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  <Sparkles size={14} /> AI Executive Summary
                </div>
                <div style={{ fontSize: '0.88rem', color: '#FFF', lineHeight: 1.6 }}>
                  {scoreData.ai_summary}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="modal-footer">
          <button className="btn btn-secondary btn-sm" onClick={onClose}>
            Close Analysis
          </button>
        </div>
      </div>
    </div>
  );
};
