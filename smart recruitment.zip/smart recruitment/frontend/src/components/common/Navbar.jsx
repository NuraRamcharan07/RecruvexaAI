import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { Sparkles, Briefcase, Users, Shield, ArrowRight, LogIn } from 'lucide-react';

export const Navbar = ({ onNavigate, activeSection }) => {
  const { user, isAuthenticated, logout } = useAuth();

  return (
    <nav className="public-navbar">
      <div className="logo-brand" style={{ cursor: 'pointer' }} onClick={() => onNavigate('home')}>
        <div className="logo-icon-badge">
          <Sparkles size={20} />
        </div>
        <span>RECRUVEXA <span style={{ color: 'var(--cyan)' }}>AI</span></span>
        <span className="logo-tag">SaaS 2.0</span>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '2rem' }}>
        <button
          className={`nav-link ${activeSection === 'home' ? 'active' : ''}`}
          onClick={() => onNavigate('home')}
          style={{ color: 'var(--text-secondary)', fontWeight: 500 }}
        >
          Overview
        </button>
        <button
          className="nav-link"
          onClick={() => onNavigate('browse-jobs')}
          style={{ color: 'var(--text-secondary)', fontWeight: 500 }}
        >
          Explore Jobs
        </button>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
        {isAuthenticated ? (
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <span style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
              Logged in as <strong style={{ color: '#FFF' }}>{user?.full_name}</strong> ({user?.role})
            </span>
            <button
              className="btn btn-primary btn-sm"
              onClick={() => onNavigate(user?.role === 'RECRUITER' ? 'recruiter-dashboard' : (user?.role === 'ADMIN' ? 'admin-dashboard' : 'candidate-dashboard'))}
            >
              Open Dashboard
              <ArrowRight size={14} />
            </button>
            <button className="btn btn-outline btn-sm" onClick={logout}>
              Sign Out
            </button>
          </div>
        ) : (
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
            <button className="btn btn-outline btn-sm" onClick={() => onNavigate('login')}>
              <LogIn size={14} />
              Sign In
            </button>
            <button className="btn btn-cyan btn-sm" onClick={() => onNavigate('register')}>
              Get Started
            </button>
          </div>
        )}
      </div>
    </nav>
  );
};
