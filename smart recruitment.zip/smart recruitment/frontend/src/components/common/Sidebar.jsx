import React from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  Sparkles,
  LayoutDashboard,
  Briefcase,
  Users,
  FileCheck2,
  CalendarCheck,
  BarChart3,
  Settings,
  FileText,
  UserCircle,
  LogOut,
  ShieldCheck,
  Search,
  Bell
} from 'lucide-react';

export const Sidebar = ({ currentTab, onSelectTab, onNavigateHome }) => {
  const { user, role, logout } = useAuth();

  const getNavItems = () => {
    if (role === 'RECRUITER') {
      return [
        { id: 'recruiter-dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { id: 'recruiter-jobs', label: 'Job Postings', icon: Briefcase },
        { id: 'recruiter-screening', label: 'AI Screening & Rank', icon: Sparkles },
        { id: 'recruiter-applications', label: 'Applications Pipeline', icon: FileCheck2 },
        { id: 'recruiter-candidates', label: 'Candidate Talent Pool', icon: Users },
        { id: 'recruiter-interviews', label: 'Interviews & Calendar', icon: CalendarCheck },
        { id: 'recruiter-analytics', label: 'Hiring Analytics', icon: BarChart3 },
      ];
    } else if (role === 'CANDIDATE') {
      return [
        { id: 'candidate-dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { id: 'candidate-jobs', label: 'Browse Openings', icon: Search },
        { id: 'candidate-applications', label: 'My Applications', icon: FileCheck2 },
        { id: 'candidate-interviews', label: 'Scheduled Interviews', icon: CalendarCheck },
        { id: 'candidate-resume', label: 'Resume & Documents', icon: FileText },
        { id: 'candidate-profile', label: 'Professional Profile', icon: UserCircle },
      ];
    } else {
      // ADMIN
      return [
        { id: 'admin-dashboard', label: 'System Overview', icon: LayoutDashboard },
        { id: 'admin-users', label: 'User Management', icon: Users },
        { id: 'admin-jobs', label: 'Moderation & Jobs', icon: Briefcase },
        { id: 'admin-ai-config', label: 'AI Engine Settings', icon: Sparkles },
        { id: 'admin-analytics', label: 'Platform Analytics', icon: BarChart3 },
      ];
    }
  };

  const navItems = getNavItems();

  return (
    <aside className="dashboard-sidebar">
      {/* Brand Header */}
      <div style={{ padding: '1.5rem', borderBottom: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'center', gap: '0.75rem', cursor: 'pointer' }} onClick={onNavigateHome}>
        <div className="logo-icon-badge">
          <Sparkles size={18} />
        </div>
        <div>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.15rem', color: '#FFF' }}>
            RECRUVEXA <span style={{ color: 'var(--cyan)' }}>AI</span>
          </div>
          <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
            {role === 'RECRUITER' ? 'Recruiter Suite' : (role === 'ADMIN' ? 'Control Console' : 'Candidate Portal')}
          </div>
        </div>
      </div>

      {/* Nav Menu */}
      <div style={{ flex: 1, padding: '1.25rem 0.75rem', display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
        <div style={{ fontSize: '0.7rem', textTransform: 'uppercase', color: 'var(--text-muted)', fontWeight: 700, letterSpacing: '0.05em', padding: '0 0.75rem 0.5rem' }}>
          Navigation
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.85rem',
                width: '100%',
                padding: '0.7rem 0.85rem',
                borderRadius: '8px',
                fontSize: '0.875rem',
                fontWeight: isActive ? 600 : 500,
                color: isActive ? '#FFF' : 'var(--text-secondary)',
                background: isActive ? 'linear-gradient(90deg, rgba(59, 130, 246, 0.2) 0%, rgba(6, 182, 212, 0.1) 100%)' : 'transparent',
                borderLeft: isActive ? '3px solid var(--cyan)' : '3px solid transparent',
                transition: 'var(--transition-fast)'
              }}
            >
              <Icon size={18} color={isActive ? 'var(--cyan)' : 'currentColor'} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* User Footer Card */}
      <div style={{ padding: '1rem', borderTop: '1px solid var(--border-subtle)', background: 'rgba(0,0,0,0.2)' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '0.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem', overflow: 'hidden' }}>
            <div style={{
              width: '36px',
              height: '36px',
              borderRadius: '50%',
              background: 'linear-gradient(135deg, #3B82F6, #8B5CF6)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: 700,
              fontSize: '0.85rem',
              color: '#FFF',
              flexShrink: 0
            }}>
              {user?.full_name?.charAt(0) || 'U'}
            </div>
            <div style={{ overflow: 'hidden' }}>
              <div style={{ fontSize: '0.82rem', fontWeight: 600, color: '#FFF', whiteSpace: 'nowrap', textOverflow: 'ellipsis', overflow: 'hidden' }}>
                {user?.full_name}
              </div>
              <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', whiteSpace: 'nowrap', textOverflow: 'ellipsis', overflow: 'hidden' }}>
                {user?.email}
              </div>
            </div>
          </div>
          <button
            onClick={logout}
            title="Log Out"
            style={{
              padding: '0.4rem',
              borderRadius: '6px',
              color: 'var(--text-muted)',
              transition: 'var(--transition-fast)'
            }}
            onMouseOver={(e) => e.currentTarget.style.color = '#F43F5E'}
            onMouseOut={(e) => e.currentTarget.style.color = 'var(--text-muted)'}
          >
            <LogOut size={16} />
          </button>
        </div>
      </div>
    </aside>
  );
};
