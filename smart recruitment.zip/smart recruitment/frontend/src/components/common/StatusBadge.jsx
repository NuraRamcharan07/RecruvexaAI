import React from 'react';

export const StatusBadge = ({ status, type = 'application' }) => {
  if (!status) return null;

  const normalized = status.toUpperCase().replace(/\s+/g, '_');

  let badgeClass = 'badge-neutral';
  let label = status.replace(/_/g, ' ');

  if (type === 'application') {
    switch (normalized) {
      case 'APPLIED':
        badgeClass = 'badge-blue';
        label = 'Applied';
        break;
      case 'RESUME_SCREENING':
        badgeClass = 'badge-cyan';
        label = 'Resume Screening';
        break;
      case 'SHORTLISTED':
        badgeClass = 'badge-purple';
        label = 'Shortlisted';
        break;
      case 'INTERVIEW_SCHEDULED':
        badgeClass = 'badge-amber';
        label = 'Interview Scheduled';
        break;
      case 'INTERVIEW_COMPLETED':
        badgeClass = 'badge-blue';
        label = 'Interview Completed';
        break;
      case 'SELECTED':
        badgeClass = 'badge-green';
        label = 'Selected';
        break;
      case 'REJECTED':
        badgeClass = 'badge-rose';
        label = 'Rejected';
        break;
      case 'WITHDRAWN':
        badgeClass = 'badge-neutral';
        label = 'Withdrawn';
        break;
      default:
        badgeClass = 'badge-neutral';
    }
  } else if (type === 'job') {
    switch (normalized) {
      case 'PUBLISHED':
        badgeClass = 'badge-green';
        label = 'Active / Published';
        break;
      case 'DRAFT':
        badgeClass = 'badge-amber';
        label = 'Draft';
        break;
      case 'CLOSED':
        badgeClass = 'badge-neutral';
        label = 'Closed';
        break;
      default:
        badgeClass = 'badge-neutral';
    }
  } else if (type === 'interview') {
    switch (normalized) {
      case 'SCHEDULED':
        badgeClass = 'badge-amber';
        label = 'Confirmed / Scheduled';
        break;
      case 'COMPLETED':
        badgeClass = 'badge-green';
        label = 'Completed';
        break;
      case 'CANCELLED':
        badgeClass = 'badge-rose';
        label = 'Cancelled';
        break;
      default:
        badgeClass = 'badge-neutral';
    }
  }

  return (
    <span className={`badge ${badgeClass}`}>
      {label}
    </span>
  );
};
