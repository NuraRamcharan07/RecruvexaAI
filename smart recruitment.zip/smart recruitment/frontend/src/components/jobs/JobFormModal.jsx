import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { Briefcase, X, AlertCircle } from 'lucide-react';

export const JobFormModal = ({ isOpen, onClose, job, onSaved }) => {
  if (!isOpen) return null;

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    department: 'Engineering',
    location: 'San Francisco, CA (Hybrid)',
    employment_type: 'FULL_TIME',
    experience_required: 3.0,
    min_salary: 120000,
    max_salary: 160000,
    salary_currency: 'USD',
    description: '',
    responsibilities: '',
    required_skills: '',
    preferred_skills: '',
    education_requirements: "Bachelor's degree in Computer Science or equivalent",
    certifications: '',
    status: 'PUBLISHED'
  });

  useEffect(() => {
    if (job) {
      setFormData({
        title: job.title || '',
        department: job.department || 'Engineering',
        location: job.location || '',
        employment_type: job.employment_type || 'FULL_TIME',
        experience_required: job.experience_required || 3.0,
        min_salary: job.min_salary || 120000,
        max_salary: job.max_salary || 160000,
        salary_currency: job.salary_currency || 'USD',
        description: job.description || '',
        responsibilities: job.responsibilities || '',
        required_skills: job.required_skills || '',
        preferred_skills: job.preferred_skills || '',
        education_requirements: job.education_requirements || '',
        certifications: job.certifications || '',
        status: job.status || 'PUBLISHED'
      });
    } else {
      setFormData({
        title: '',
        department: 'Engineering',
        location: 'Remote',
        employment_type: 'FULL_TIME',
        experience_required: 3.0,
        min_salary: 120000,
        max_salary: 160000,
        salary_currency: 'USD',
        description: 'We are seeking a talented engineer to join our high-growth recruitment intelligence platform team.',
        responsibilities: 'Build scalable microservices, collaborate with product managers, and write clean unit-tested code.',
        required_skills: 'Python, FastAPI, React, PostgreSQL, Docker',
        preferred_skills: 'Kubernetes, AWS, TypeScript',
        education_requirements: "Bachelor's degree in Computer Science or related field",
        certifications: 'Cloud credentials welcome',
        status: 'PUBLISHED'
      });
    }
  }, [job]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const payload = {
        ...formData,
        experience_required: parseFloat(formData.experience_required),
        min_salary: parseInt(formData.min_salary, 10),
        max_salary: parseInt(formData.max_salary, 10),
      };

      if (job?.id) {
        await api.jobs.update(job.id, payload);
      } else {
        await api.jobs.create(payload);
      }

      onSaved && onSaved();
      onClose();
    } catch (err) {
      setError(err.message || 'Failed to save job');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-content" style={{ maxWidth: '720px' }} onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
            <Briefcase size={20} color="var(--primary)" />
            <h3 style={{ fontSize: '1.15rem', color: '#FFF' }}>
              {job ? 'Edit Job Posting' : 'Create New Job Opening'}
            </h3>
          </div>
          <button onClick={onClose} style={{ color: 'var(--text-muted)' }}><X size={20} /></button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            {error && (
              <div style={{ background: 'var(--danger-bg)', border: '1px solid rgba(244, 63, 94, 0.3)', padding: '0.75rem', borderRadius: '8px', color: 'var(--danger)', fontSize: '0.85rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <AlertCircle size={16} />
                {error}
              </div>
            )}

            <div className="form-group">
              <label className="form-label">Job Title *</label>
              <input
                type="text"
                className="form-input"
                required
                placeholder="e.g. Senior Machine Learning Engineer"
                value={formData.title}
                onChange={e => setFormData({ ...formData, title: e.target.value })}
              />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '0.75rem' }}>
              <div className="form-group">
                <label className="form-label">Department</label>
                <input
                  type="text"
                  className="form-input"
                  required
                  value={formData.department}
                  onChange={e => setFormData({ ...formData, department: e.target.value })}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Location</label>
                <input
                  type="text"
                  className="form-input"
                  required
                  placeholder="e.g. Remote or San Francisco"
                  value={formData.location}
                  onChange={e => setFormData({ ...formData, location: e.target.value })}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Employment Type</label>
                <select
                  className="form-select"
                  value={formData.employment_type}
                  onChange={e => setFormData({ ...formData, employment_type: e.target.value })}
                >
                  <option value="FULL_TIME">Full-time</option>
                  <option value="PART_TIME">Part-time</option>
                  <option value="CONTRACT">Contract</option>
                  <option value="INTERNSHIP">Internship</option>
                  <option value="REMOTE">Remote</option>
                  <option value="HYBRID">Hybrid</option>
                </select>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '0.75rem' }}>
              <div className="form-group">
                <label className="form-label">Min Experience (Years)</label>
                <input
                  type="number"
                  step="0.5"
                  className="form-input"
                  required
                  value={formData.experience_required}
                  onChange={e => setFormData({ ...formData, experience_required: e.target.value })}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Salary Min ($)</label>
                <input
                  type="number"
                  className="form-input"
                  value={formData.min_salary}
                  onChange={e => setFormData({ ...formData, min_salary: e.target.value })}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Salary Max ($)</label>
                <input
                  type="number"
                  className="form-input"
                  value={formData.max_salary}
                  onChange={e => setFormData({ ...formData, max_salary: e.target.value })}
                />
              </div>
            </div>

            <div className="form-group">
              <label className="form-label">Required Skills (Comma separated) *</label>
              <input
                type="text"
                className="form-input"
                required
                placeholder="Python, React, FastAPI, Docker, PostgreSQL"
                value={formData.required_skills}
                onChange={e => setFormData({ ...formData, required_skills: e.target.value })}
              />
              <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                These skills directly power the AI matching engine and candidate ranking.
              </span>
            </div>

            <div className="form-group">
              <label className="form-label">Preferred Skills</label>
              <input
                type="text"
                className="form-input"
                placeholder="Kubernetes, Redis, AWS, TypeScript"
                value={formData.preferred_skills}
                onChange={e => setFormData({ ...formData, preferred_skills: e.target.value })}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Job Description *</label>
              <textarea
                className="form-textarea"
                rows={3}
                required
                value={formData.description}
                onChange={e => setFormData({ ...formData, description: e.target.value })}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Core Responsibilities</label>
              <textarea
                className="form-textarea"
                rows={2}
                value={formData.responsibilities}
                onChange={e => setFormData({ ...formData, responsibilities: e.target.value })}
              />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
              <div className="form-group">
                <label className="form-label">Education Requirements</label>
                <input
                  type="text"
                  className="form-input"
                  value={formData.education_requirements}
                  onChange={e => setFormData({ ...formData, education_requirements: e.target.value })}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Publication Status</label>
                <select
                  className="form-select"
                  value={formData.status}
                  onChange={e => setFormData({ ...formData, status: e.target.value })}
                >
                  <option value="PUBLISHED">Published (Accepting Applications)</option>
                  <option value="DRAFT">Draft (Internal Only)</option>
                  <option value="CLOSED">Closed (Hidden)</option>
                </select>
              </div>
            </div>
          </div>

          <div className="modal-footer">
            <button type="button" className="btn btn-outline btn-sm" onClick={onClose} disabled={loading}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary btn-sm" disabled={loading}>
              {loading ? 'Saving Opening...' : (job ? 'Update Job' : 'Publish Opening')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
