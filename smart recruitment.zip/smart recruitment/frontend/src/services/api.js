// API Client for RecruVexa AI REST endpoints

const API_BASE = '/api';

function getAuthHeaders(isFormData = false) {
  const token = localStorage.getItem('recruvexa_token');
  const headers = {};
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  if (!isFormData) {
    headers['Content-Type'] = 'application/json';
  }
  return headers;
}

async function request(endpoint, options = {}) {
  const isFormData = options.body instanceof FormData;
  const headers = {
    ...getAuthHeaders(isFormData),
    ...(options.headers || {})
  };

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers
  });

  if (response.status === 204) {
    return null;
  }

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const errorMsg = data.detail || (typeof data === 'string' ? data : 'Request failed');
    throw new Error(errorMsg);
  }

  return data;
}

export const api = {
  // Auth
  auth: {
    login: (email, password) => request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password })
    }),
    register: (userData) => request('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData)
    }),
    getMe: () => request('/auth/me'),
    logout: () => request('/auth/logout', { method: 'POST' }),
  },

  // Jobs
  jobs: {
    list: (params = {}) => {
      const query = new URLSearchParams();
      Object.entries(params).forEach(([k, v]) => {
        if (v !== undefined && v !== null && v !== '') query.append(k, v);
      });
      return request(`/jobs?${query.toString()}`);
    },
    get: (id) => request(`/jobs/${id}`),
    create: (jobData) => request('/jobs', {
      method: 'POST',
      body: JSON.stringify(jobData)
    }),
    update: (id, jobData) => request(`/jobs/${id}`, {
      method: 'PUT',
      body: JSON.stringify(jobData)
    }),
    delete: (id) => request(`/jobs/${id}`, { method: 'DELETE' }),
    duplicate: (id) => request(`/jobs/${id}/duplicate`, { method: 'POST' }),
    setStatus: (id, status) => request(`/jobs/${id}/status?status=${status}`, { method: 'POST' })
  },

  // Resumes
  resumes: {
    upload: (file) => {
      const formData = new FormData();
      formData.append('file', file);
      return request('/resumes/upload', {
        method: 'POST',
        body: formData
      });
    },
    getMy: () => request('/resumes/my'),
    get: (id) => request(`/resumes/${id}`),
    delete: (id) => request(`/resumes/${id}`, { method: 'DELETE' }),
    downloadUrl: (id) => `${API_BASE}/resumes/${id}/download`
  },

  // Applications
  applications: {
    apply: (jobId, resumeId = null, coverLetter = '') => request('/applications', {
      method: 'POST',
      body: JSON.stringify({ job_id: jobId, resume_id: resumeId, cover_letter: coverLetter })
    }),
    list: (params = {}) => {
      const query = new URLSearchParams();
      Object.entries(params).forEach(([k, v]) => {
        if (v !== undefined && v !== null && v !== '') query.append(k, v);
      });
      return request(`/applications?${query.toString()}`);
    },
    get: (id) => request(`/applications/${id}`),
    updateStatus: (id, status, notes = '', isShortlisted = null) => request(`/applications/${id}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status, notes, is_shortlisted: isShortlisted })
    }),
    toggleShortlist: (id, shortlist = true) => request(`/applications/${id}/shortlist?shortlist=${shortlist}`, {
      method: 'POST'
    }),
    withdraw: (id) => request(`/applications/${id}/withdraw`, { method: 'POST' })
  },

  // AI Screening
  screening: {
    analyze: (applicationId) => request(`/screening/analyze/${applicationId}`, { method: 'POST' }),
    getScore: (applicationId) => request(`/screening/${applicationId}`),
    getRanking: (jobId, params = {}) => {
      const query = new URLSearchParams();
      Object.entries(params).forEach(([k, v]) => {
        if (v !== undefined && v !== null && v !== '') query.append(k, v);
      });
      return request(`/screening/jobs/${jobId}/ranking?${query.toString()}`);
    }
  },

  // Interviews
  interviews: {
    list: (params = {}) => {
      const query = new URLSearchParams();
      Object.entries(params).forEach(([k, v]) => {
        if (v !== undefined && v !== null && v !== '') query.append(k, v);
      });
      return request(`/interviews?${query.toString()}`);
    },
    get: (id) => request(`/interviews/${id}`),
    schedule: (data) => request('/interviews', {
      method: 'POST',
      body: JSON.stringify(data)
    }),
    update: (id, data) => request(`/interviews/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data)
    }),
    cancel: (id, reason = '') => request(`/interviews/${id}?reason=${encodeURIComponent(reason)}`, {
      method: 'DELETE'
    })
  },

  // Analytics
  analytics: {
    getDashboard: (params = {}) => {
      const query = new URLSearchParams();
      Object.entries(params).forEach(([k, v]) => {
        if (v !== undefined && v !== null && v !== '') query.append(k, v);
      });
      return request(`/analytics/dashboard?${query.toString()}`);
    }
  },

  // Candidates
  candidates: {
    list: (params = {}) => {
      const query = new URLSearchParams();
      Object.entries(params).forEach(([k, v]) => {
        if (v !== undefined && v !== null && v !== '') query.append(k, v);
      });
      return request(`/candidates?${query.toString()}`);
    },
    get: (id) => request(`/candidates/${id}`),
    updateProfile: (profileData) => request('/candidates/profile', {
      method: 'PUT',
      body: JSON.stringify(profileData)
    })
  },

  // Admin
  admin: {
    getOverview: () => request('/admin/overview'),
    listUsers: (role = null) => request(`/admin/users${role ? `?role=${role}` : ''}`),
    toggleActive: (id) => request(`/admin/users/${id}/toggle-active`, { method: 'PUT' }),
    getAISettings: () => request('/admin/settings/ai'),
    updateAISettings: (settings) => request('/admin/settings/ai', {
      method: 'PUT',
      body: JSON.stringify(settings)
    })
  },

  // Notifications
  notifications: {
    list: () => request('/notifications'),
    markRead: (id) => request(`/notifications/${id}/read`, { method: 'PUT' }),
    markAllRead: () => request('/notifications/read-all', { method: 'PUT' })
  }
};
