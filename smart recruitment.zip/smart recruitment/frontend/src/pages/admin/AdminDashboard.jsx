import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import {
  ShieldCheck,
  Users,
  Briefcase,
  FileCheck2,
  CalendarCheck,
  Sparkles,
  CheckCircle2,
  Sliders,
  Settings,
  Database,
  Activity
} from 'lucide-react';

export const AdminDashboard = () => {
  const [overview, setOverview] = useState(null);
  const [users, setUsers] = useState([]);
  const [aiConfig, setAiConfig] = useState(null);
  const [activeTab, setActiveTab] = useState('overview'); // 'overview', 'users', 'ai-settings'
  const [loading, setLoading] = useState(true);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [ovData, usersData, configData] = await Promise.all([
        api.admin.getOverview(),
        api.admin.listUsers(),
        api.admin.getAISettings()
      ]);
      setOverview(ovData);
      setUsers(usersData || []);
      setAiConfig(configData);
    } catch (e) {
      console.error("Admin data fetch failed", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleToggleUserActive = async (id) => {
    try {
      await api.admin.toggleActive(id);
      fetchData();
    } catch (e) {
      alert("Failed to toggle user status: " + e.message);
    }
  };

  const handleSaveAISettings = async (e) => {
    e.preventDefault();
    setSaveSuccess(false);
    try {
      await api.admin.updateAISettings(aiConfig);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (e) {
      alert("Failed to update AI settings: " + e.message);
    }
  };

  return (
    <div>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.75rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', color: '#A78BFA', fontSize: '0.8rem', fontWeight: 700, textTransform: 'uppercase' }}>
            <ShieldCheck size={14} /> Master Administrator Console
          </div>
          <h2 style={{ fontSize: '1.5rem', color: '#FFF', marginTop: '0.2rem' }}>
            System Oversight & AI Calibration
          </h2>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
            Platform metrics, user role governance, and algorithmic scoring weight controls
          </p>
        </div>

        {/* Tab Controls */}
        <div style={{ display: 'flex', background: 'var(--bg-surface)', padding: '4px', borderRadius: '8px', border: '1px solid var(--border-subtle)' }}>
          <button
            className={`btn btn-sm ${activeTab === 'overview' ? 'btn-primary' : 'btn-outline'}`}
            onClick={() => setActiveTab('overview')}
          >
            <Activity size={14} /> Overview
          </button>
          <button
            className={`btn btn-sm ${activeTab === 'users' ? 'btn-primary' : 'btn-outline'}`}
            onClick={() => setActiveTab('users')}
          >
            <Users size={14} /> Directory ({users.length})
          </button>
          <button
            className={`btn btn-sm ${activeTab === 'ai-settings' ? 'btn-primary' : 'btn-outline'}`}
            onClick={() => setActiveTab('ai-settings')}
          >
            <Sparkles size={14} /> AI Configuration
          </button>
        </div>
      </div>

      {activeTab === 'overview' && (
        <>
          {/* Overview Cards */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '1.25rem', marginBottom: '2rem' }}>
            <div className="glass-card">
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Registered Users</div>
              <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#FFF', marginTop: '0.2rem' }}>
                {overview?.total_users || 0}
              </div>
              <div style={{ fontSize: '0.72rem', color: 'var(--cyan)' }}>Platform wide</div>
            </div>

            <div className="glass-card">
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Active Recruiters</div>
              <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#60A5FA', marginTop: '0.2rem' }}>
                {overview?.total_recruiters || 0}
              </div>
              <div style={{ fontSize: '0.72rem', color: 'var(--text-secondary)' }}>Hiring partners</div>
            </div>

            <div className="glass-card">
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Candidates</div>
              <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#34D399', marginTop: '0.2rem' }}>
                {overview?.total_candidates || 0}
              </div>
              <div style={{ fontSize: '0.72rem', color: 'var(--text-secondary)' }}>Job seekers</div>
            </div>

            <div className="glass-card">
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Total Job Openings</div>
              <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#FBBF24', marginTop: '0.2rem' }}>
                {overview?.total_jobs || 0}
              </div>
              <div style={{ fontSize: '0.72rem', color: 'var(--text-secondary)' }}>Active postings</div>
            </div>

            <div className="glass-card">
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Total Applications</div>
              <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#A78BFA', marginTop: '0.2rem' }}>
                {overview?.total_applications || 0}
              </div>
              <div style={{ fontSize: '0.72rem', color: 'var(--text-secondary)' }}>Evaluated by AI</div>
            </div>
          </div>

          {/* System Health Card */}
          <div className="glass-card" style={{ marginBottom: '2rem' }}>
            <h3 style={{ fontSize: '1.1rem', color: '#FFF', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Database size={16} color="var(--cyan)" />
              System Health & Diagnostics
            </h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1.25rem', fontSize: '0.85rem' }}>
              <div style={{ background: 'var(--bg-primary)', padding: '1rem', borderRadius: '8px' }}>
                <div style={{ color: 'var(--text-muted)' }}>Database Infrastructure</div>
                <div style={{ fontWeight: 700, color: '#10B981', marginTop: '0.25rem' }}>
                  Connected (Relational Engine Active)
                </div>
              </div>
              <div style={{ background: 'var(--bg-primary)', padding: '1rem', borderRadius: '8px' }}>
                <div style={{ color: 'var(--text-muted)' }}>AI Scoring Engine</div>
                <div style={{ fontWeight: 700, color: '#38BDF8', marginTop: '0.25rem' }}>
                  {overview?.ai_status || 'Deterministic & Heuristic Active'}
                </div>
              </div>
              <div style={{ background: 'var(--bg-primary)', padding: '1rem', borderRadius: '8px' }}>
                <div style={{ color: 'var(--text-muted)' }}>Document Storage</div>
                <div style={{ fontWeight: 700, color: '#FFF', marginTop: '0.25rem' }}>
                  {overview?.storage_used_mb || 18.6} MB (PDF/DOCX Extracted)
                </div>
              </div>
            </div>
          </div>
        </>
      )}

      {activeTab === 'users' && (
        <div className="glass-card">
          <h3 style={{ fontSize: '1.1rem', color: '#FFF', marginBottom: '1.25rem' }}>
            Platform User Governance Directory
          </h3>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
              <thead>
                <tr style={{ borderBottom: '1px solid var(--border-subtle)', color: 'var(--text-muted)' }}>
                  <th style={{ padding: '0.75rem 1rem' }}>User</th>
                  <th style={{ padding: '0.75rem 1rem' }}>Role</th>
                  <th style={{ padding: '0.75rem 1rem' }}>Status</th>
                  <th style={{ padding: '0.75rem 1rem' }}>Joined</th>
                  <th style={{ padding: '0.75rem 1rem', textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map(u => (
                  <tr key={u.id} style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                    <td style={{ padding: '0.85rem 1rem' }}>
                      <div style={{ fontWeight: 600, color: '#FFF' }}>{u.full_name}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{u.email}</div>
                    </td>
                    <td style={{ padding: '0.85rem 1rem' }}>
                      <span className={`badge ${u.role === 'ADMIN' ? 'badge-purple' : (u.role === 'RECRUITER' ? 'badge-blue' : 'badge-cyan')}`}>
                        {u.role}
                      </span>
                    </td>
                    <td style={{ padding: '0.85rem 1rem' }}>
                      <span className={`badge ${u.is_active ? 'badge-green' : 'badge-rose'}`}>
                        {u.is_active ? 'Active' : 'Suspended'}
                      </span>
                    </td>
                    <td style={{ padding: '0.85rem 1rem', color: 'var(--text-secondary)' }}>
                      {new Date(u.created_at).toLocaleDateString()}
                    </td>
                    <td style={{ padding: '0.85rem 1rem', textAlign: 'right' }}>
                      {u.role !== 'ADMIN' && (
                        <button
                          className={`btn btn-sm ${u.is_active ? 'btn-danger' : 'btn-outline'}`}
                          style={{ fontSize: '0.75rem', padding: '0.25rem 0.6rem' }}
                          onClick={() => handleToggleUserActive(u.id)}
                        >
                          {u.is_active ? 'Deactivate' : 'Activate'}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'ai-settings' && aiConfig && (
        <div className="glass-card" style={{ maxWidth: '750px' }}>
          <h3 style={{ fontSize: '1.15rem', color: '#FFF', marginBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Sparkles size={18} color="var(--cyan)" />
            AI Scoring Dimension Calibration
          </h3>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '1.5rem' }}>
            Configure the relative weight coefficients applied during multi-factor resume analysis.
          </p>

          {saveSuccess && (
            <div style={{ background: 'var(--success-bg)', border: '1px solid rgba(16, 185, 129, 0.3)', padding: '0.75rem 1rem', borderRadius: '8px', color: '#34D399', fontSize: '0.85rem', marginBottom: '1.25rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <CheckCircle2 size={16} /> AI configuration updated and live across all scoring pipelines!
            </div>
          )}

          <form onSubmit={handleSaveAISettings}>
            <div className="form-group">
              <label className="form-label">
                Skills Match Weight: <strong>{Math.round(aiConfig.skills_weight * 100)}%</strong>
              </label>
              <input
                type="range"
                min="0.1"
                max="0.6"
                step="0.05"
                value={aiConfig.skills_weight}
                onChange={e => setAiConfig({ ...aiConfig, skills_weight: parseFloat(e.target.value) })}
                style={{ width: '100%', accentColor: 'var(--cyan)' }}
              />
            </div>

            <div className="form-group">
              <label className="form-label">
                Experience Duration Weight: <strong>{Math.round(aiConfig.experience_weight * 100)}%</strong>
              </label>
              <input
                type="range"
                min="0.1"
                max="0.5"
                step="0.05"
                value={aiConfig.experience_weight}
                onChange={e => setAiConfig({ ...aiConfig, experience_weight: parseFloat(e.target.value) })}
                style={{ width: '100%', accentColor: 'var(--primary)' }}
              />
            </div>

            <div className="form-group">
              <label className="form-label">
                Education Level Weight: <strong>{Math.round(aiConfig.education_weight * 100)}%</strong>
              </label>
              <input
                type="range"
                min="0.05"
                max="0.3"
                step="0.05"
                value={aiConfig.education_weight}
                onChange={e => setAiConfig({ ...aiConfig, education_weight: parseFloat(e.target.value) })}
                style={{ width: '100%', accentColor: '#A78BFA' }}
              />
            </div>

            <div className="form-group">
              <label className="form-label">
                Practical Projects Weight: <strong>{Math.round(aiConfig.project_weight * 100)}%</strong>
              </label>
              <input
                type="range"
                min="0.05"
                max="0.3"
                step="0.05"
                value={aiConfig.project_weight}
                onChange={e => setAiConfig({ ...aiConfig, project_weight: parseFloat(e.target.value) })}
                style={{ width: '100%', accentColor: '#F59E0B' }}
              />
            </div>

            <div className="form-group">
              <label className="form-label">
                Certifications Weight: <strong>{Math.round(aiConfig.certification_weight * 100)}%</strong>
              </label>
              <input
                type="range"
                min="0.05"
                max="0.25"
                step="0.05"
                value={aiConfig.certification_weight}
                onChange={e => setAiConfig({ ...aiConfig, certification_weight: parseFloat(e.target.value) })}
                style={{ width: '100%', accentColor: '#10B981' }}
              />
            </div>

            <button type="submit" className="btn btn-primary" style={{ marginTop: '0.75rem' }}>
              Save AI Calibration
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
