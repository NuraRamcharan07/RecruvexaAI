import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Sparkles, Mail, Lock, User, Briefcase, AlertCircle, ArrowRight } from 'lucide-react';

export const RegisterPage = ({ onNavigate }) => {
  const { register } = useAuth();
  const [role, setRole] = useState('RECRUITER');
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    full_name: '',
    phone: '',
    company_name: '',
    industry: 'Technology',
    designatory_title: 'Talent Acquisition Director',
    headline: 'Senior Software Engineer',
    location: 'San Francisco, CA',
    total_experience_years: 4.0
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const payload = {
        email: formData.email,
        password: formData.password,
        full_name: formData.full_name,
        phone: formData.phone,
        role: role,
        ...(role === 'RECRUITER' ? {
          company_name: formData.company_name,
          industry: formData.industry,
          designatory_title: formData.designatory_title
        } : {
          headline: formData.headline,
          location: formData.location,
          total_experience_years: parseFloat(formData.total_experience_years)
        })
      };

      const user = await register(payload);
      if (user.role === 'RECRUITER') {
        onNavigate('recruiter-dashboard');
      } else {
        onNavigate('candidate-dashboard');
      }
    } catch (err) {
      setError(err.message || 'Registration failed. Please check your details.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: 'calc(100vh - 70px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '2.5rem 1.5rem'
    }}>
      <div className="glass-card" style={{ maxWidth: '540px', width: '100%', padding: '2.5rem' }}>
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div className="logo-icon-badge" style={{ margin: '0 auto 1rem', width: '44px', height: '44px' }}>
            <Sparkles size={24} />
          </div>
          <h2 style={{ fontSize: '1.6rem', color: '#FFF' }}>Create Your Account</h2>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginTop: '0.35rem' }}>
            Join RecruVexa AI to revolutionize hiring and talent discovery
          </p>
        </div>

        {/* Role Selector Tabs */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem', background: 'var(--bg-primary)', padding: '4px', borderRadius: '10px', marginBottom: '1.5rem' }}>
          <button
            type="button"
            className={`btn ${role === 'RECRUITER' ? 'btn-primary' : 'btn-outline'}`}
            style={{ borderRadius: '8px', fontSize: '0.85rem' }}
            onClick={() => setRole('RECRUITER')}
          >
            I am a Recruiter / Employer
          </button>
          <button
            type="button"
            className={`btn ${role === 'CANDIDATE' ? 'btn-cyan' : 'btn-outline'}`}
            style={{ borderRadius: '8px', fontSize: '0.85rem' }}
            onClick={() => setRole('CANDIDATE')}
          >
            I am a Job Candidate
          </button>
        </div>

        {error && (
          <div style={{
            background: 'var(--danger-bg)',
            border: '1px solid rgba(244, 63, 94, 0.3)',
            padding: '0.75rem 1rem',
            borderRadius: '8px',
            color: 'var(--danger)',
            fontSize: '0.85rem',
            marginBottom: '1.25rem',
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem'
          }}>
            <AlertCircle size={16} />
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Full Name *</label>
            <input
              type="text"
              className="form-input"
              required
              placeholder="e.g. Sarah Jenkins"
              value={formData.full_name}
              onChange={e => setFormData({ ...formData, full_name: e.target.value })}
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
            <div className="form-group">
              <label className="form-label">Email Address *</label>
              <input
                type="email"
                className="form-input"
                required
                placeholder="name@domain.com"
                value={formData.email}
                onChange={e => setFormData({ ...formData, email: e.target.value })}
              />
            </div>
            <div className="form-group">
              <label className="form-label">Password *</label>
              <input
                type="password"
                className="form-input"
                required
                placeholder="Min 6 chars"
                value={formData.password}
                onChange={e => setFormData({ ...formData, password: e.target.value })}
              />
            </div>
          </div>

          {role === 'RECRUITER' ? (
            <>
              <div className="form-group">
                <label className="form-label">Company / Organization *</label>
                <input
                  type="text"
                  className="form-input"
                  required
                  placeholder="e.g. Apex Innovations"
                  value={formData.company_name}
                  onChange={e => setFormData({ ...formData, company_name: e.target.value })}
                />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                <div className="form-group">
                  <label className="form-label">Industry</label>
                  <input
                    type="text"
                    className="form-input"
                    value={formData.industry}
                    onChange={e => setFormData({ ...formData, industry: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Your Title</label>
                  <input
                    type="text"
                    className="form-input"
                    value={formData.designatory_title}
                    onChange={e => setFormData({ ...formData, designatory_title: e.target.value })}
                  />
                </div>
              </div>
            </>
          ) : (
            <>
              <div className="form-group">
                <label className="form-label">Professional Headline</label>
                <input
                  type="text"
                  className="form-input"
                  placeholder="e.g. Senior Full-Stack Engineer"
                  value={formData.headline}
                  onChange={e => setFormData({ ...formData, headline: e.target.value })}
                />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                <div className="form-group">
                  <label className="form-label">Location</label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="City, State / Remote"
                    value={formData.location}
                    onChange={e => setFormData({ ...formData, location: e.target.value })}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Experience (Years)</label>
                  <input
                    type="number"
                    step="0.5"
                    className="form-input"
                    value={formData.total_experience_years}
                    onChange={e => setFormData({ ...formData, total_experience_years: e.target.value })}
                  />
                </div>
              </div>
            </>
          )}

          <button
            type="submit"
            className="btn btn-primary"
            style={{ width: '100%', marginTop: '0.75rem' }}
            disabled={loading}
          >
            {loading ? 'Creating Account...' : 'Complete Registration'}
            <ArrowRight size={16} />
          </button>
        </form>

        <div style={{ marginTop: '1.75rem', textAlign: 'center', fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
          Already have an account?{' '}
          <button
            onClick={() => onNavigate('login')}
            style={{ color: 'var(--cyan)', fontWeight: 600, background: 'none', border: 'none', cursor: 'pointer' }}
          >
            Sign In Here
          </button>
        </div>
      </div>
    </div>
  );
};
