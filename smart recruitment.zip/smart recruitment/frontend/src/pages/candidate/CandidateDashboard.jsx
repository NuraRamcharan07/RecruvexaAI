import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { StatusBadge } from '../../components/common/StatusBadge';
import {
  FileCheck2,
  CalendarCheck,
  Briefcase,
  Upload,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  Clock,
  ExternalLink,
  MapPin
} from 'lucide-react';

export const CandidateDashboard = ({ onNavigate }) => {
  const { user } = useAuth();
  const [applications, setApplications] = useState([]);
  const [interviews, setInterviews] = useState([]);
  const [recommendedJobs, setRecommendedJobs] = useState([]);
  const [resumes, setResumes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [appsData, itvsData, jobsData, resumesData] = await Promise.all([
          api.applications.list(),
          api.interviews.list(),
          api.jobs.list({ page_size: 4 }),
          api.resumes.getMy()
        ]);
        setApplications(appsData || []);
        setInterviews(itvsData || []);
        setRecommendedJobs(jobsData.items || []);
        setResumes(resumesData || []);
      } catch (e) {
        console.error("Candidate dashboard fetch failed", e);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const latestApp = applications[0];

  const getStepProgress = (status) => {
    switch (status) {
      case 'APPLIED': return 1;
      case 'RESUME_SCREENING': return 2;
      case 'SHORTLISTED': return 3;
      case 'INTERVIEW_SCHEDULED': return 4;
      case 'INTERVIEW_COMPLETED': return 5;
      case 'SELECTED': return 6;
      case 'REJECTED': return 6;
      default: return 1;
    }
  };

  const currentStep = latestApp ? getStepProgress(latestApp.status) : 0;

  return (
    <div>
      {/* Welcome Banner */}
      <div style={{
        background: 'linear-gradient(135deg, rgba(17, 28, 56, 0.9) 0%, rgba(22, 36, 71, 0.9) 100%)',
        border: '1px solid var(--border-cyan)',
        borderRadius: '14px',
        padding: '1.75rem',
        marginBottom: '2rem',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '1rem'
      }}>
        <div>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', color: 'var(--cyan)', fontSize: '0.8rem', fontWeight: 700, textTransform: 'uppercase' }}>
            <Sparkles size={14} /> Candidate Career Portal
          </div>
          <h2 style={{ fontSize: '1.6rem', color: '#FFF', marginTop: '0.25rem' }}>
            Welcome back, {user?.full_name}!
          </h2>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem' }}>
            Track application progression, respond to scheduled interviews, and discover matched openings.
          </p>
        </div>

        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <button className="btn btn-outline btn-sm" onClick={() => onNavigate('candidate-resume')}>
            <Upload size={14} />
            Upload Resume
          </button>
          <button className="btn btn-primary btn-sm" onClick={() => onNavigate('candidate-jobs')}>
            Browse Open Jobs
            <ArrowRight size={14} />
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1.25rem', marginBottom: '2rem' }}>
        <div className="glass-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', color: '#3B82F6', marginBottom: '0.5rem' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Active Applications</span>
            <FileCheck2 size={18} />
          </div>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#FFF' }}>{applications.length}</div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: '0.2rem' }}>Submitted to date</div>
        </div>

        <div className="glass-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', color: '#06B6D4', marginBottom: '0.5rem' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Upcoming Interviews</span>
            <CalendarCheck size={18} />
          </div>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#FFF' }}>{interviews.length}</div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: '0.2rem' }}>Action required</div>
        </div>

        <div className="glass-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', color: '#10B981', marginBottom: '0.5rem' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Resumes on File</span>
            <Upload size={18} />
          </div>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#FFF' }}>{resumes.length}</div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: '0.2rem' }}>Ready for 1-click apply</div>
        </div>

        <div className="glass-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', color: '#8B5CF6', marginBottom: '0.5rem' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Recommended Roles</span>
            <Briefcase size={18} />
          </div>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#FFF' }}>{recommendedJobs.length}</div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: '0.2rem' }}>Matched to profile</div>
        </div>
      </div>

      {/* Latest Application Progress Stepper */}
      {latestApp && (
        <div className="glass-card" style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem', flexWrap: 'wrap', gap: '0.5rem' }}>
            <div>
              <div style={{ fontSize: '0.75rem', color: 'var(--cyan)', fontWeight: 700, textTransform: 'uppercase' }}>
                Active Application Timeline
              </div>
              <h3 style={{ fontSize: '1.15rem', color: '#FFF', margin: '0.2rem 0' }}>
                {latestApp.job_title}
              </h3>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                Applied {new Date(latestApp.created_at).toLocaleDateString()} &bull; Current Stage: <strong style={{ color: '#FFF' }}>{latestApp.current_stage}</strong>
              </div>
            </div>
            <StatusBadge status={latestApp.status} type="application" />
          </div>

          {/* Stepper Progress */}
          <div className="timeline-stepper">
            <div className="timeline-track" />
            <div className="timeline-progress" style={{ width: `${Math.min(100, (currentStep / 6) * 100)}%` }} />

            {['Applied', 'Screening', 'Shortlisted', 'Interview', 'Review', 'Decision'].map((label, idx) => {
              const stepNum = idx + 1;
              const isCompleted = stepNum < currentStep;
              const isActive = stepNum === currentStep;
              return (
                <div key={idx} className={`timeline-step ${isCompleted ? 'completed' : (isActive ? 'active' : '')}`}>
                  <div className="step-node">
                    {isCompleted ? <CheckCircle2 size={16} /> : stepNum}
                  </div>
                  <span className="step-title">{label}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Recommended Openings & Upcoming Interviews Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '1.5rem' }}>
        {/* Recommended Openings */}
        <div className="glass-card">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
            <h3 style={{ fontSize: '1.1rem', color: '#FFF', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Briefcase size={16} color="var(--cyan)" />
              Matched Open Positions
            </h3>
            <button className="btn btn-outline btn-sm" onClick={() => onNavigate('candidate-jobs')}>
              View All Openings
            </button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
            {recommendedJobs.map(job => (
              <div
                key={job.id}
                className="glass-card glass-card-interactive"
                style={{ padding: '1rem' }}
                onClick={() => onNavigate('candidate-jobs')}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.35rem' }}>
                  <h4 style={{ fontSize: '0.95rem', color: '#FFF' }}>{job.title}</h4>
                  <span className="badge badge-blue" style={{ fontSize: '0.68rem' }}>{job.employment_type?.replace('_', ' ')}</span>
                </div>
                <div style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', marginBottom: '0.5rem' }}>
                  {job.department} &bull; {job.location}
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                  <span>{job.experience_required}+ Yrs Required</span>
                  <span style={{ color: 'var(--cyan)', fontWeight: 600 }}>1-Click Apply &rarr;</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Scheduled Interviews Card */}
        <div className="glass-card">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
            <h3 style={{ fontSize: '1.1rem', color: '#FFF', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <CalendarCheck size={16} color="var(--primary)" />
              Upcoming Interviews
            </h3>
            <button className="btn btn-outline btn-sm" onClick={() => onNavigate('candidate-interviews')}>
              Manage
            </button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
            {interviews.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '2.5rem', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                No pending interviews scheduled yet.
              </div>
            ) : (
              interviews.map(itv => (
                <div key={itv.id} style={{ background: 'var(--bg-primary)', padding: '1rem', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.4rem' }}>
                    <div style={{ fontWeight: 700, fontSize: '0.92rem', color: '#FFF' }}>{itv.title}</div>
                    <span className="badge badge-cyan" style={{ fontSize: '0.7rem' }}>{itv.interview_type?.replace('_', ' ')}</span>
                  </div>
                  <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginBottom: '0.75rem' }}>
                    {itv.job_title} &bull; With {itv.interviewer_name}
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: '0.78rem' }}>
                    <span style={{ color: 'var(--cyan)', fontWeight: 600 }}>{itv.scheduled_date} at {itv.scheduled_time}</span>
                    {itv.meeting_link && (
                      <a href={itv.meeting_link} target="_blank" rel="noopener noreferrer" className="btn btn-primary btn-sm" style={{ fontSize: '0.72rem', padding: '0.2rem 0.5rem' }}>
                        Join Call <ExternalLink size={11} />
                      </a>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
