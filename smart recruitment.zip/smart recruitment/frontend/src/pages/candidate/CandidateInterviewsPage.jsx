import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { StatusBadge } from '../../components/common/StatusBadge';
import {
  CalendarCheck,
  Clock,
  Video,
  User,
  ExternalLink,
  MapPin,
  Calendar,
  Info
} from 'lucide-react';

export const CandidateInterviewsPage = () => {
  const [interviews, setInterviews] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchInterviews = async () => {
      setLoading(true);
      try {
        const data = await api.interviews.list();
        setInterviews(data || []);
      } catch (e) {
        console.error("Failed to load candidate interviews", e);
      } finally {
        setLoading(false);
      }
    };
    fetchInterviews();
  }, []);

  return (
    <div>
      <div style={{ marginBottom: '1.75rem' }}>
        <h2 style={{ fontSize: '1.5rem', color: '#FFF' }}>My Scheduled Interviews</h2>
        <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
          Review upcoming interview schedules, conference links, and interviewer briefing notes
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '1.25rem' }}>
        {interviews.length === 0 ? (
          <div className="glass-card" style={{ gridColumn: '1 / -1', textAlign: 'center', padding: '3.5rem' }}>
            <CalendarCheck size={40} color="var(--text-muted)" style={{ margin: '0 auto 1rem' }} />
            <h3 style={{ color: '#FFF' }}>No upcoming interviews scheduled</h3>
            <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', marginTop: '0.35rem' }}>
              When a recruiter shortlists your application, invitations with video call links will appear here.
            </p>
          </div>
        ) : (
          interviews.map(itv => (
            <div key={itv.id} className="glass-card" style={{ display: 'flex', flexDirection: 'column' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '0.5rem', marginBottom: '0.75rem' }}>
                <div>
                  <span className="badge badge-cyan" style={{ fontSize: '0.7rem', marginBottom: '0.35rem' }}>
                    {itv.interview_type?.replace('_', ' ')}
                  </span>
                  <h3 style={{ fontSize: '1.15rem', color: '#FFF', lineHeight: 1.3 }}>
                    {itv.title}
                  </h3>
                  <div style={{ fontSize: '0.8rem', color: 'var(--cyan)', fontWeight: 600, marginTop: '0.2rem' }}>
                    {itv.company_name} &bull; {itv.job_title}
                  </div>
                </div>
                <StatusBadge status={itv.status} type="interview" />
              </div>

              {/* Date & Time Ribbon */}
              <div style={{
                background: 'var(--bg-primary)',
                padding: '0.75rem 1rem',
                borderRadius: '8px',
                border: '1px solid var(--border-subtle)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: '1rem'
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.85rem', color: '#FFF' }}>
                  <Calendar size={15} color="var(--primary)" />
                  <strong>{itv.scheduled_date}</strong>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.85rem', color: 'var(--cyan)' }}>
                  <Clock size={15} />
                  <strong>{itv.scheduled_time} ({itv.duration_minutes}m)</strong>
                </div>
              </div>

              {/* Interviewer details */}
              <div style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', display: 'flex', flexDirection: 'column', gap: '0.4rem', marginBottom: '1.25rem', flex: 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  <User size={14} color="var(--text-muted)" />
                  <span>Interviewer: <strong style={{ color: '#FFF' }}>{itv.interviewer_name}</strong></span>
                </div>
                {itv.location && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                    <MapPin size={14} color="var(--text-muted)" />
                    <span>{itv.location}</span>
                  </div>
                )}
                {itv.notes && (
                  <div style={{ background: 'rgba(255,255,255,0.03)', padding: '0.65rem 0.85rem', borderRadius: '6px', fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: '0.35rem' }}>
                    <strong>Note:</strong> {itv.notes}
                  </div>
                )}
              </div>

              {/* Meeting Link Action */}
              <div style={{ borderTop: '1px solid var(--border-subtle)', paddingTop: '0.85rem' }}>
                {itv.meeting_link ? (
                  <a
                    href={itv.meeting_link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-primary btn-sm"
                    style={{ width: '100%' }}
                  >
                    <Video size={14} />
                    Launch Interview Meeting Link
                    <ExternalLink size={13} />
                  </a>
                ) : (
                  <div style={{ textAlign: 'center', fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                    In-person meeting at designated office address
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
