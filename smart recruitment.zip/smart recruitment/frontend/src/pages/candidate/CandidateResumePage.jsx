import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import {
  FileText,
  Upload,
  Trash2,
  Download,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  FileCheck,
  Calendar,
  Layers,
  GraduationCap,
  Award
} from 'lucide-react';

export const CandidateResumePage = () => {
  const [resumes, setResumes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState('');
  const [error, setError] = useState(null);
  const [successMsg, setSuccessMsg] = useState('');

  const fetchResumes = async () => {
    setLoading(true);
    try {
      const data = await api.resumes.getMy();
      setResumes(data || []);
    } catch (e) {
      console.error("Failed to load resumes", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchResumes();
  }, []);

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate extension
    const ext = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();
    if (!['.pdf', '.docx', '.doc', '.txt'].includes(ext)) {
      setError("Unsupported file format. Please upload PDF, DOCX, DOC, or TXT.");
      return;
    }

    setUploading(true);
    setError(null);
    setSuccessMsg('');

    try {
      setUploadProgress('Extracting raw text from document...');
      await new Promise(r => setTimeout(r, 400));
      setUploadProgress('Parsing candidate entities and skills...');
      await new Promise(r => setTimeout(r, 400));
      setUploadProgress('Structuring AI profile credentials...');

      await api.resumes.upload(file);
      setSuccessMsg("Resume uploaded and parsed successfully by AI!");
      fetchResumes();
    } catch (err) {
      setError(err.message || 'Failed to upload and parse resume');
    } finally {
      setUploading(false);
      setUploadProgress('');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this resume?")) {
      try {
        await api.resumes.delete(id);
        fetchResumes();
      } catch (e) {
        alert("Failed to delete resume: " + e.message);
      }
    }
  };

  return (
    <div>
      <div style={{ marginBottom: '1.75rem' }}>
        <h2 style={{ fontSize: '1.5rem', color: '#FFF' }}>Resume Management & AI Extraction</h2>
        <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
          Upload PDF/DOCX resumes for automated semantic extraction and job matching
        </p>
      </div>

      {/* Upload Box */}
      <div className="glass-card" style={{ padding: '2rem', textAlign: 'center', marginBottom: '2rem', border: '2px dashed var(--border-cyan)' }}>
        <div className="logo-icon-badge" style={{ margin: '0 auto 1rem', width: '48px', height: '48px' }}>
          <Upload size={24} />
        </div>
        <h3 style={{ fontSize: '1.2rem', color: '#FFF', marginBottom: '0.35rem' }}>
          Upload Your Latest Resume
        </h3>
        <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', maxWidth: '500px', margin: '0 auto 1.5rem' }}>
          Supported formats: <strong>PDF, DOCX, DOC, TXT</strong> (Max 10MB). Our AI engine immediately extracts your skills, work history, and education.
        </p>

        {uploading && (
          <div style={{ background: 'var(--bg-primary)', padding: '1rem', borderRadius: '8px', border: '1px solid var(--border-cyan)', maxWidth: '400px', margin: '0 auto 1.25rem', color: 'var(--cyan)', fontSize: '0.85rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
            <Sparkles size={16} className="pulse-glow" />
            <span>{uploadProgress || 'Processing document...'}</span>
          </div>
        )}

        {error && (
          <div style={{ background: 'var(--danger-bg)', border: '1px solid rgba(244, 63, 94, 0.3)', padding: '0.75rem', borderRadius: '8px', color: 'var(--danger)', fontSize: '0.85rem', maxWidth: '500px', margin: '0 auto 1.25rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
            <AlertCircle size={16} />
            {error}
          </div>
        )}

        {successMsg && (
          <div style={{ background: 'var(--success-bg)', border: '1px solid rgba(16, 185, 129, 0.3)', padding: '0.75rem', borderRadius: '8px', color: '#34D399', fontSize: '0.85rem', maxWidth: '500px', margin: '0 auto 1.25rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
            <CheckCircle2 size={16} />
            {successMsg}
          </div>
        )}

        <label className="btn btn-cyan btn-lg" style={{ cursor: 'pointer', display: 'inline-flex' }}>
          <FileText size={18} />
          <span>Select Resume File</span>
          <input
            type="file"
            accept=".pdf,.docx,.doc,.txt"
            style={{ display: 'none' }}
            onChange={handleFileUpload}
            disabled={uploading}
          />
        </label>
      </div>

      {/* Resumes List */}
      <h3 style={{ fontSize: '1.15rem', color: '#FFF', marginBottom: '1rem' }}>
        Uploaded Documents ({resumes.length})
      </h3>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
        {resumes.map(resume => (
          <div key={resume.id} className="glass-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem', marginBottom: '1rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                <div style={{ width: '44px', height: '44px', borderRadius: '10px', background: 'rgba(59, 130, 246, 0.15)', border: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--primary)' }}>
                  <FileText size={22} />
                </div>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <h4 style={{ fontSize: '1.1rem', color: '#FFF' }}>{resume.original_name}</h4>
                    {resume.is_primary && (
                      <span className="badge badge-green" style={{ fontSize: '0.65rem' }}>Primary Active</span>
                    )}
                  </div>
                  <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: '0.2rem' }}>
                    {(resume.file_size / 1024).toFixed(1)} KB &bull; Uploaded {new Date(resume.created_at).toLocaleDateString()}
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <a
                  href={api.resumes.downloadUrl(resume.id)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-outline btn-sm"
                  style={{ fontSize: '0.75rem' }}
                >
                  <Download size={14} /> Download
                </a>
                <button
                  className="btn btn-danger btn-sm"
                  style={{ fontSize: '0.75rem' }}
                  onClick={() => handleDelete(resume.id)}
                >
                  <Trash2 size={14} /> Delete
                </button>
              </div>
            </div>

            {/* AI Extracted Attributes Breakdown */}
            <div style={{ background: 'var(--bg-primary)', padding: '1rem', borderRadius: '10px', border: '1px solid var(--border-subtle)' }}>
              <div style={{ fontSize: '0.72rem', textTransform: 'uppercase', color: 'var(--cyan)', fontWeight: 700, letterSpacing: '0.05em', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                <Sparkles size={13} /> AI Extracted Profile Entities
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem', fontSize: '0.82rem' }}>
                <div>
                  <span style={{ color: 'var(--text-muted)' }}>Identified Name: </span>
                  <strong style={{ color: '#FFF' }}>{resume.parsed_name || 'Not detected'}</strong>
                </div>
                <div>
                  <span style={{ color: 'var(--text-muted)' }}>Email: </span>
                  <strong style={{ color: '#FFF' }}>{resume.parsed_email || 'Not detected'}</strong>
                </div>
                <div>
                  <span style={{ color: 'var(--text-muted)' }}>Verified Experience: </span>
                  <strong style={{ color: '#10B981' }}>{resume.parsed_experience_years || 0} Years</strong>
                </div>
                <div>
                  <span style={{ color: 'var(--text-muted)' }}>Education: </span>
                  <strong style={{ color: '#FFF' }}>{resume.parsed_education || 'Not specified'}</strong>
                </div>
              </div>

              {resume.parsed_skills && (
                <div style={{ marginTop: '0.85rem', borderTop: '1px solid rgba(255,255,255,0.05)', paddingTop: '0.75rem' }}>
                  <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginBottom: '0.35rem' }}>Recognized Technical Skills:</div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem' }}>
                    {resume.parsed_skills.split(',').map((s, idx) => (
                      <span key={idx} className="skill-chip matching" style={{ fontSize: '0.72rem' }}>{s.trim()}</span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
