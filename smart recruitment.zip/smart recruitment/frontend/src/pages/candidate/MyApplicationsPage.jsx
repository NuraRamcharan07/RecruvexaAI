import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { StatusBadge } from '../../components/common/StatusBadge';
import {
  FileCheck2,
  Clock,
  CheckCircle2,
  CalendarCheck,
  AlertCircle,
  ChevronRight,
  ArrowRight,
  XOctagon
} from 'lucide-react';

export const MyApplicationsPage = () => {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchApplications = async () => {
    setLoading(true);
    try {
      const data = await api.applications.list();
      setApplications(data || []);
    } catch (e) {
      console.error("Failed to load applications", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchApplications();
  }, []);

  const handleWithdraw = async (id) => {
    if (window.confirm("Are you sure you want to withdraw this application? This action cannot be reversed.")) {
      try {
        await api.applications.withdraw(id);
        fetchApplications();
      } catch (e) {
        alert("Failed to withdraw application: " + e.message);
      }
    }
  };

  const getStepProgress = (status) => {
    switch (status) {
      case 'APPLIED': return 1;
      case 'RESUME_SCREENING': return 2;
      case 'SHORTLISTED': return 3;
      case 'INTERVIEW_SCHEDULED': return 4;
      case 'INTERVIEW_COMPLETED': return 5;
      case 'SELECTED': return 6;
      case 'REJECTED': return 6;
      case 'WITHDRAWN': return 0;
      default: return 1;
    }
  };

  return (
    <div>
      <div style={{ marginBottom: '1.75rem' }}>
        <h2 style={{ fontSize: '1.5rem', color: '#FFF' }}>My Job Applications</h2>
        <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
          Track real-time candidate progression and recruiter decision milestones
        </p>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
        {applications.length === 0 ? (
          <div className="glass-card" style={{ textAlign: 'center', padding: '3.5rem' }}>
            <FileCheck2 size={40} color="var(--text-muted)" style={{ margin: '0 auto 1rem' }} />
            <h3 style={{ color: '#FFF' }}>No active applications found</h3>
            <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', marginTop: '0.35rem' }}>
              Explore available openings to submit your first intelligent application.
            </p>
          </div>
        ) : (
          applications.map(app => {
            const stepNum = getStepProgress(app.status);
            const isWithdrawn = app.status === 'WITHDRAWN';

            return (
              <div key={app.id} className="glass-card">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem', marginBottom: '1rem' }}>
                  <div>
                    <span className="badge badge-blue" style={{ fontSize: '0.7rem', marginBottom: '0.35rem' }}>
                      {app.job_department || 'Engineering'}
                    </span>
                    <h3 style={{ fontSize: '1.25rem', color: '#FFF' }}>
                      {app.job_title}
                    </h3>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginTop: '0.2rem' }}>
                      Applied {new Date(app.created_at).toLocaleDateString()} &bull; Current Milestone: <strong style={{ color: '#FFF' }}>{app.current_stage}</strong>
                    </div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                    <StatusBadge status={app.status} type="application" />
                    {!isWithdrawn && app.status !== 'SELECTED' && app.status !== 'REJECTED' && (
                      <button
                        className="btn btn-danger btn-sm"
                        style={{ fontSize: '0.72rem', padding: '0.25rem 0.5rem' }}
                        onClick={() => handleWithdraw(app.id)}
                      >
                        Withdraw
                      </button>
                    )}
                  </div>
                </div>

                {/* Progress Stepper */}
                {!isWithdrawn ? (
                  <div className="timeline-stepper" style={{ margin: '1.5rem 0' }}>
                    <div className="timeline-track" />
                    <div className="timeline-progress" style={{ width: `${Math.min(100, (stepNum / 6) * 100)}%` }} />

                    {['Application Submitted', 'Resume Under Review', 'Shortlisted', 'Interview Scheduled', 'Interview Completed', 'Final Decision'].map((label, idx) => {
                      const thisStep = idx + 1;
                      const isCompleted = thisStep < stepNum;
                      const isActive = thisStep === stepNum;
                      return (
                        <div key={idx} className={`timeline-step ${isCompleted ? 'completed' : (isActive ? 'active' : '')}`}>
                          <div className="step-node">
                            {isCompleted ? <CheckCircle2 size={16} /> : thisStep}
                          </div>
                          <span className="step-title">{label}</span>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div style={{ background: 'rgba(244, 63, 94, 0.08)', padding: '0.85rem', borderRadius: '8px', border: '1px solid rgba(244, 63, 94, 0.25)', color: '#FB7185', fontSize: '0.85rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <XOctagon size={16} />
                    This application was withdrawn. No further recruitment steps are active.
                  </div>
                )}

                {/* Recruiter Notes if any */}
                {app.recruiter_notes && (
                  <div style={{ background: 'var(--bg-primary)', padding: '0.85rem 1rem', borderRadius: '8px', borderLeft: '3px solid var(--primary)', fontSize: '0.82rem', color: 'var(--text-secondary)' }}>
                    <strong style={{ color: '#FFF' }}>Recruitment Team Note: </strong>
                    {app.recruiter_notes}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
