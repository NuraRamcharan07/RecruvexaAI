import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { api } from '../../services/api';
import { User, Mail, MapPin, Briefcase, Link as LinkIcon, CheckCircle2, AlertCircle } from 'lucide-react';

export const CandidateProfilePage = () => {
  const { user, refreshUser } = useAuth();
  const [formData, setFormData] = useState({
    headline: '',
    summary: '',
    location: '',
    total_experience_years: 0,
    education_level: '',
    current_company: '',
    current_title: '',
    skills_text: '',
    github_url: '',
    linkedin_url: '',
    portfolio_url: ''
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (user?.candidate_profile) {
      const p = user.candidate_profile;
      setFormData({
        headline: p.headline || '',
        summary: p.summary || '',
        location: p.location || '',
        total_experience_years: p.total_experience_years || 0,
        education_level: p.education_level || '',
        current_company: p.current_company || '',
        current_title: p.current_title || '',
        skills_text: p.skills_text || '',
        github_url: p.github_url || '',
        linkedin_url: p.linkedin_url || '',
        portfolio_url: p.portfolio_url || ''
      });
    }
  }, [user]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setSuccess(false);
    setError(null);

    try {
      await api.candidates.updateProfile({
        ...formData,
        total_experience_years: parseFloat(formData.total_experience_years)
      });
      await refreshUser();
      setSuccess(true);
    } catch (err) {
      setError(err.message || 'Failed to update profile');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: '800px' }}>
      <div style={{ marginBottom: '1.75rem' }}>
        <h2 style={{ fontSize: '1.5rem', color: '#FFF' }}>Professional Candidate Profile</h2>
        <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
          Keep your candidate credentials up to date to maximize match scores with hiring employers
        </p>
      </div>

      <div className="glass-card" style={{ padding: '2rem' }}>
        {success && (
          <div style={{ background: 'var(--success-bg)', border: '1px solid rgba(16, 185, 129, 0.3)', padding: '0.75rem 1rem', borderRadius: '8px', color: '#34D399', fontSize: '0.85rem', marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <CheckCircle2 size={16} /> Profile updated successfully!
          </div>
        )}

        {error && (
          <div style={{ background: 'var(--danger-bg)', border: '1px solid rgba(244, 63, 94, 0.3)', padding: '0.75rem 1rem', borderRadius: '8px', color: 'var(--danger)', fontSize: '0.85rem', marginBottom: '1.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <AlertCircle size={16} /> {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Professional Headline</label>
            <input
              type="text"
              className="form-input"
              placeholder="e.g. Senior Full-Stack Engineer | React, Python, AWS"
              value={formData.headline}
              onChange={e => setFormData({ ...formData, headline: e.target.value })}
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
            <div className="form-group">
              <label className="form-label">Location</label>
              <input
                type="text"
                className="form-input"
                placeholder="City, State / Remote"
                value={formData.location}
                onChange={e => setFormData({ ...formData, location: e.target.value })}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Total Experience (Years)</label>
              <input
                type="number"
                step="0.5"
                className="form-input"
                value={formData.total_experience_years}
                onChange={e => setFormData({ ...formData, total_experience_years: e.target.value })}
              />
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
            <div className="form-group">
              <label className="form-label">Current Company</label>
              <input
                type="text"
                className="form-input"
                placeholder="e.g. OmniTech Labs"
                value={formData.current_company}
                onChange={e => setFormData({ ...formData, current_company: e.target.value })}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Current Title</label>
              <input
                type="text"
                className="form-input"
                placeholder="e.g. Senior Engineer"
                value={formData.current_title}
                onChange={e => setFormData({ ...formData, current_title: e.target.value })}
              />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Education Level / Degree</label>
            <input
              type="text"
              className="form-input"
              placeholder="e.g. B.S. in Computer Science"
              value={formData.education_level}
              onChange={e => setFormData({ ...formData, education_level: e.target.value })}
            />
          </div>

          <div className="form-group">
            <label className="form-label">Core Skills (Comma separated)</label>
            <input
              type="text"
              className="form-input"
              placeholder="React, Python, FastAPI, Docker, PostgreSQL, AWS"
              value={formData.skills_text}
              onChange={e => setFormData({ ...formData, skills_text: e.target.value })}
            />
          </div>

          <div className="form-group">
            <label className="form-label">Professional Summary & Bio</label>
            <textarea
              className="form-textarea"
              rows={4}
              placeholder="Detail your engineering focus, key achievements, and domain expertise..."
              value={formData.summary}
              onChange={e => setFormData({ ...formData, summary: e.target.value })}
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1rem' }}>
            <div className="form-group">
              <label className="form-label">GitHub URL</label>
              <input
                type="url"
                className="form-input"
                placeholder="https://github.com/..."
                value={formData.github_url}
                onChange={e => setFormData({ ...formData, github_url: e.target.value })}
              />
            </div>

            <div className="form-group">
              <label className="form-label">LinkedIn URL</label>
              <input
                type="url"
                className="form-input"
                placeholder="https://linkedin.com/in/..."
                value={formData.linkedin_url}
                onChange={e => setFormData({ ...formData, linkedin_url: e.target.value })}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Portfolio / Website</label>
              <input
                type="url"
                className="form-input"
                placeholder="https://..."
                value={formData.portfolio_url}
                onChange={e => setFormData({ ...formData, portfolio_url: e.target.value })}
              />
            </div>
          </div>

          <button type="submit" className="btn btn-primary" disabled={loading} style={{ marginTop: '0.5rem' }}>
            {loading ? 'Saving Changes...' : 'Save Profile Details'}
          </button>
        </form>
      </div>
    </div>
  );
};
