import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import {
  Briefcase,
  Search,
  MapPin,
  Clock,
  DollarSign,
  Sparkles,
  CheckCircle2,
  Upload,
  X,
  AlertCircle,
  FileText
} from 'lucide-react';

export const BrowseJobsPage = () => {
  const { isAuthenticated, user, fastLogin } = useAuth();
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [department, setDepartment] = useState('');
  const [employmentType, setEmploymentType] = useState('');

  // Selected Job for Drawer/Apply
  const [selectedJob, setSelectedJob] = useState(null);
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [resumes, setResumes] = useState([]);
  const [selectedResumeId, setSelectedResumeId] = useState('');
  const [coverLetter, setCoverLetter] = useState('');
  const [applyLoading, setApplyLoading] = useState(false);
  const [applySuccess, setApplySuccess] = useState(false);
  const [applyError, setApplyError] = useState(null);

  const fetchJobs = async () => {
    setLoading(true);
    try {
      const data = await api.jobs.list({
        q: searchQuery,
        department,
        employment_type: employmentType || undefined
      });
      setJobs(data.items || []);
    } catch (e) {
      console.error("Failed to load jobs", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchJobs();
  }, [searchQuery, department, employmentType]);

  const handleOpenApply = async (job) => {
    setSelectedJob(job);
    setApplySuccess(false);
    setApplyError(null);

    if (isAuthenticated) {
      try {
        const userResumes = await api.resumes.getMy();
        setResumes(userResumes || []);
        const primary = userResumes.find(r => r.is_primary) || userResumes[0];
        if (primary) setSelectedResumeId(primary.id);
      } catch (e) {
        console.error("Failed to fetch resumes", e);
      }
    }
    setIsApplyModalOpen(true);
  };

  const handleApplySubmit = async (e) => {
    e.preventDefault();
    if (!isAuthenticated) {
      alert("Please sign in or use one of the quick demo buttons to submit an application.");
      return;
    }

    setApplyLoading(true);
    setApplyError(null);

    try {
      await api.applications.apply(
        selectedJob.id,
        selectedResumeId ? parseInt(selectedResumeId, 10) : null,
        coverLetter
      );
      setApplySuccess(true);
    } catch (err) {
      setApplyError(err.message || 'Failed to submit application');
    } finally {
      setApplyLoading(false);
    }
  };

  return (
    <div>
      {/* Header */}
      <div style={{ marginBottom: '1.75rem' }}>
        <h2 style={{ fontSize: '1.5rem', color: '#FFF' }}>Explore Career Opportunities</h2>
        <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
          Discover intelligent roles matched to your technical profile and credentials
        </p>
      </div>

      {/* Filter Bar */}
      <div className="glass-card" style={{ padding: '1rem 1.25rem', marginBottom: '1.5rem' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem', alignItems: 'center' }}>
          <div style={{ position: 'relative' }}>
            <input
              type="text"
              className="form-input"
              placeholder="Job title, keywords, or skills..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              style={{ paddingLeft: '2.5rem' }}
            />
            <Search size={16} color="var(--text-muted)" style={{ position: 'absolute', left: '0.85rem', top: '50%', transform: 'translateY(-50%)' }} />
          </div>

          <div>
            <select
              className="form-select"
              value={department}
              onChange={e => setDepartment(e.target.value)}
            >
              <option value="">All Departments</option>
              <option value="Engineering">Engineering</option>
              <option value="AI">AI Research</option>
              <option value="Product">Product Design</option>
              <option value="Infrastructure">Infrastructure</option>
            </select>
          </div>

          <div>
            <select
              className="form-select"
              value={employmentType}
              onChange={e => setEmploymentType(e.target.value)}
            >
              <option value="">All Employment Types</option>
              <option value="FULL_TIME">Full-time</option>
              <option value="PART_TIME">Part-time</option>
              <option value="REMOTE">Remote</option>
              <option value="HYBRID">Hybrid</option>
              <option value="CONTRACT">Contract</option>
            </select>
          </div>
        </div>
      </div>

      {/* Jobs Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '1.25rem' }}>
        {jobs.map(job => (
          <div key={job.id} className="glass-card" style={{ display: 'flex', flexDirection: 'column' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.75rem' }}>
              <div>
                <span className="badge badge-blue" style={{ fontSize: '0.7rem', marginBottom: '0.35rem' }}>
                  {job.department}
                </span>
                <h3 style={{ fontSize: '1.2rem', color: '#FFF', lineHeight: 1.3 }}>
                  {job.title}
                </h3>
                <div style={{ fontSize: '0.82rem', color: 'var(--cyan)', fontWeight: 600, marginTop: '0.2rem' }}>
                  {job.recruiter?.company_name || 'Apex Innovations'}
                </div>
              </div>
              <span className="badge badge-cyan" style={{ fontSize: '0.7rem' }}>
                {job.employment_type?.replace('_', ' ')}
              </span>
            </div>

            <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '0.75rem' }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                <MapPin size={13} color="var(--text-muted)" />
                {job.location}
              </span>
              <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                <Clock size={13} color="var(--text-muted)" />
                {job.experience_required}+ Yrs Exp
              </span>
            </div>

            {/* Salary Banner */}
            <div style={{ background: 'var(--bg-primary)', padding: '0.6rem 0.85rem', borderRadius: '8px', fontSize: '0.82rem', fontWeight: 600, color: '#10B981', marginBottom: '0.85rem' }}>
              Salary: {job.min_salary ? `$${job.min_salary.toLocaleString()} - $${job.max_salary?.toLocaleString()}` : 'Competitive'} {job.salary_currency}
            </div>

            <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', lineHeight: 1.5, marginBottom: '1rem', flex: 1 }}>
              {job.description?.slice(0, 140)}...
            </p>

            {/* Skills chips */}
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem', marginBottom: '1.25rem' }}>
              {job.required_skills?.split(',').slice(0, 5).map((s, idx) => (
                <span key={idx} className="skill-chip">{s.trim()}</span>
              ))}
            </div>

            {/* Actions */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderTop: '1px solid var(--border-subtle)', paddingTop: '0.85rem' }}>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                {job.applications_count || 0} applicants so far
              </span>
              <button className="btn btn-cyan btn-sm" onClick={() => handleOpenApply(job)}>
                <Sparkles size={14} /> Apply Now
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Apply Modal */}
      {isApplyModalOpen && selectedJob && (
        <div className="modal-backdrop" onClick={() => setIsApplyModalOpen(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <div>
                <h3 style={{ fontSize: '1.15rem', color: '#FFF' }}>Apply for Position</h3>
                <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                  {selectedJob.title} &bull; {selectedJob.recruiter?.company_name || 'Apex Innovations'}
                </p>
              </div>
              <button onClick={() => setIsApplyModalOpen(false)} style={{ color: 'var(--text-muted)' }}><X size={20} /></button>
            </div>

            {applySuccess ? (
              <div className="modal-body" style={{ textAlign: 'center', padding: '2.5rem' }}>
                <CheckCircle2 size={48} color="#10B981" style={{ margin: '0 auto 1rem' }} />
                <h3 style={{ color: '#FFF', fontSize: '1.3rem' }}>Application Successfully Submitted!</h3>
                <p style={{ color: 'var(--text-secondary)', fontSize: '0.88rem', margin: '0.5rem 0 1.5rem', lineHeight: 1.6 }}>
                  Our AI Screening engine has parsed your resume and registered your application in the recruiter's candidate matrix.
                </p>
                <button className="btn btn-primary btn-sm" onClick={() => setIsApplyModalOpen(false)}>
                  Close & View Pipeline
                </button>
              </div>
            ) : (
              <form onSubmit={handleApplySubmit}>
                <div className="modal-body">
                  {!isAuthenticated && (
                    <div style={{ background: 'rgba(59, 130, 246, 0.1)', border: '1px solid var(--border-cyan)', padding: '0.85rem', borderRadius: '8px', marginBottom: '1.25rem' }}>
                      <div style={{ fontSize: '0.82rem', color: '#FFF', marginBottom: '0.5rem' }}>
                        You are currently exploring as a guest. Click below to apply instantly as Candidate:
                      </div>
                      <button
                        type="button"
                        className="btn btn-cyan btn-sm"
                        onClick={() => fastLogin('CANDIDATE')}
                      >
                        Instant Sign In as Alex Rivers (Candidate)
                      </button>
                    </div>
                  )}

                  {applyError && (
                    <div style={{ background: 'var(--danger-bg)', border: '1px solid rgba(244, 63, 94, 0.3)', padding: '0.75rem', borderRadius: '8px', color: 'var(--danger)', fontSize: '0.85rem', marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <AlertCircle size={16} />
                      {applyError}
                    </div>
                  )}

                  <div className="form-group">
                    <label className="form-label">Select Saved Resume Document</label>
                    {resumes.length > 0 ? (
                      <select
                        className="form-select"
                        value={selectedResumeId}
                        onChange={e => setSelectedResumeId(e.target.value)}
                      >
                        {resumes.map(r => (
                          <option key={r.id} value={r.id}>
                            {r.original_name} ({r.parsed_experience_years || 0} yrs exp &bull; {r.is_primary ? 'Primary' : 'Archived'})
                          </option>
                        ))}
                      </select>
                    ) : (
                      <div style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', background: 'var(--bg-primary)', padding: '0.75rem', borderRadius: '8px', border: '1px solid var(--border-subtle)' }}>
                        No uploaded resumes found. Your candidate profile text will be used for automated screening.
                      </div>
                    )}
                  </div>

                  <div className="form-group">
                    <label className="form-label">Brief Cover Letter / Introduction Note</label>
                    <textarea
                      className="form-textarea"
                      rows={3}
                      placeholder="Highlight your relevant experience, interest in the team, and key project wins..."
                      value={coverLetter}
                      onChange={e => setCoverLetter(e.target.value)}
                    />
                  </div>
                </div>

                <div className="modal-footer">
                  <button type="button" className="btn btn-outline btn-sm" onClick={() => setIsApplyModalOpen(false)}>
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-primary btn-sm" disabled={applyLoading}>
                    {applyLoading ? 'Evaluating & Submitting...' : 'Submit AI Application'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
