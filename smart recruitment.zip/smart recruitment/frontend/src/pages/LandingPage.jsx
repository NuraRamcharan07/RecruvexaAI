import React, { useState } from 'react';
import { AIScoreMeter } from '../components/ai/AIScoreMeter';
import {
  Sparkles,
  ArrowRight,
  CheckCircle,
  Briefcase,
  Layers,
  CalendarCheck,
  BarChart3,
  ShieldCheck,
  Users,
  Search,
  Clock,
  TrendingUp,
  Cpu,
  FileText,
  Play
} from 'lucide-react';

export const LandingPage = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState('screening');

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      {/* 1. Hero Section */}
      <section style={{
        padding: '5rem 2rem 4rem',
        maxWidth: '1280px',
        margin: '0 auto',
        width: '100%',
        textAlign: 'center',
        position: 'relative'
      }}>
        <div style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: '0.5rem',
          padding: '0.4rem 1rem',
          borderRadius: '30px',
          background: 'linear-gradient(135deg, rgba(59, 130, 246, 0.15) 0%, rgba(6, 182, 212, 0.15) 100%)',
          border: '1px solid var(--border-cyan)',
          color: 'var(--cyan)',
          fontSize: '0.85rem',
          fontWeight: 600,
          marginBottom: '1.75rem'
        }}>
          <Sparkles size={16} />
          Intelligent Recruitment. Faster Decisions. Better Talent.
        </div>

        <h1 style={{
          fontSize: 'clamp(2.5rem, 5.5vw, 4.2rem)',
          fontWeight: 800,
          color: '#FFF',
          lineHeight: 1.1,
          letterSpacing: '-0.03em',
          maxWidth: '900px',
          margin: '0 auto 1.5rem',
          fontFamily: 'var(--font-display)'
        }}>
          Recruit Smarter. <br />
          <span style={{
            background: 'linear-gradient(135deg, #60A5FA 0%, #22D3EE 50%, #A78BFA 100%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent'
          }}>
            Hire Better With AI.
          </span>
        </h1>

        <p style={{
          fontSize: 'clamp(1rem, 1.8vw, 1.25rem)',
          color: 'var(--text-secondary)',
          maxWidth: '750px',
          margin: '0 auto 2.5rem',
          lineHeight: 1.6
        }}>
          RecruVexa AI streamlines recruitment with intelligent resume screening, candidate ranking, interview scheduling, and actionable hiring analytics — all in one unified SaaS ecosystem.
        </p>

        {/* Primary CTAs */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '1rem', flexWrap: 'wrap', marginBottom: '3.5rem' }}>
          <button className="btn btn-cyan btn-lg" onClick={() => onNavigate('register')}>
            Get Started Free
            <ArrowRight size={18} />
          </button>
          <button className="btn btn-secondary btn-lg" onClick={() => onNavigate('browse-jobs')}>
            <Search size={18} />
            Explore Candidate Jobs
          </button>
        </div>

        {/* Hero Interactive Interactive Preview Card */}
        <div className="glass-card pulse-glow" style={{
          maxWidth: '1000px',
          margin: '0 auto',
          textAlign: 'left',
          padding: '2rem',
          border: '1px solid rgba(59, 130, 246, 0.3)',
          background: 'linear-gradient(180deg, rgba(17, 28, 56, 0.8) 0%, rgba(11, 19, 43, 0.95) 100%)'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '1rem', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '0.75rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
              <div style={{ width: '12px', height: '12px', borderRadius: '50%', background: '#F43F5E' }} />
              <div style={{ width: '12px', height: '12px', borderRadius: '50%', background: '#F59E0B' }} />
              <div style={{ width: '12px', height: '12px', borderRadius: '50%', background: '#10B981' }} />
              <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginLeft: '0.5rem', fontFamily: 'monospace' }}>
                recruvexa.ai/recruiter/screening-engine
              </span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <span className="badge badge-cyan">AI Engine Active</span>
              <span className="badge badge-green">Human in the Loop</span>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.5rem', alignItems: 'center' }}>
            <div>
              <div style={{ fontSize: '0.75rem', color: 'var(--cyan)', fontWeight: 700, textTransform: 'uppercase' }}>
                Featured Job: Senior Full-Stack AI Engineer
              </div>
              <h3 style={{ fontSize: '1.4rem', color: '#FFF', margin: '0.35rem 0' }}>
                Candidate: Alex Rivers
              </h3>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.5, marginBottom: '1rem' }}>
                AI Analysis: Candidate demonstrates 6.0 yrs experience with strong overlap in React, FastAPI, AWS, and Docker. Exceeds standard role thresholds.
              </p>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem', marginBottom: '1.25rem' }}>
                <span className="skill-chip matching">React 96%</span>
                <span className="skill-chip matching">FastAPI 94%</span>
                <span className="skill-chip matching">Docker 92%</span>
                <span className="skill-chip matching">AWS 90%</span>
                <span className="skill-chip missing">Vector DBs (Gap)</span>
              </div>
              <div style={{ display: 'flex', gap: '0.75rem' }}>
                <button className="btn btn-primary btn-sm" onClick={() => onNavigate('login')}>
                  Sign In to Screen
                </button>
                <button className="btn btn-outline btn-sm" onClick={() => onNavigate('browse-jobs')}>
                  View All Openings
                </button>
              </div>
            </div>

            <div style={{ background: 'var(--bg-primary)', padding: '1.5rem', borderRadius: '12px', border: '1px solid var(--border-subtle)', textAlign: 'center' }}>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '0.75rem' }}>
                OVERALL MATCH COMPATIBILITY
              </div>
              <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '1rem' }}>
                <AIScoreMeter score={92.5} size="ring" />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem', fontSize: '0.75rem' }}>
                <div style={{ background: 'var(--bg-surface)', padding: '0.5rem', borderRadius: '6px' }}>
                  <div style={{ color: 'var(--text-muted)' }}>Skills</div>
                  <div style={{ fontWeight: 700, color: '#34D399' }}>95%</div>
                </div>
                <div style={{ background: 'var(--bg-surface)', padding: '0.5rem', borderRadius: '6px' }}>
                  <div style={{ color: 'var(--text-muted)' }}>Experience</div>
                  <div style={{ fontWeight: 700, color: '#38BDF8' }}>96%</div>
                </div>
                <div style={{ background: 'var(--bg-surface)', padding: '0.5rem', borderRadius: '6px' }}>
                  <div style={{ color: 'var(--text-muted)' }}>Education</div>
                  <div style={{ fontWeight: 700, color: '#A78BFA' }}>92%</div>
                </div>
                <div style={{ background: 'var(--bg-surface)', padding: '0.5rem', borderRadius: '6px' }}>
                  <div style={{ color: 'var(--text-muted)' }}>Projects</div>
                  <div style={{ fontWeight: 700, color: '#FBBF24' }}>88%</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Problem vs Solution Section */}
      <section style={{ padding: '5rem 2rem', background: 'var(--bg-secondary)', borderTop: '1px solid var(--border-subtle)', borderBottom: '1px solid var(--border-subtle)' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
          <div style={{ textAlign: 'center', maxWidth: '700px', margin: '0 auto 3.5rem' }}>
            <span className="badge badge-cyan" style={{ marginBottom: '0.75rem' }}>The Recruitment Dilemma</span>
            <h2 style={{ fontSize: '2.2rem', color: '#FFF', marginTop: '0.5rem' }}>
              Why Legacy Hiring Is Costing Companies Millions
            </h2>
            <p style={{ color: 'var(--text-secondary)', marginTop: '0.75rem' }}>
              Traditional hiring relies on tedious keyword matching that filters out top candidates while recruiters drown in hundreds of repetitive resumes.
            </p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '2rem' }}>
            {/* The Old Way */}
            <div className="glass-card" style={{ border: '1px solid rgba(244, 63, 94, 0.3)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--danger)', fontWeight: 700, marginBottom: '1rem' }}>
                <Clock size={18} />
                THE OLD WAY (TRADITIONAL)
              </div>
              <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '1rem', color: 'var(--text-secondary)', fontSize: '0.9rem' }}>
                <li style={{ display: 'flex', gap: '0.75rem' }}>
                  <span style={{ color: 'var(--danger)', fontWeight: 700 }}>✕</span>
                  <span><strong>40+ Hours per hire:</strong> Manual scanning of resumes leads to burnout and slow hiring velocity.</span>
                </li>
                <li style={{ display: 'flex', gap: '0.75rem' }}>
                  <span style={{ color: 'var(--danger)', fontWeight: 700 }}>✕</span>
                  <span><strong>Primitive keyword filters:</strong> Candidates who phrase skills slightly differently are silently rejected.</span>
                </li>
                <li style={{ display: 'flex', gap: '0.75rem' }}>
                  <span style={{ color: 'var(--danger)', fontWeight: 700 }}>✕</span>
                  <span><strong>Fragmented communication:</strong> Endless emails, scheduling conflicts, and poor candidate visibility.</span>
                </li>
              </ul>
            </div>

            {/* The RecruVexa Way */}
            <div className="glass-card" style={{ border: '1px solid rgba(6, 182, 212, 0.4)', background: 'linear-gradient(180deg, rgba(17, 28, 56, 0.9) 0%, rgba(11, 19, 43, 0.9) 100%)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--cyan)', fontWeight: 700, marginBottom: '1rem' }}>
                <Sparkles size={18} />
                THE RECRUVEXA AI WAY
              </div>
              <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '1rem', color: 'var(--text-primary)', fontSize: '0.9rem' }}>
                <li style={{ display: 'flex', gap: '0.75rem' }}>
                  <CheckCircle size={18} color="#10B981" style={{ flexShrink: 0 }} />
                  <span><strong>75% Faster screening:</strong> Instant multi-dimensional matching across skills, experience, education, and projects.</span>
                </li>
                <li style={{ display: 'flex', gap: '0.75rem' }}>
                  <CheckCircle size={18} color="#10B981" style={{ flexShrink: 0 }} />
                  <span><strong>Assistive Intelligence:</strong> Clear explanations of matching skills, missing skills, and areas to verify.</span>
                </li>
                <li style={{ display: 'flex', gap: '0.75rem' }}>
                  <CheckCircle size={18} color="#10B981" style={{ flexShrink: 0 }} />
                  <span><strong>Integrated Workflow:</strong> One click from candidate ranking to Google Meet / Zoom interview scheduling.</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Core Features Showcase */}
      <section style={{ padding: '5rem 2rem', maxWidth: '1280px', margin: '0 auto', width: '100%' }}>
        <div style={{ textAlign: 'center', maxWidth: '750px', margin: '0 auto 3.5rem' }}>
          <span className="badge badge-purple" style={{ marginBottom: '0.75rem' }}>Platform Modules</span>
          <h2 style={{ fontSize: '2.2rem', color: '#FFF' }}>Everything You Need To Build World-Class Teams</h2>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.5rem' }}>
          <div className="glass-card">
            <div className="logo-icon-badge" style={{ marginBottom: '1.25rem' }}>
              <Sparkles size={20} />
            </div>
            <h3 style={{ fontSize: '1.15rem', color: '#FFF', marginBottom: '0.5rem' }}>AI Resume Screening</h3>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.6 }}>
              Extracts text from PDF/DOCX resumes, detects entities, and scores compatibility across 5 distinct pillars.
            </p>
          </div>

          <div className="glass-card">
            <div className="logo-icon-badge" style={{ background: 'linear-gradient(135deg, #10B981, #06B6D4)', marginBottom: '1.25rem' }}>
              <TrendingUp size={20} />
            </div>
            <h3 style={{ fontSize: '1.15rem', color: '#FFF', marginBottom: '0.5rem' }}>Smart Candidate Ranking</h3>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.6 }}>
              Sort candidates instantly by AI match percentage, verified experience, or application date with precision filters.
            </p>
          </div>

          <div className="glass-card">
            <div className="logo-icon-badge" style={{ background: 'linear-gradient(135deg, #8B5CF6, #EC4899)', marginBottom: '1.25rem' }}>
              <CalendarCheck size={20} />
            </div>
            <h3 style={{ fontSize: '1.15rem', color: '#FFF', marginBottom: '0.5rem' }}>Interview Scheduling</h3>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.6 }}>
              Schedule technical, HR, or executive interviews with automated conflict detection and video conference links.
            </p>
          </div>

          <div className="glass-card">
            <div className="logo-icon-badge" style={{ background: 'linear-gradient(135deg, #F59E0B, #EF4444)', marginBottom: '1.25rem' }}>
              <BarChart3 size={20} />
            </div>
            <h3 style={{ fontSize: '1.15rem', color: '#FFF', marginBottom: '0.5rem' }}>Recruitment Analytics</h3>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.6 }}>
              Live hiring funnels, conversion rates, skill demand distributions, and average time-to-hire metrics.
            </p>
          </div>
        </div>
      </section>

      {/* 4. Responsible AI Banner */}
      <section style={{ padding: '3.5rem 2rem', background: 'linear-gradient(90deg, rgba(7, 13, 24, 1) 0%, rgba(17, 28, 56, 1) 100%)', borderTop: '1px solid var(--border-subtle)', borderBottom: '1px solid var(--border-subtle)' }}>
        <div style={{ maxWidth: '1000px', margin: '0 auto', display: 'flex', alignItems: 'center', gap: '2rem', flexWrap: 'wrap' }}>
          <div style={{ width: '60px', height: '60px', borderRadius: '16px', background: 'rgba(6, 182, 212, 0.15)', border: '1px solid var(--border-cyan)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--cyan)', flexShrink: 0 }}>
            <ShieldCheck size={32} />
          </div>
          <div style={{ flex: 1 }}>
            <h3 style={{ fontSize: '1.25rem', color: '#FFF', marginBottom: '0.35rem' }}>
              Built On Responsible AI & Human-In-The-Loop Ethics
            </h3>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.6 }}>
              RecruVexa AI never automatically discards candidates. Every score is an assistive decision-support indicator with clear explanations, protecting candidates from black-box automated rejections.
            </p>
          </div>
          <button className="btn btn-outline btn-sm" onClick={() => onNavigate('register')}>
            Get Started Free
          </button>
        </div>
      </section>

      {/* 5. Call To Action Footer */}
      <footer style={{ padding: '4rem 2rem 3rem', background: 'var(--bg-primary)', marginTop: 'auto', borderTop: '1px solid var(--border-subtle)' }}>
        <div style={{ maxWidth: '1200px', margin: '0 auto', textAlign: 'center' }}>
          <h2 style={{ fontSize: '2rem', color: '#FFF', marginBottom: '1rem', fontFamily: 'var(--font-display)' }}>
            Ready To Upgrade Your Recruitment Workflow?
          </h2>
          <p style={{ color: 'var(--text-secondary)', maxWidth: '600px', margin: '0 auto 2rem', fontSize: '0.95rem' }}>
            Join RecruVexa AI and transform the way your team finds and hires top talent.
          </p>
          <div style={{ display: 'flex', justifyContent: 'center', gap: '1rem', flexWrap: 'wrap', marginBottom: '3rem' }}>
            <button className="btn btn-primary" onClick={() => onNavigate('register')}>
              Create Your Account
            </button>
            <button className="btn btn-cyan" onClick={() => onNavigate('login')}>
              Sign In
            </button>
          </div>
          <div style={{ borderTop: '1px solid var(--border-subtle)', paddingTop: '2rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem', fontSize: '0.8rem', color: 'var(--text-muted)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <div className="logo-icon-badge" style={{ width: '24px', height: '24px' }}>
                <Sparkles size={12} />
              </div>
              <span style={{ color: '#FFF', fontWeight: 700 }}>RECRUVEXA AI</span> &copy; 2026. All rights reserved.
            </div>
            <div>
              Status: <span style={{ color: '#10B981' }}>All Systems Operational (FastAPI + AI Engine)</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
