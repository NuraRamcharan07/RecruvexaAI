import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { StatusBadge } from '../../components/common/StatusBadge';
import { AIScoreMeter } from '../../components/ai/AIScoreMeter';
import { MatchBreakdownModal } from '../../components/ai/MatchBreakdownModal';
import { ScheduleInterviewModal } from '../../components/interviews/ScheduleInterviewModal';
import {
  FileCheck2,
  Filter,
  Search,
  Sparkles,
  Calendar,
  ChevronRight,
  LayoutGrid,
  List as ListIcon,
  CheckCircle,
  XCircle,
  Clock
} from 'lucide-react';

const STAGES = [
  { id: 'APPLIED', label: 'Applied', color: '#3B82F6' },
  { id: 'RESUME_SCREENING', label: 'Resume Screening', color: '#06B6D4' },
  { id: 'SHORTLISTED', label: 'Shortlisted', color: '#8B5CF6' },
  { id: 'INTERVIEW_SCHEDULED', label: 'Interview Scheduled', color: '#F59E0B' },
  { id: 'INTERVIEW_COMPLETED', label: 'Interview Done', color: '#38BDF8' },
  { id: 'SELECTED', label: 'Selected / Offer', color: '#10B981' },
];

export const ApplicationsPage = () => {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState('kanban'); // 'kanban' or 'list'
  const [selectedJob, setSelectedJob] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  // Modals
  const [selectedScore, setSelectedScore] = useState(null);
  const [interviewApplication, setInterviewApplication] = useState(null);
  const [statusUpdateApp, setStatusUpdateApp] = useState(null);
  const [targetStatus, setTargetStatus] = useState('');
  const [statusNotes, setStatusNotes] = useState('');

  const fetchApplications = async () => {
    setLoading(true);
    try {
      const data = await api.applications.list();
      setApplications(data || []);
    } catch (e) {
      console.error("Failed to load applications", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchApplications();
  }, []);

  const handleUpdateStatus = async () => {
    if (!statusUpdateApp || !targetStatus) return;
    try {
      await api.applications.updateStatus(statusUpdateApp.id, targetStatus, statusNotes);
      setStatusUpdateApp(null);
      setStatusNotes('');
      fetchApplications();
    } catch (e) {
      alert("Failed to update status: " + e.message);
    }
  };

  const filteredApps = applications.filter(a => {
    const matchesSearch = !searchQuery ||
      a.candidate_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.job_title?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesJob = !selectedJob || a.job_title === selectedJob;
    return matchesSearch && matchesJob;
  });

  // Extract unique job titles for filter
  const uniqueJobs = Array.from(new Set(applications.map(a => a.job_title).filter(Boolean)));

  return (
    <div>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.75rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', color: '#FFF' }}>Recruitment Applications Pipeline</h2>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
            Track and advance candidates across the end-to-end hiring stages
          </p>
        </div>

        {/* View Toggle */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <div style={{ display: 'flex', background: 'var(--bg-surface)', padding: '3px', borderRadius: '8px', border: '1px solid var(--border-subtle)' }}>
            <button
              className={`btn btn-sm ${viewMode === 'kanban' ? 'btn-primary' : 'btn-outline'}`}
              style={{ padding: '0.35rem 0.65rem' }}
              onClick={() => setViewMode('kanban')}
            >
              <LayoutGrid size={14} /> Kanban
            </button>
            <button
              className={`btn btn-sm ${viewMode === 'list' ? 'btn-primary' : 'btn-outline'}`}
              style={{ padding: '0.35rem 0.65rem' }}
              onClick={() => setViewMode('list')}
            >
              <ListIcon size={14} /> List
            </button>
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="glass-card" style={{ padding: '0.85rem 1.25rem', marginBottom: '1.5rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', flexWrap: 'wrap' }}>
          <div style={{ position: 'relative', flex: 1, minWidth: '220px' }}>
            <input
              type="text"
              className="form-input"
              placeholder="Search candidate name or position..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              style={{ paddingLeft: '2.5rem' }}
            />
            <Search size={16} color="var(--text-muted)" style={{ position: 'absolute', left: '0.85rem', top: '50%', transform: 'translateY(-50%)' }} />
          </div>

          <div style={{ width: '240px' }}>
            <select
              className="form-select"
              value={selectedJob}
              onChange={e => setSelectedJob(e.target.value)}
            >
              <option value="">All Job Positions</option>
              {uniqueJobs.map((j, i) => (
                <option key={i} value={j}>{j}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Kanban Board View */}
      {viewMode === 'kanban' ? (
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
          gap: '1rem',
          alignItems: 'start',
          overflowX: 'auto',
          paddingBottom: '1rem'
        }}>
          {STAGES.map(stage => {
            const stageApps = filteredApps.filter(a => a.status === stage.id);
            return (
              <div
                key={stage.id}
                style={{
                  background: 'var(--bg-secondary)',
                  border: '1px solid var(--border-subtle)',
                  borderRadius: '12px',
                  padding: '1rem',
                  minHeight: '480px',
                  display: 'flex',
                  flexDirection: 'column'
                }}
              >
                {/* Column Header */}
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem', paddingBottom: '0.5rem', borderBottom: `2px solid ${stage.color}` }}>
                  <span style={{ fontWeight: 700, fontSize: '0.88rem', color: '#FFF' }}>
                    {stage.label}
                  </span>
                  <span className="badge" style={{ background: `${stage.color}20`, color: stage.color }}>
                    {stageApps.length}
                  </span>
                </div>

                {/* Column Cards */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', flex: 1 }}>
                  {stageApps.map(app => (
                    <div
                      key={app.id}
                      className="glass-card glass-card-interactive"
                      style={{ padding: '0.85rem' }}
                      onClick={() => {
                        setStatusUpdateApp(app);
                        setTargetStatus(app.status);
                      }}
                    >
                      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '0.5rem', marginBottom: '0.4rem' }}>
                        <div style={{ fontWeight: 700, fontSize: '0.9rem', color: '#FFF' }}>
                          {app.candidate_name}
                        </div>
                        <AIScoreMeter score={app.overall_match_score} size="sm" showLabel={false} />
                      </div>

                      <div style={{ fontSize: '0.78rem', color: 'var(--cyan)', fontWeight: 500, marginBottom: '0.5rem' }}>
                        {app.job_title}
                      </div>

                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: '0.72rem', color: 'var(--text-muted)', borderTop: '1px solid var(--border-subtle)', paddingTop: '0.5rem', marginTop: '0.5rem' }}>
                        <span>{app.total_experience_years} yrs exp</span>
                        <span style={{ color: 'var(--primary)', fontWeight: 600 }}>Update Stage &rarr;</span>
                      </div>
                    </div>
                  ))}
                  {stageApps.length === 0 && (
                    <div style={{ textAlign: 'center', padding: '2rem 0', color: 'var(--text-muted)', fontSize: '0.75rem' }}>
                      No candidates in this stage
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* List View */
        <div className="glass-card">
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
              <thead>
                <tr style={{ borderBottom: '1px solid var(--border-subtle)', color: 'var(--text-muted)' }}>
                  <th style={{ padding: '0.75rem 1rem' }}>Candidate</th>
                  <th style={{ padding: '0.75rem 1rem' }}>Job Title</th>
                  <th style={{ padding: '0.75rem 1rem' }}>AI Compatibility</th>
                  <th style={{ padding: '0.75rem 1rem' }}>Current Stage</th>
                  <th style={{ padding: '0.75rem 1rem', textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredApps.map(app => (
                  <tr key={app.id} style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                    <td style={{ padding: '0.85rem 1rem' }}>
                      <div style={{ fontWeight: 600, color: '#FFF' }}>{app.candidate_name}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{app.candidate_email}</div>
                    </td>
                    <td style={{ padding: '0.85rem 1rem', color: 'var(--text-secondary)' }}>
                      {app.job_title}
                    </td>
                    <td style={{ padding: '0.85rem 1rem' }}>
                      <AIScoreMeter
                        score={app.overall_match_score}
                        onClick={() => {
                          if (app.screening_score) {
                            setSelectedScore({
                              ...app.screening_score,
                              candidateName: app.candidate_name,
                              jobTitle: app.job_title
                            });
                          }
                        }}
                      />
                    </td>
                    <td style={{ padding: '0.85rem 1rem' }}>
                      <StatusBadge status={app.status} type="application" />
                    </td>
                    <td style={{ padding: '0.85rem 1rem', textAlign: 'right' }}>
                      <button
                        className="btn btn-primary btn-sm"
                        style={{ fontSize: '0.75rem', padding: '0.25rem 0.65rem' }}
                        onClick={() => {
                          setStatusUpdateApp(app);
                          setTargetStatus(app.status);
                        }}
                      >
                        Advance Stage
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Stage Transition Modal */}
      {statusUpdateApp && (
        <div className="modal-backdrop" onClick={() => setStatusUpdateApp(null)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3 style={{ fontSize: '1.15rem', color: '#FFF' }}>Advance Candidate Recruitment Stage</h3>
              <button onClick={() => setStatusUpdateApp(null)} style={{ color: 'var(--text-muted)' }}>✕</button>
            </div>
            <div className="modal-body">
              <div style={{ background: 'var(--bg-primary)', padding: '0.85rem', borderRadius: '8px', marginBottom: '1.25rem' }}>
                <div style={{ fontWeight: 700, color: '#FFF' }}>{statusUpdateApp.candidate_name}</div>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Position: {statusUpdateApp.job_title}</div>
              </div>

              <div className="form-group">
                <label className="form-label">Select Next Stage</label>
                <select
                  className="form-select"
                  value={targetStatus}
                  onChange={e => setTargetStatus(e.target.value)}
                >
                  <option value="APPLIED">Applied</option>
                  <option value="RESUME_SCREENING">Resume Screening</option>
                  <option value="SHORTLISTED">Shortlisted</option>
                  <option value="INTERVIEW_SCHEDULED">Interview Scheduled</option>
                  <option value="INTERVIEW_COMPLETED">Interview Completed</option>
                  <option value="SELECTED">Selected / Offer Extended</option>
                  <option value="REJECTED">Rejected</option>
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Recruiter Stage Notes</label>
                <textarea
                  className="form-textarea"
                  rows={3}
                  placeholder="e.g. Excellent technical assessment. Moving to final leadership interview."
                  value={statusNotes}
                  onChange={e => setStatusNotes(e.target.value)}
                />
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-outline btn-sm" onClick={() => setStatusUpdateApp(null)}>
                Cancel
              </button>
              <button className="btn btn-primary btn-sm" onClick={handleUpdateStatus}>
                Save Stage Transition
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Breakdown Modal */}
      {selectedScore && (
        <MatchBreakdownModal
          isOpen={!!selectedScore}
          onClose={() => setSelectedScore(null)}
          scoreData={selectedScore}
          candidateName={selectedScore.candidateName}
          jobTitle={selectedScore.jobTitle}
        />
      )}
    </div>
  );
};
