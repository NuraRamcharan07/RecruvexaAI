import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import {
  BarChart3,
  TrendingUp,
  Clock,
  CheckCircle2,
  Users,
  Briefcase,
  Layers,
  ArrowUpRight,
  Filter
} from 'lucide-react';

export const AnalyticsPage = () => {
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [departmentFilter, setDepartmentFilter] = useState('');

  const fetchAnalytics = async () => {
    setLoading(true);
    try {
      const data = await api.analytics.getDashboard({
        department: departmentFilter || undefined
      });
      setAnalytics(data);
    } catch (e) {
      console.error("Failed to load analytics", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnalytics();
  }, [departmentFilter]);

  return (
    <div>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.75rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', color: '#FFF' }}>Recruitment Analytics & Insights</h2>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
            Data-driven metrics covering recruitment velocity, funnel conversion, and skill trends
          </p>
        </div>

        <div style={{ width: '220px' }}>
          <select
            className="form-select"
            value={departmentFilter}
            onChange={e => setDepartmentFilter(e.target.value)}
          >
            <option value="">All Departments</option>
            <option value="Engineering">Engineering</option>
            <option value="AI">AI Research</option>
            <option value="Product">Product Design</option>
            <option value="Infrastructure">Infrastructure</option>
          </select>
        </div>
      </div>

      {/* KPI Conversion Rates Row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '1rem', marginBottom: '1.75rem' }}>
        <div className="glass-card">
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Screening Success Rate</div>
          <div style={{ fontSize: '1.7rem', fontWeight: 800, color: '#38BDF8', margin: '0.25rem 0' }}>
            {analytics?.screening_success_rate || 0}%
          </div>
          <div style={{ fontSize: '0.72rem', color: 'var(--text-secondary)' }}>Passed automated criteria</div>
        </div>

        <div className="glass-card">
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Shortlisting Rate</div>
          <div style={{ fontSize: '1.7rem', fontWeight: 800, color: '#8B5CF6', margin: '0.25rem 0' }}>
            {analytics?.shortlisting_rate || 0}%
          </div>
          <div style={{ fontSize: '0.72rem', color: 'var(--text-secondary)' }}>Advancing to interview</div>
        </div>

        <div className="glass-card">
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Interview Conversion</div>
          <div style={{ fontSize: '1.7rem', fontWeight: 800, color: '#F59E0B', margin: '0.25rem 0' }}>
            {analytics?.interview_rate || 0}%
          </div>
          <div style={{ fontSize: '0.72rem', color: 'var(--text-secondary)' }}>Scheduled candidate ratio</div>
        </div>

        <div className="glass-card">
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Offer / Selection Rate</div>
          <div style={{ fontSize: '1.7rem', fontWeight: 800, color: '#10B981', margin: '0.25rem 0' }}>
            {analytics?.selection_rate || 0}%
          </div>
          <div style={{ fontSize: '0.72rem', color: 'var(--text-secondary)' }}>Final hiring yield</div>
        </div>

        <div className="glass-card">
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Avg Time to Hire</div>
          <div style={{ fontSize: '1.7rem', fontWeight: 800, color: '#FFF', margin: '0.25rem 0' }}>
            {analytics?.avg_time_to_hire_days || 16.8}d
          </div>
          <div style={{ fontSize: '0.72rem', color: 'var(--text-secondary)' }}>From apply to selection</div>
        </div>
      </div>

      {/* Funnel & Timeline Visualizations Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '1.5rem', marginBottom: '2rem' }}>
        {/* Recruitment Funnel Visual */}
        <div className="glass-card">
          <h3 style={{ fontSize: '1.1rem', color: '#FFF', marginBottom: '1.25rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <TrendingUp size={18} color="var(--cyan)" />
            End-to-End Recruitment Funnel
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {analytics?.hiring_funnel?.map((step, idx) => (
              <div key={idx}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.4rem' }}>
                  <span style={{ fontWeight: 600, color: '#FFF' }}>{step.stage}</span>
                  <span style={{ color: 'var(--text-secondary)' }}>
                    <strong style={{ color: '#FFF' }}>{step.count}</strong> candidates ({step.percentage}%)
                  </span>
                </div>
                <div style={{ height: '10px', background: 'var(--bg-primary)', borderRadius: '5px', overflow: 'hidden' }}>
                  <div style={{
                    width: `${Math.max(5, step.percentage)}%`,
                    height: '100%',
                    background: idx === 0 ? '#3B82F6' : (idx === 1 ? '#06B6D4' : (idx === 2 ? '#8B5CF6' : (idx === 3 ? '#F59E0B' : '#10B981'))),
                    borderRadius: '5px',
                    transition: 'width 0.5s ease'
                  }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Timeline Chart */}
        <div className="glass-card">
          <h3 style={{ fontSize: '1.1rem', color: '#FFF', marginBottom: '1.25rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Clock size={18} color="var(--primary)" />
            Applications & Interview Activity Trend
          </h3>
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: '0.75rem', height: '220px', padding: '1rem 0', borderBottom: '1px solid var(--border-subtle)' }}>
            {analytics?.applications_timeline?.map((item, idx) => {
              const maxApps = Math.max(...(analytics.applications_timeline.map(t => t.applications)), 5);
              const heightPct = Math.max(15, (item.applications / maxApps) * 180);
              return (
                <div key={idx} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', height: '100%', justifyContent: 'flex-end' }}>
                  <div style={{ fontSize: '0.72rem', fontWeight: 700, color: '#FFF', marginBottom: '0.25rem' }}>
                    {item.applications}
                  </div>
                  <div style={{
                    width: '70%',
                    height: `${heightPct}px`,
                    background: 'linear-gradient(180deg, #3B82F6 0%, #06B6D4 100%)',
                    borderRadius: '4px 4px 0 0',
                    transition: 'height 0.4s ease'
                  }} />
                  <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', marginTop: '0.5rem', whiteSpace: 'nowrap' }}>
                    {item.date}
                  </div>
                </div>
              );
            })}
          </div>
          <div style={{ display: 'flex', justifyContent: 'center', gap: '1.5rem', marginTop: '0.75rem', fontSize: '0.75rem' }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', color: 'var(--cyan)' }}>
              <div style={{ width: '10px', height: '10px', background: '#06B6D4', borderRadius: '2px' }} />
              Applications Volume
            </span>
          </div>
        </div>
      </div>

      {/* Job-by-Job Performance Table */}
      <div className="glass-card">
        <h3 style={{ fontSize: '1.1rem', color: '#FFF', marginBottom: '1.25rem' }}>
          Job Openings Performance Breakdown
        </h3>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border-subtle)', color: 'var(--text-muted)' }}>
                <th style={{ padding: '0.75rem 1rem' }}>Job Title</th>
                <th style={{ padding: '0.75rem 1rem' }}>Department</th>
                <th style={{ padding: '0.75rem 1rem' }}>Applicants</th>
                <th style={{ padding: '0.75rem 1rem' }}>Shortlisted</th>
                <th style={{ padding: '0.75rem 1rem' }}>Interviews</th>
                <th style={{ padding: '0.75rem 1rem' }}>Offers</th>
                <th style={{ padding: '0.75rem 1rem' }}>Avg AI Score</th>
              </tr>
            </thead>
            <tbody>
              {analytics?.job_performance?.map(j => (
                <tr key={j.job_id} style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                  <td style={{ padding: '0.85rem 1rem', fontWeight: 600, color: '#FFF' }}>
                    {j.title}
                  </td>
                  <td style={{ padding: '0.85rem 1rem', color: 'var(--text-secondary)' }}>
                    {j.department}
                  </td>
                  <td style={{ padding: '0.85rem 1rem', color: '#FFF' }}>
                    {j.applications_count}
                  </td>
                  <td style={{ padding: '0.85rem 1rem', color: '#8B5CF6' }}>
                    {j.shortlisted_count}
                  </td>
                  <td style={{ padding: '0.85rem 1rem', color: '#F59E0B' }}>
                    {j.interviews_count}
                  </td>
                  <td style={{ padding: '0.85rem 1rem', color: '#10B981', fontWeight: 700 }}>
                    {j.selected_count}
                  </td>
                  <td style={{ padding: '0.85rem 1rem' }}>
                    <span className="badge badge-cyan">{j.avg_ai_score}%</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
