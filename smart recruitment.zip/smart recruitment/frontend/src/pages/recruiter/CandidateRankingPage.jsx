import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { AIScoreMeter } from '../../components/ai/AIScoreMeter';
import { StatusBadge } from '../../components/common/StatusBadge';
import { MatchBreakdownModal } from '../../components/ai/MatchBreakdownModal';
import { ScheduleInterviewModal } from '../../components/interviews/ScheduleInterviewModal';
import {
  Sparkles,
  Trophy,
  Filter,
  ArrowUpDown,
  Search,
  CheckCircle2,
  CalendarCheck,
  FileText,
  SlidersHorizontal,
  ChevronRight
} from 'lucide-react';

export const CandidateRankingPage = ({ initialJobId }) => {
  const [jobs, setJobs] = useState([]);
  const [selectedJobId, setSelectedJobId] = useState(initialJobId || null);
  const [rankedCandidates, setRankedCandidates] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters & Sorting
  const [sortBy, setSortBy] = useState('ai_score');
  const [minScore, setMinScore] = useState(0);
  const [minExperience, setMinExperience] = useState(0);
  const [skillFilter, setSkillFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  // Modals
  const [selectedScore, setSelectedScore] = useState(null);
  const [interviewApplication, setInterviewApplication] = useState(null);

  // Fetch jobs
  useEffect(() => {
    const loadJobs = async () => {
      try {
        const data = await api.jobs.list({ recruiter_only: true });
        setJobs(data.items || []);
        if (!selectedJobId && data.items?.length > 0) {
          setSelectedJobId(data.items[0].id);
        }
      } catch (e) {
        console.error("Failed to fetch jobs", e);
      }
    };
    loadJobs();
  }, []);

  // Fetch ranking when job or filters change
  const fetchRanking = async () => {
    if (!selectedJobId) return;
    setLoading(true);
    try {
      const data = await api.screening.getRanking(selectedJobId, {
        sort_by: sortBy,
        min_score: minScore > 0 ? minScore : undefined,
        min_experience: minExperience > 0 ? minExperience : undefined,
        skill_filter: skillFilter || undefined,
        status: statusFilter || undefined
      });
      setRankedCandidates(data || []);
    } catch (e) {
      console.error("Failed to load ranking", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRanking();
  }, [selectedJobId, sortBy, minScore, minExperience, skillFilter, statusFilter]);

  const handleToggleShortlist = async (appId, currentShortlist) => {
    try {
      await api.applications.toggleShortlist(appId, !currentShortlist);
      fetchRanking();
    } catch (e) {
      alert("Error updating shortlist: " + e.message);
    }
  };

  const currentJob = jobs.find(j => j.id === parseInt(selectedJobId, 10));

  return (
    <div>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.75rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', color: 'var(--cyan)', fontSize: '0.8rem', fontWeight: 700, textTransform: 'uppercase' }}>
            <Sparkles size={14} /> AI Decision Support Engine
          </div>
          <h2 style={{ fontSize: '1.5rem', color: '#FFF', marginTop: '0.2rem' }}>
            Candidate Ranking & Match Matrix
          </h2>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
            Comparative evaluation of all applicants weighted by skills, experience, projects, and certifications.
          </p>
        </div>

        {/* Job Selector Dropdown */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>Target Opening:</span>
          <select
            className="form-select"
            style={{ width: '280px', fontWeight: 600, borderColor: 'var(--border-cyan)' }}
            value={selectedJobId || ''}
            onChange={e => setSelectedJobId(parseInt(e.target.value, 10))}
          >
            {jobs.map(j => (
              <option key={j.id} value={j.id}>
                {j.title} ({j.department})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Filter & Sort Bar */}
      <div className="glass-card" style={{ padding: '1rem 1.25rem', marginBottom: '1.5rem' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '1rem', alignItems: 'center' }}>
          <div>
            <label className="form-label" style={{ fontSize: '0.75rem' }}>Sort Ranking By</label>
            <select className="form-select" value={sortBy} onChange={e => setSortBy(e.target.value)}>
              <option value="ai_score">AI Compatibility Score (Highest)</option>
              <option value="experience">Total Experience (Years)</option>
              <option value="date">Application Submission Date</option>
            </select>
          </div>

          <div>
            <label className="form-label" style={{ fontSize: '0.75rem' }}>Min AI Score ({minScore}%)</label>
            <input
              type="range"
              min="0"
              max="95"
              step="5"
              value={minScore}
              onChange={e => setMinScore(parseInt(e.target.value, 10))}
              style={{ width: '100%', accentColor: 'var(--cyan)' }}
            />
          </div>

          <div>
            <label className="form-label" style={{ fontSize: '0.75rem' }}>Filter By Skill Keyword</label>
            <input
              type="text"
              className="form-input"
              placeholder="e.g. React or Python"
              value={skillFilter}
              onChange={e => setSkillFilter(e.target.value)}
            />
          </div>

          <div>
            <label className="form-label" style={{ fontSize: '0.75rem' }}>Pipeline Status</label>
            <select className="form-select" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
              <option value="">All Statuses</option>
              <option value="APPLIED">Applied</option>
              <option value="RESUME_SCREENING">Resume Screening</option>
              <option value="SHORTLISTED">Shortlisted</option>
              <option value="INTERVIEW_SCHEDULED">Interview Scheduled</option>
              <option value="SELECTED">Selected</option>
            </select>
          </div>
        </div>
      </div>

      {/* Candidates Ranking List */}
      <div className="glass-card" style={{ padding: '1.25rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '0.75rem' }}>
          <div style={{ fontSize: '0.9rem', fontWeight: 700, color: '#FFF' }}>
            Ranked Applicants ({rankedCandidates.length})
          </div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
            Ranked by multi-dimensional match algorithms. Final decisions remain with recruiters.
          </div>
        </div>

        {rankedCandidates.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-secondary)' }}>
            <Trophy size={36} color="var(--text-muted)" style={{ margin: '0 auto 0.75rem' }} />
            <h4 style={{ color: '#FFF' }}>No candidates match the specified filter criteria</h4>
            <p style={{ fontSize: '0.85rem', marginTop: '0.25rem' }}>
              Try lowering the minimum score or clearing skill filters.
            </p>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            {rankedCandidates.map((cand) => {
              const isTop3 = cand.rank <= 3;
              return (
                <div
                  key={cand.application_id}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '1rem 1.25rem',
                    background: isTop3 ? 'rgba(59, 130, 246, 0.05)' : 'var(--bg-primary)',
                    border: isTop3 ? '1px solid rgba(59, 130, 246, 0.3)' : '1px solid var(--border-subtle)',
                    borderRadius: '10px',
                    transition: 'var(--transition-fast)',
                    flexWrap: 'wrap',
                    gap: '1rem'
                  }}
                >
                  {/* Left: Rank badge & Candidate Profile */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: '1.25rem', minWidth: '260px' }}>
                    <div style={{
                      width: '36px',
                      height: '36px',
                      borderRadius: '50%',
                      background: cand.rank === 1 ? '#F59E0B' : (cand.rank === 2 ? '#94A3B8' : (cand.rank === 3 ? '#B45309' : 'rgba(255,255,255,0.08)')),
                      color: cand.rank <= 3 ? '#0F172A' : 'var(--text-secondary)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontWeight: 800,
                      fontSize: '0.9rem',
                      flexShrink: 0
                    }}>
                      #{cand.rank}
                    </div>

                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <span style={{ fontWeight: 700, fontSize: '1rem', color: '#FFF' }}>
                          {cand.candidate_name}
                        </span>
                        {cand.is_shortlisted && (
                          <span className="badge badge-purple" style={{ fontSize: '0.65rem' }}>Shortlisted</span>
                        )}
                      </div>
                      <div style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', marginTop: '0.15rem' }}>
                        {cand.headline || `${cand.total_experience_years} years verified experience`}
                      </div>
                    </div>
                  </div>

                  {/* Center: Matching skills chips preview */}
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem', flex: 1, minWidth: '220px' }}>
                    {cand.matching_skills?.slice(0, 4).map((s, idx) => (
                      <span key={idx} className="skill-chip matching" style={{ fontSize: '0.72rem' }}>
                        {s}
                      </span>
                    ))}
                    {cand.missing_skills?.slice(0, 2).map((s, idx) => (
                      <span key={idx} className="skill-chip missing" style={{ fontSize: '0.72rem' }}>
                        {s} (Gap)
                      </span>
                    ))}
                  </div>

                  {/* Right: AI Score Meter & Interactive Actions */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <AIScoreMeter
                      score={cand.overall_score}
                      onClick={() => setSelectedScore({
                        overall_score: cand.overall_score,
                        skills_match_score: cand.skills_match_score,
                        experience_match_score: cand.experience_match_score,
                        education_match_score: cand.education_match_score,
                        project_match_score: cand.project_match_score,
                        certification_match_score: cand.certification_match_score,
                        matching_skills: JSON.stringify(cand.matching_skills),
                        missing_skills: JSON.stringify(cand.missing_skills),
                        ai_summary: cand.ai_summary,
                        recommendation: cand.recommendation,
                        candidateName: cand.candidate_name,
                        jobTitle: currentJob?.title || "Role"
                      })}
                    />

                    <div style={{ display: 'flex', gap: '0.4rem' }}>
                      <button
                        className={`btn btn-sm ${cand.is_shortlisted ? 'btn-danger' : 'btn-outline'}`}
                        style={{ fontSize: '0.75rem', padding: '0.3rem 0.65rem' }}
                        onClick={() => handleToggleShortlist(cand.application_id, cand.is_shortlisted)}
                      >
                        <CheckCircle2 size={13} />
                        {cand.is_shortlisted ? 'Remove' : 'Shortlist'}
                      </button>
                      <button
                        className="btn btn-primary btn-sm"
                        style={{ fontSize: '0.75rem', padding: '0.3rem 0.65rem' }}
                        onClick={() => setInterviewApplication({
                          id: cand.application_id,
                          candidate_name: cand.candidate_name,
                          job_title: currentJob?.title || "Role"
                        })}
                      >
                        <CalendarCheck size={13} />
                        Schedule
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Breakdown Modal */}
      {selectedScore && (
        <MatchBreakdownModal
          isOpen={!!selectedScore}
          onClose={() => setSelectedScore(null)}
          scoreData={selectedScore}
          candidateName={selectedScore.candidateName}
          jobTitle={selectedScore.jobTitle}
        />
      )}

      {/* Schedule Interview Modal */}
      {interviewApplication && (
        <ScheduleInterviewModal
          isOpen={!!interviewApplication}
          onClose={() => setInterviewApplication(null)}
          application={interviewApplication}
          onScheduled={fetchRanking}
        />
      )}
    </div>
  );
};
