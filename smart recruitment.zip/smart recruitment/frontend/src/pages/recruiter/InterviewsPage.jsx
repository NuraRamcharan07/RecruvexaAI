import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { StatusBadge } from '../../components/common/StatusBadge';
import {
  CalendarCheck,
  Clock,
  Video,
  User,
  ExternalLink,
  MapPin,
  CheckCircle2,
  XCircle,
  Calendar,
  AlertCircle
} from 'lucide-react';

export const InterviewsPage = () => {
  const [interviews, setInterviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('');

  const fetchInterviews = async () => {
    setLoading(true);
    try {
      const data = await api.interviews.list({
        status: statusFilter || undefined
      });
      setInterviews(data || []);
    } catch (e) {
      console.error("Failed to load interviews", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInterviews();
  }, [statusFilter]);

  const handleMarkCompleted = async (id) => {
    try {
      await api.interviews.update(id, {
        status: 'COMPLETED',
        feedback: 'Candidate successfully attended interview session.'
      });
      fetchInterviews();
    } catch (e) {
      alert("Error completing interview: " + e.message);
    }
  };

  const handleCancel = async (id) => {
    const reason = window.prompt("Reason for cancellation:");
    if (reason !== null) {
      try {
        await api.interviews.cancel(id, reason);
        fetchInterviews();
      } catch (e) {
        alert("Error cancelling interview: " + e.message);
      }
    }
  };

  return (
    <div>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.75rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', color: '#FFF' }}>Interviews & Scheduling Desk</h2>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
            Coordinate technical reviews, panel screenings, and track interview feedback
          </p>
        </div>

        <div style={{ width: '200px' }}>
          <select
            className="form-select"
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
          >
            <option value="">All Statuses</option>
            <option value="SCHEDULED">Scheduled / Active</option>
            <option value="COMPLETED">Completed</option>
            <option value="CANCELLED">Cancelled</option>
          </select>
        </div>
      </div>

      {/* Interviews Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '1.25rem' }}>
        {interviews.length === 0 ? (
          <div className="glass-card" style={{ gridColumn: '1 / -1', textAlign: 'center', padding: '3rem' }}>
            <CalendarCheck size={36} color="var(--text-muted)" style={{ margin: '0 auto 0.75rem' }} />
            <h4 style={{ color: '#FFF' }}>No interviews scheduled</h4>
            <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', marginTop: '0.25rem' }}>
              Schedule interviews directly from Candidate Ranking or Applications Pipeline.
            </p>
          </div>
        ) : (
          interviews.map(itv => (
            <div key={itv.id} className="glass-card" style={{ display: 'flex', flexDirection: 'column' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '0.5rem', marginBottom: '0.75rem' }}>
                <div>
                  <span className="badge badge-cyan" style={{ fontSize: '0.7rem', marginBottom: '0.35rem' }}>
                    {itv.interview_type?.replace('_', ' ')}
                  </span>
                  <h3 style={{ fontSize: '1.1rem', color: '#FFF', lineHeight: 1.3 }}>
                    {itv.title}
                  </h3>
                  <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginTop: '0.2rem' }}>
                    Candidate: <strong style={{ color: '#FFF' }}>{itv.candidate_name}</strong> &bull; {itv.job_title}
                  </div>
                </div>
                <StatusBadge status={itv.status} type="interview" />
              </div>

              {/* Date & Time Ribbon */}
              <div style={{
                background: 'var(--bg-primary)',
                padding: '0.75rem 1rem',
                borderRadius: '8px',
                border: '1px solid var(--border-subtle)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: '1rem'
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.85rem', color: '#FFF' }}>
                  <Calendar size={15} color="var(--primary)" />
                  <strong>{itv.scheduled_date}</strong>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.85rem', color: 'var(--cyan)' }}>
                  <Clock size={15} />
                  <strong>{itv.scheduled_time} ({itv.duration_minutes}m)</strong>
                </div>
              </div>

              {/* Interviewer & Location */}
              <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', display: 'flex', flexDirection: 'column', gap: '0.4rem', marginBottom: '1.25rem', flex: 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  <User size={14} color="var(--text-muted)" />
                  <span>Interviewer: <strong style={{ color: '#FFF' }}>{itv.interviewer_name}</strong></span>
                </div>
                {itv.location && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                    <MapPin size={14} color="var(--text-muted)" />
                    <span>{itv.location}</span>
                  </div>
                )}
                {itv.notes && (
                  <div style={{ fontStyle: 'italic', color: 'var(--text-muted)', marginTop: '0.25rem' }}>
                    "{itv.notes}"
                  </div>
                )}
              </div>

              {/* Action Buttons Footer */}
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderTop: '1px solid var(--border-subtle)', paddingTop: '0.85rem' }}>
                {itv.meeting_link ? (
                  <a
                    href={itv.meeting_link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-primary btn-sm"
                    style={{ fontSize: '0.75rem', padding: '0.3rem 0.75rem' }}
                  >
                    <Video size={13} />
                    Join Video Link
                    <ExternalLink size={12} />
                  </a>
                ) : (
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Onsite / Local</span>
                )}

                {itv.status === 'SCHEDULED' && (
                  <div style={{ display: 'flex', gap: '0.35rem' }}>
                    <button
                      className="btn btn-outline btn-sm"
                      style={{ fontSize: '0.75rem', padding: '0.3rem 0.6rem', color: '#10B981' }}
                      onClick={() => handleMarkCompleted(itv.id)}
                      title="Mark interview completed"
                    >
                      <CheckCircle2 size={13} /> Completed
                    </button>
                    <button
                      className="btn btn-danger btn-sm"
                      style={{ fontSize: '0.75rem', padding: '0.3rem 0.6rem' }}
                      onClick={() => handleCancel(itv.id)}
                      title="Cancel interview"
                    >
                      <XCircle size={13} /> Cancel
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
