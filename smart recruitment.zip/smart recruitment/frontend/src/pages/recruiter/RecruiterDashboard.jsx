import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { AIScoreMeter } from '../../components/ai/AIScoreMeter';
import { StatusBadge } from '../../components/common/StatusBadge';
import { MatchBreakdownModal } from '../../components/ai/MatchBreakdownModal';
import { ScheduleInterviewModal } from '../../components/interviews/ScheduleInterviewModal';
import {
  Briefcase,
  Users,
  FileCheck2,
  CalendarCheck,
  Award,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Clock,
  Plus
} from 'lucide-react';

export const RecruiterDashboard = ({ onNavigate, onOpenJobModal }) => {
  const [analytics, setAnalytics] = useState(null);
  const [recentApplications, setRecentApplications] = useState([]);
  const [loading, setLoading] = useState(true);

  // Modals
  const [selectedScore, setSelectedScore] = useState(null);
  const [selectedAppForInterview, setSelectedAppForInterview] = useState(null);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [analyticsData, appsData] = await Promise.all([
        api.analytics.getDashboard(),
        api.applications.list()
      ]);
      setAnalytics(analyticsData);
      setRecentApplications(appsData.slice(0, 6));
    } catch (e) {
      console.error("Dashboard load failed:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const statCards = [
    { label: 'Total Jobs', value: analytics?.total_jobs || 0, icon: Briefcase, color: '#3B82F6', change: '+2 active' },
    { label: 'Total Applicants', value: analytics?.total_applications || 0, icon: Users, color: '#06B6D4', change: '+5 this week' },
    { label: 'Shortlisted', value: analytics?.shortlisted_candidates || 0, icon: FileCheck2, color: '#8B5CF6', change: `${analytics?.shortlisting_rate || 0}% rate` },
    { label: 'Scheduled Interviews', value: analytics?.scheduled_interviews || 0, icon: CalendarCheck, color: '#F59E0B', change: 'Live pipeline' },
    { label: 'Selected / Hired', value: analytics?.selected_candidates || 0, icon: Award, color: '#10B981', change: 'Final selection' },
  ];

  return (
    <div>
      {/* Top Welcome Action Banner */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        background: 'linear-gradient(135deg, rgba(17, 28, 56, 0.9) 0%, rgba(22, 36, 71, 0.9) 100%)',
        border: '1px solid var(--border-subtle)',
        borderRadius: '14px',
        padding: '1.5rem',
        marginBottom: '2rem',
        flexWrap: 'wrap',
        gap: '1rem'
      }}>
        <div>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', color: 'var(--cyan)', fontSize: '0.8rem', fontWeight: 700, textTransform: 'uppercase' }}>
            <Sparkles size={14} /> Recruiter Intelligence Hub
          </div>
          <h2 style={{ fontSize: '1.6rem', color: '#FFF', marginTop: '0.25rem' }}>
            Recruitment Command Center
          </h2>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem' }}>
            Monitor real-time candidate applications, review AI screening rankings, and coordinate interviews.
          </p>
        </div>
        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <button className="btn btn-outline btn-sm" onClick={() => onNavigate('recruiter-screening')}>
            <Sparkles size={15} color="var(--cyan)" />
            AI Candidate Ranking
          </button>
          <button className="btn btn-primary btn-sm" onClick={onOpenJobModal}>
            <Plus size={15} />
            Post New Job Opening
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1.25rem', marginBottom: '2rem' }}>
        {statCards.map((c, i) => {
          const Icon = c.icon;
          return (
            <div key={i} className="glass-card">
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
                <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', fontWeight: 600 }}>{c.label}</span>
                <div style={{ width: '32px', height: '32px', borderRadius: '8px', background: `${c.color}20`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: c.color }}>
                  <Icon size={16} />
                </div>
              </div>
              <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#FFF', fontFamily: 'var(--font-display)' }}>
                {c.value}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '0.35rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                <TrendingUp size={12} color="#10B981" />
                {c.change}
              </div>
            </div>
          );
        })}
      </div>

      {/* Funnel & Quick Timeline Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '1.5rem', marginBottom: '2rem' }}>
        {/* Recruitment Funnel */}
        <div className="glass-card">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
            <h3 style={{ fontSize: '1.05rem', color: '#FFF', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <TrendingUp size={16} color="var(--cyan)" />
              Candidate Recruitment Funnel
            </h3>
            <button className="btn btn-outline btn-sm" style={{ fontSize: '0.72rem', padding: '0.2rem 0.5rem' }} onClick={() => onNavigate('recruiter-analytics')}>
              Deep Analytics
            </button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
            {analytics?.hiring_funnel?.map((step, idx) => (
              <div key={idx}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', marginBottom: '0.3rem' }}>
                  <span style={{ color: '#FFF', fontWeight: 600 }}>{step.stage}</span>
                  <span style={{ color: 'var(--text-secondary)' }}>
                    <strong>{step.count}</strong> candidates ({step.percentage}%)
                  </span>
                </div>
                <div style={{ height: '8px', background: 'var(--bg-primary)', borderRadius: '4px', overflow: 'hidden' }}>
                  <div style={{
                    width: `${Math.max(6, step.percentage)}%`,
                    height: '100%',
                    background: idx === 0 ? '#3B82F6' : (idx === 1 ? '#06B6D4' : (idx === 2 ? '#8B5CF6' : (idx === 3 ? '#F59E0B' : '#10B981'))),
                    borderRadius: '4px',
                    transition: 'width 0.5s ease'
                  }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Demanded Skills & Quick Ratios */}
        <div className="glass-card">
          <h3 style={{ fontSize: '1.05rem', color: '#FFF', marginBottom: '1.25rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Sparkles size={16} color="var(--primary)" />
            Top In-Demand Candidate Skills
          </h3>

          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.6rem', marginBottom: '1.75rem' }}>
            {analytics?.top_demanded_skills?.map((item, idx) => (
              <div
                key={idx}
                style={{
                  background: 'var(--bg-primary)',
                  border: '1px solid var(--border-subtle)',
                  borderRadius: '8px',
                  padding: '0.5rem 0.85rem',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.5rem'
                }}
              >
                <span style={{ fontSize: '0.85rem', fontWeight: 600, color: '#FFF' }}>{item.skill}</span>
                <span className="badge badge-blue" style={{ fontSize: '0.7rem' }}>{item.demand_count} jobs</span>
              </div>
            ))}
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem', borderTop: '1px solid var(--border-subtle)', paddingTop: '1rem' }}>
            <div style={{ background: 'var(--bg-primary)', padding: '0.75rem', borderRadius: '8px' }}>
              <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>Avg Time to Shortlist</div>
              <div style={{ fontSize: '1.15rem', fontWeight: 700, color: '#38BDF8', marginTop: '0.2rem' }}>
                {analytics?.avg_time_to_shortlist_days || 3.2} Days
              </div>
            </div>
            <div style={{ background: 'var(--bg-primary)', padding: '0.75rem', borderRadius: '8px' }}>
              <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>Avg Time to Hire</div>
              <div style={{ fontSize: '1.15rem', fontWeight: 700, color: '#10B981', marginTop: '0.2rem' }}>
                {analytics?.avg_time_to_hire_days || 16.8} Days
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Applications with AI Scores Table */}
      <div className="glass-card">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
          <div>
            <h3 style={{ fontSize: '1.1rem', color: '#FFF' }}>Recent Applications & AI Screening</h3>
            <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
              Top candidates evaluated against job criteria with real-time match scores.
            </p>
          </div>
          <button className="btn btn-outline btn-sm" onClick={() => onNavigate('recruiter-applications')}>
            View All Pipeline ({analytics?.total_applications || 0})
            <ArrowRight size={14} />
          </button>
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border-subtle)', color: 'var(--text-muted)' }}>
                <th style={{ padding: '0.75rem 1rem', fontWeight: 600 }}>Candidate</th>
                <th style={{ padding: '0.75rem 1rem', fontWeight: 600 }}>Target Job</th>
                <th style={{ padding: '0.75rem 1rem', fontWeight: 600 }}>Experience</th>
                <th style={{ padding: '0.75rem 1rem', fontWeight: 600 }}>AI Match Score</th>
                <th style={{ padding: '0.75rem 1rem', fontWeight: 600 }}>Status</th>
                <th style={{ padding: '0.75rem 1rem', fontWeight: 600, textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {recentApplications.map((app) => (
                <tr key={app.id} style={{ borderBottom: '1px solid rgba(255,255,255,0.04)', transition: 'background 0.15s' }}>
                  <td style={{ padding: '0.85rem 1rem' }}>
                    <div style={{ fontWeight: 600, color: '#FFF' }}>{app.candidate_name}</div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{app.candidate_email}</div>
                  </td>
                  <td style={{ padding: '0.85rem 1rem', color: 'var(--text-secondary)' }}>
                    {app.job_title}
                  </td>
                  <td style={{ padding: '0.85rem 1rem', color: '#FFF' }}>
                    {app.total_experience_years} Yrs
                  </td>
                  <td style={{ padding: '0.85rem 1rem' }}>
                    <AIScoreMeter
                      score={app.overall_match_score}
                      onClick={() => {
                        if (app.screening_score) {
                          setSelectedScore({
                            ...app.screening_score,
                            candidateName: app.candidate_name,
                            jobTitle: app.job_title
                          });
                        }
                      }}
                    />
                  </td>
                  <td style={{ padding: '0.85rem 1rem' }}>
                    <StatusBadge status={app.status} type="application" />
                  </td>
                  <td style={{ padding: '0.85rem 1rem', textAlign: 'right' }}>
                    <div style={{ display: 'inline-flex', gap: '0.4rem' }}>
                      <button
                        className="btn btn-outline btn-sm"
                        style={{ fontSize: '0.75rem', padding: '0.25rem 0.6rem' }}
                        onClick={() => setSelectedAppForInterview(app)}
                      >
                        Schedule
                      </button>
                      {app.screening_score && (
                        <button
                          className="btn btn-secondary btn-sm"
                          style={{ fontSize: '0.75rem', padding: '0.25rem 0.6rem', color: 'var(--cyan)' }}
                          onClick={() => setSelectedScore({
                            ...app.screening_score,
                            candidateName: app.candidate_name,
                            jobTitle: app.job_title
                          })}
                        >
                          Insights
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modals */}
      {selectedScore && (
        <MatchBreakdownModal
          isOpen={!!selectedScore}
          onClose={() => setSelectedScore(null)}
          scoreData={selectedScore}
          candidateName={selectedScore.candidateName}
          jobTitle={selectedScore.jobTitle}
        />
      )}

      {selectedAppForInterview && (
        <ScheduleInterviewModal
          isOpen={!!selectedAppForInterview}
          onClose={() => setSelectedAppForInterview(null)}
          application={selectedAppForInterview}
          onScheduled={fetchData}
        />
      )}
    </div>
  );
};
