import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { Users, Search, MapPin, Briefcase, ExternalLink, Mail, Phone, Sparkles } from 'lucide-react';

export const CandidatesPoolPage = () => {
  const [candidates, setCandidates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [minExp, setMinExp] = useState('');

  const fetchCandidates = async () => {
    setLoading(true);
    try {
      const data = await api.candidates.list({
        q: searchQuery,
        min_experience: minExp ? parseFloat(minExp) : undefined
      });
      setCandidates(data || []);
    } catch (e) {
      console.error("Failed to load candidates pool", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCandidates();
  }, [searchQuery, minExp]);

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.75rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', color: '#FFF' }}>Candidate Talent Directory</h2>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
            Search verified talent pool by technical domain, years of experience, and skills
          </p>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="glass-card" style={{ padding: '1rem 1.25rem', marginBottom: '1.5rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', flexWrap: 'wrap' }}>
          <div style={{ position: 'relative', flex: 1, minWidth: '240px' }}>
            <input
              type="text"
              className="form-input"
              placeholder="Search candidate name, headline, skills..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              style={{ paddingLeft: '2.5rem' }}
            />
            <Search size={16} color="var(--text-muted)" style={{ position: 'absolute', left: '0.85rem', top: '50%', transform: 'translateY(-50%)' }} />
          </div>

          <div style={{ width: '180px' }}>
            <select
              className="form-select"
              value={minExp}
              onChange={e => setMinExp(e.target.value)}
            >
              <option value="">Any Experience</option>
              <option value="2">2+ Years</option>
              <option value="4">4+ Years</option>
              <option value="6">6+ Years</option>
            </select>
          </div>
        </div>
      </div>

      {/* Candidates Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: '1.25rem' }}>
        {candidates.map(cand => {
          const profile = cand.candidate_profile;
          return (
            <div key={cand.id} className="glass-card" style={{ display: 'flex', flexDirection: 'column' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '1rem', marginBottom: '1rem' }}>
                <div style={{
                  width: '44px',
                  height: '44px',
                  borderRadius: '50%',
                  background: 'linear-gradient(135deg, #3B82F6, #06B6D4)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontWeight: 800,
                  fontSize: '1rem',
                  color: '#FFF',
                  flexShrink: 0
                }}>
                  {cand.full_name?.charAt(0)}
                </div>
                <div>
                  <h3 style={{ fontSize: '1.1rem', color: '#FFF' }}>{cand.full_name}</h3>
                  <div style={{ fontSize: '0.8rem', color: 'var(--cyan)', fontWeight: 500 }}>
                    {profile?.headline || 'Professional Candidate'}
                  </div>
                  {profile?.location && (
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.25rem', marginTop: '0.2rem' }}>
                      <MapPin size={12} /> {profile.location}
                    </div>
                  )}
                </div>
              </div>

              {profile?.summary && (
                <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', lineHeight: 1.5, marginBottom: '1rem', flex: 1 }}>
                  {profile.summary}
                </p>
              )}

              {/* Skills Tags */}
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem', marginBottom: '1.25rem' }}>
                {profile?.skills_text?.split(',').slice(0, 6).map((s, idx) => (
                  <span key={idx} className="skill-chip">{s.trim()}</span>
                ))}
              </div>

              {/* Footer */}
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderTop: '1px solid var(--border-subtle)', paddingTop: '0.85rem', fontSize: '0.78rem', color: 'var(--text-muted)' }}>
                <span>{profile?.total_experience_years || 0} Yrs Experience</span>
                <span style={{ color: '#10B981', fontWeight: 600 }}>Active Profile</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
