import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { StatusBadge } from '../../components/common/StatusBadge';
import { JobFormModal } from '../../components/jobs/JobFormModal';
import {
  Briefcase,
  Plus,
  Search,
  Users,
  Copy,
  Edit2,
  Trash2,
  Eye,
  Sparkles,
  Check,
  Power
} from 'lucide-react';

export const JobsManagementPage = ({ onNavigateToRanking }) => {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('');
  const [editingJob, setEditingJob] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const fetchJobs = async () => {
    setLoading(true);
    try {
      const data = await api.jobs.list({
        q: searchQuery,
        department: departmentFilter,
        recruiter_only: true
      });
      setJobs(data.items || []);
    } catch (e) {
      console.error("Failed to load jobs", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchJobs();
  }, [searchQuery, departmentFilter]);

  const handleDuplicate = async (id) => {
    try {
      await api.jobs.duplicate(id);
      fetchJobs();
    } catch (e) {
      alert("Failed to duplicate job: " + e.message);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this job posting?")) {
      try {
        await api.jobs.delete(id);
        fetchJobs();
      } catch (e) {
        alert("Failed to delete job: " + e.message);
      }
    }
  };

  const handleToggleStatus = async (job) => {
    const nextStatus = job.status === 'PUBLISHED' ? 'CLOSED' : 'PUBLISHED';
    try {
      await api.jobs.setStatus(job.id, nextStatus);
      fetchJobs();
    } catch (e) {
      alert("Failed to update status: " + e.message);
    }
  };

  return (
    <div>
      {/* Header Controls */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.75rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h2 style={{ fontSize: '1.5rem', color: '#FFF' }}>Job Openings Management</h2>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
            Publish, edit, and track job postings across departments
          </p>
        </div>
        <button
          className="btn btn-primary"
          onClick={() => {
            setEditingJob(null);
            setIsModalOpen(true);
          }}
        >
          <Plus size={16} />
          Create New Job Opening
        </button>
      </div>

      {/* Filter Bar */}
      <div className="glass-card" style={{ padding: '1rem 1.25rem', marginBottom: '1.5rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', flexWrap: 'wrap' }}>
          <div style={{ position: 'relative', flex: 1, minWidth: '220px' }}>
            <input
              type="text"
              className="form-input"
              placeholder="Search by job title or required skills..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              style={{ paddingLeft: '2.5rem' }}
            />
            <Search size={16} color="var(--text-muted)" style={{ position: 'absolute', left: '0.85rem', top: '50%', transform: 'translateY(-50%)' }} />
          </div>

          <div style={{ width: '200px' }}>
            <select
              className="form-select"
              value={departmentFilter}
              onChange={e => setDepartmentFilter(e.target.value)}
            >
              <option value="">All Departments</option>
              <option value="Engineering">Engineering</option>
              <option value="AI">AI Research</option>
              <option value="Product">Product Design</option>
              <option value="Infrastructure">Infrastructure</option>
            </select>
          </div>
        </div>
      </div>

      {/* Jobs Grid / Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '1.25rem' }}>
        {jobs.length === 0 ? (
          <div className="glass-card" style={{ gridColumn: '1 / -1', textAlign: 'center', padding: '3rem' }}>
            <Briefcase size={36} color="var(--text-muted)" style={{ margin: '0 auto 1rem' }} />
            <h3 style={{ color: '#FFF', fontSize: '1.1rem' }}>No job openings found</h3>
            <p style={{ color: 'var(--text-secondary)', fontSize: '0.85rem', marginTop: '0.35rem' }}>
              Create your first job posting to start receiving AI-screened candidate applications.
            </p>
          </div>
        ) : (
          jobs.map(job => (
            <div key={job.id} className="glass-card" style={{ display: 'flex', flexDirection: 'column' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '0.5rem', marginBottom: '0.75rem' }}>
                <div>
                  <span className="badge badge-blue" style={{ fontSize: '0.7rem', marginBottom: '0.35rem' }}>
                    {job.department}
                  </span>
                  <h3 style={{ fontSize: '1.15rem', color: '#FFF', lineHeight: 1.3 }}>
                    {job.title}
                  </h3>
                  <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginTop: '0.2rem' }}>
                    {job.location} &bull; {job.employment_type?.replace('_', ' ')}
                  </div>
                </div>
                <StatusBadge status={job.status} type="job" />
              </div>

              {/* Salary & Exp */}
              <div style={{ background: 'var(--bg-primary)', padding: '0.65rem 0.85rem', borderRadius: '8px', display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', marginBottom: '0.85rem' }}>
                <div>
                  <span style={{ color: 'var(--text-muted)' }}>Experience: </span>
                  <strong style={{ color: '#FFF' }}>{job.experience_required}+ Yrs</strong>
                </div>
                <div>
                  <span style={{ color: 'var(--text-muted)' }}>Salary: </span>
                  <strong style={{ color: 'var(--cyan)' }}>
                    {job.min_salary ? `$${job.min_salary.toLocaleString()} - $${job.max_salary?.toLocaleString()}` : 'Competitive'}
                  </strong>
                </div>
              </div>

              {/* Skills preview */}
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.35rem', marginBottom: '1.25rem', flex: 1 }}>
                {job.required_skills?.split(',').slice(0, 5).map((s, idx) => (
                  <span key={idx} className="skill-chip">{s.trim()}</span>
                ))}
              </div>

              {/* Stats & Actions Footer */}
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderTop: '1px solid var(--border-subtle)', paddingTop: '0.85rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', fontSize: '0.78rem', color: 'var(--text-secondary)' }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                    <Users size={14} color="var(--primary)" />
                    <strong>{job.applications_count || 0}</strong> Applicants
                  </span>
                  <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                    <Eye size={14} color="var(--text-muted)" />
                    {job.views_count || 0} Views
                  </span>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                  <button
                    className="btn btn-cyan btn-sm"
                    style={{ fontSize: '0.75rem', padding: '0.25rem 0.6rem' }}
                    onClick={() => onNavigateToRanking(job.id)}
                    title="View candidate ranking"
                  >
                    <Sparkles size={13} />
                    Rank Candidates
                  </button>
                  <button
                    className="btn btn-outline btn-sm"
                    style={{ padding: '0.3rem', borderRadius: '6px' }}
                    onClick={() => {
                      setEditingJob(job);
                      setIsModalOpen(true);
                    }}
                    title="Edit Opening"
                  >
                    <Edit2 size={13} />
                  </button>
                  <button
                    className="btn btn-outline btn-sm"
                    style={{ padding: '0.3rem', borderRadius: '6px' }}
                    onClick={() => handleDuplicate(job.id)}
                    title="Duplicate Opening"
                  >
                    <Copy size={13} />
                  </button>
                  <button
                    className="btn btn-outline btn-sm"
                    style={{ padding: '0.3rem', borderRadius: '6px', color: job.status === 'PUBLISHED' ? '#F59E0B' : '#10B981' }}
                    onClick={() => handleToggleStatus(job)}
                    title={job.status === 'PUBLISHED' ? 'Close Opening' : 'Publish Opening'}
                  >
                    <Power size={13} />
                  </button>
                  <button
                    className="btn btn-danger btn-sm"
                    style={{ padding: '0.3rem', borderRadius: '6px' }}
                    onClick={() => handleDelete(job.id)}
                    title="Delete Opening"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      <JobFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        job={editingJob}
        onSaved={fetchJobs}
      />
    </div>
  );
};
