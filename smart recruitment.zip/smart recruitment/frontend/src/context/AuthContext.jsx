import React, { createContext, useContext, useState, useEffect } from 'react';
import { api } from '../services/api';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('recruvexa_token'));
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const initAuth = async () => {
      const storedToken = localStorage.getItem('recruvexa_token');
      if (storedToken) {
        try {
          const userData = await api.auth.getMe();
          setUser(userData);
        } catch (err) {
          console.error("Session restoration failed:", err);
          localStorage.removeItem('recruvexa_token');
          setToken(null);
          setUser(null);
        }
      }
      setLoading(false);
    };

    initAuth();
  }, []);

  const login = async (email, password) => {
    setError(null);
    try {
      const data = await api.auth.login(email, password);
      localStorage.setItem('recruvexa_token', data.access_token);
      setToken(data.access_token);
      setUser(data.user);
      return data.user;
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  const register = async (userData) => {
    setError(null);
    try {
      const data = await api.auth.register(userData);
      localStorage.setItem('recruvexa_token', data.access_token);
      setToken(data.access_token);
      setUser(data.user);
      return data.user;
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  const logout = () => {
    try {
      api.auth.logout();
    } catch (e) {
      // Ignore network failure on logout
    }
    localStorage.removeItem('recruvexa_token');
    setToken(null);
    setUser(null);
  };

  const fastLogin = async (role) => {
    let email = 'sarah.recruiter@apextech.io';
    let password = 'Recruiter123!';
    if (role === 'CANDIDATE') {
      email = 'alex.rivers@example.com';
      password = 'Candidate123!';
    } else if (role === 'ADMIN') {
      email = 'admin@recruvexa.ai';
      password = 'Admin123!';
    }
    return await login(email, password);
  };

  const refreshUser = async () => {
    try {
      const userData = await api.auth.getMe();
      setUser(userData);
    } catch (err) {
      console.error("Failed to refresh user:", err);
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      token,
      isAuthenticated: !!user,
      role: user?.role,
      loading,
      error,
      login,
      register,
      logout,
      fastLogin,
      refreshUser
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
