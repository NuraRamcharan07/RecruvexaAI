# RECRUVEXA AI
### *Intelligent Recruitment. Faster Decisions. Better Talent.*

RecruVexa AI is an enterprise-grade, modern AI-assisted smart recruitment and resume screening SaaS platform that streamlines the complete hiring workflow by combining job posting, resume document management, AI-assisted resume screening, candidate ranking, interview scheduling, and recruitment analytics.

---

## 🌟 Key Product Capabilities

- **Phase 1 — Complete HR Recruitment Lifecycle:** Job Creation → Published → Applications → Resume Screening → AI Analysis → Candidate Ranking → Shortlisting → Interview Scheduling → Selection / Rejection → Hiring Analytics.
- **Phase 2 — Multi-Format Resume Management:** Extract text from PDF, DOCX, DOC, and TXT files, extracting candidate names, contact information, skills, years of experience, education degrees, certifications, and portfolio projects.
- **Phase 3 & 4 — AI-Assisted Candidate Screening:** Multi-dimensional compatibility evaluation with 5-pillar breakdown (Skills Match %, Experience Match %, Education Match %, Project Match %, Certification Match %) plus matching skills, missing skills, potential concerns, and executive AI summary.
- **Phase 5 — Intelligent Candidate Ranking:** Dynamic candidate leaderboard sorted by AI score, verified experience, or application date with precision filters.
- **Phase 6 — Candidate Portal:** Modern candidate dashboard featuring real-time visual application progress steppers, scheduled interview details, 1-click apply, and resume document management.
- **Phase 7 — Interview Scheduling System:** Technical, HR, Managerial, and Video interview management with automated conflict detection, Google Meet / Zoom conference integration, and calendar tracking.
- **Phase 8 & 10 — Recruiter Dashboard & Analytics:** High-level metrics, live recruitment funnel (`Applied` → `Screened` → `Shortlisted` → `Interviewed` → `Selected`), timeline activity trends, and skill demand distributions.
- **Phase 11 — Master Admin Console:** User governance directory, system health diagnostics, and dynamic AI scoring weight calibration.
- **Responsible AI Principles:** AI scores act strictly as assistive decision-support tools with transparent breakdowns and zero automated black-box rejections.

---

## 🏗️ Technology Architecture

- **Backend:** Python 3.12, FastAPI, Pydantic v2, SQLAlchemy 2.0, Uvicorn, Python-Jose (JWT), Bcrypt, PyPDF, Python-Docx.
- **Database:** PostgreSQL support with instant zero-friction SQLite fallback (`sqlite:///./recruvexa.db`) for immediate offline running.
- **AI Engine:** Modular architecture (`resume_parser.py`, `resume_analyzer.py`, `candidate_matcher.py`, `scoring_engine.py`) with deterministic NLP heuristic matching + pluggable external LLM support.
- **Frontend:** React 18, Vite 5, Lucide Icons, Ultra-Premium Vanilla CSS Design System with dark navy glassmorphism, Google Fonts (`Outfit` and `Inter`), and micro-animations.

---

## 🚀 Quick Start Guide

### Prerequisites
- Python 3.11 or 3.12
- Node.js 18+ or 20+ LTS

---

### Step 1: Backend Setup & Startup

1. Open a terminal in the project root:
   ```bash
   cd backend
   ```

2. Create virtual environment and install dependencies:
   ```bash
   python -m venv .venv
   # Windows:
   .venv\Scripts\activate
   # Linux/macOS:
   source .venv/bin/activate

   pip install -r requirements.txt
   ```

3. Launch the FastAPI server (automatically initializes database tables and seeds demo data on first start):
   ```bash
   python run.py
   ```
   *The REST API will be live at `http://127.0.0.1:8000`*  
   *Interactive Swagger Documentation: `http://127.0.0.1:8000/docs`*

   ---

### Step 2: Frontend Setup & Startup

1. Open a second terminal:
   ```bash
   cd frontend
   npm install
   npm run dev
   ```
   *The React Web Application will be live at `http://127.0.0.1:5173`*

---

## 🔑 Pre-Configured Demo Accounts

For immediate evaluation, the platform includes pre-populated enterprise data with instant **1-Click Demo Login** buttons on the Login page:

| Role | Email | Password | Persona & Company |
| :--- | :--- | :--- | :--- |
| **Recruiter** | `sarah.recruiter@apextech.io` | `Recruiter123!` | Sarah Jenkins — Director of Talent, Apex Innovations |
| **Candidate** | `alex.rivers@example.com` | `Candidate123!` | Alex Rivers — Senior Full-Stack Engineer |
| **Administrator** | `admin@recruvexa.ai` | `Admin123!` | Alexander Vance — Platform Administrator |

---

## 🧪 Running Automated Tests

A comprehensive suite of 14 integration and unit tests covering authentication, job posting, AI screening, candidate matching, and interview conflict validation is included:

```bash
cd backend
.venv\Scripts\pytest tests -v
```

---

## 📁 Repository Structure

```
smart-recruitment/
├── backend/
│   ├── app/
│   │   ├── api/             # REST endpoints (auth, jobs, applications, screening, interviews, analytics, admin)
│   │   ├── core/            # Config, JWT tokens, direct bcrypt security
│   │   ├── database/        # SQLAlchemy engine & session management
│   │   ├── models/          # 10+ Relational database models
│   │   ├── schemas/         # Pydantic schemas for request validation & responses
│   │   ├── services/ai/     # Dedicated AI parser, scorer, and matcher
│   │   └── utils/           # Database seeding script with realistic hiring data
│   ├── tests/               # Pytest automated test suite
│   ├── requirements.txt
│   └── run.py               # Fast backend runner script
├── frontend/
│   ├── src/
│   │   ├── components/      # Common UI, AI score meters, modals, badges
│   │   ├── context/         # AuthContext with 1-click fast demo switching
│   │   ├── pages/           # Landing page, Recruiter suite, Candidate portal, Admin console
│   │   ├── services/        # Centralized API client
│   │   ├── styles/          # Ultra-premium Vanilla CSS design system
│   │   ├── App.jsx          # Role-based dashboard routing
│   │   └── main.jsx
│   ├── package.json
│   └── vite.config.js       # Configured with proxy to port 8000
├── docs/
│   └── API_DOCUMENTATION.md # Detailed endpoint specifications
├── docker-compose.yml       # Production container orchestration
├── .env.example
└── README.md
```

---

## ⚖️ Responsible AI Notice

RecruVexa AI is strictly designed as an **assistive decision-support system**.
- AI match scores represent multi-pillar compatibility evaluations against stated requirements.
- No applicant is ever automatically disqualified or rejected without human recruiter review.
- Transparency is guaranteed through detailed factor breakdowns and highlighted potential verification areas.
