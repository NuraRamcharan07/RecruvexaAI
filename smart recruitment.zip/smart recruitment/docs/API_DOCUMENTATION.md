# RecruVexa AI — REST API Documentation

**Interactive Swagger UI:** `http://127.0.0.1:8000/docs`  
**Alternative ReDoc:** `http://127.0.0.1:8000/redoc`

---

## 1. Authentication (`/api/auth`)

### `POST /api/auth/register`
Creates a new account (`RECRUITER`, `CANDIDATE`, or `ADMIN`).
- **Body:**
  ```json
  {
    "email": "user@example.com",
    "password": "Password123!",
    "full_name": "Full Name",
    "role": "RECRUITER",
    "phone": "+1 555-0100",
    "company_name": "TechCorp",
    "industry": "Software",
    "designatory_title": "Head of Talent"
  }
  ```
- **Response:** `201 Created` with JWT `access_token` and user object.

### `POST /api/auth/login`
Authenticates email and password.
- **Body:**
  ```json
  {
    "email": "sarah.recruiter@apextech.io",
    "password": "Recruiter123!"
  }
  ```
- **Response:** `200 OK` with JWT bearer token.

### `GET /api/auth/me`
Returns currently authenticated user profile and nested Recruiter/Candidate profile data.

---

## 2. Jobs (`/api/jobs`)

### `GET /api/jobs`
List job postings with multi-parameter filtering:
- Query parameters:
  - `q`: Search keyword in title, description, skills
  - `department`: Filter by department (e.g. Engineering, AI)
  - `employment_type`: `FULL_TIME`, `PART_TIME`, `REMOTE`, `HYBRID`, etc.
  - `location`: Filter location
  - `status`: `PUBLISHED`, `DRAFT`, `CLOSED`
  - `recruiter_only`: Boolean flag to retrieve only current recruiter's jobs

### `POST /api/jobs`
Publish a new job opening (Authorized: Recruiter / Admin).
- **Body:**
  ```json
  {
    "title": "Senior AI Infrastructure Engineer",
    "department": "Engineering",
    "location": "San Francisco, CA (Hybrid)",
    "employment_type": "FULL_TIME",
    "experience_required": 4.0,
    "min_salary": 140000,
    "max_salary": 180000,
    "salary_currency": "USD",
    "description": "Architect high-performance inference pipelines...",
    "responsibilities": "Design low-latency microservices...",
    "required_skills": "Python, FastAPI, Docker, Kubernetes, AWS",
    "preferred_skills": "Redis, Kafka, Terraform",
    "education_requirements": "Bachelor's degree in CS",
    "status": "PUBLISHED"
  }
  ```

### `GET /api/jobs/{id}`
Returns job details and increments view analytics counter.

### `PUT /api/jobs/{id}`
Updates existing job opening.

### `DELETE /api/jobs/{id}`
Removes job posting.

### `POST /api/jobs/{id}/duplicate`
Clones job as a new Draft.

### `POST /api/jobs/{id}/status?status=CLOSED`
Transitions job between `PUBLISHED`, `CLOSED`, and `DRAFT`.

---

## 3. Resumes & Document Processing (`/api/resumes`)

### `POST /api/resumes/upload`
Uploads PDF, DOCX, DOC, or TXT file (`multipart/form-data`).
- Extracts raw text using `pypdf` / `python-docx`.
- Employs heuristic NLP to extract name, email, phone, years of experience, technical skills, degrees, certifications, and projects.

### `GET /api/resumes/my`
Lists all candidate's uploaded resumes.

### `GET /api/resumes/{id}/download`
Downloads physical document file.

---

## 4. Applications (`/api/applications`)

### `POST /api/applications`
Candidate submits application for a job.
- Triggers automated AI screening analysis comparing candidate's resume/profile to job specifications.
- Advances application stage to `Applied` with timeline tracking.

### `GET /api/applications`
Lists applications (filtered by job_id, status, is_shortlisted).

### `PUT /api/applications/{id}/status`
Transitions application stage (e.g. `Applied` -> `Resume Screening` -> `Shortlisted` -> `Interview Scheduled` -> `Selected` / `Rejected`).
- Logs status audit trail in `application_status_history`.
- Automatically delivers notification to candidate.

### `POST /api/applications/{id}/shortlist`
Toggles candidate shortlist state.

---

## 5. AI Screening & Candidate Ranking (`/api/screening`)

### `POST /api/screening/analyze/{application_id}`
Triggers or recalculates AI screening score and breakdown.

### `GET /api/screening/{application_id}`
Returns AI candidate score:
- `overall_score` (0-100)
- `skills_match_score`
- `experience_match_score`
- `education_match_score`
- `project_match_score`
- `certification_match_score`
- `matching_skills` (JSON list)
- `missing_skills` (JSON list)
- `relevant_experience` (Summary)
- `relevant_projects` (Summary)
- `potential_concerns` (Assistive warning flags)
- `ai_summary` (Executive summary)
- `recommendation` (`STRONG_MATCH`, `GOOD_MATCH`, `PARTIAL_MATCH`, `LOW_MATCH`)

### `GET /api/screening/jobs/{job_id}/ranking`
Returns ranked candidate list for a specific opening:
- `sort_by`: `ai_score`, `experience`, or `date`
- Filters: `min_score`, `min_experience`, `skill_filter`, `status`

---

## 6. Interviews (`/api/interviews`)

### `POST /api/interviews`
Schedules an interview:
- Validates candidate schedule conflict.
- Fields: `interview_type` (`TECHNICAL`, `HR`, `MANAGERIAL`, `FINAL`, `VIDEO`, `IN_PERSON`), `scheduled_date`, `scheduled_time`, `duration_minutes`, `interviewer_name`, `meeting_link`, `location`, `notes`.
- Automatically transitions application status to `INTERVIEW_SCHEDULED`.
- Dispatches candidate notification.

### `GET /api/interviews`
List interviews for current recruiter or candidate.

### `PUT /api/interviews/{id}`
Update schedule or complete interview with rating and feedback.

### `DELETE /api/interviews/{id}`
Cancels interview with reason note.

---

## 7. Analytics (`/api/analytics`)

### `GET /api/analytics/dashboard`
Returns recruitment KPIs:
- Total jobs, active jobs, applications, shortlisted, scheduled interviews, selections
- Recruitment funnel (`Applied` -> `Screened` -> `Shortlisted` -> `Interviewed` -> `Selected`)
- Applications trend over time
- Top in-demand skills
- Job-by-job performance breakdown
- Average time to shortlist and hire (days)

---

## 8. Administration (`/api/admin`)

### `GET /api/admin/overview`
Platform health, total accounts, active jobs, storage footprint.

### `GET /api/admin/users`
User governance directory with search and role filters.

### `PUT /api/admin/users/{id}/toggle-active`
Activate or suspend accounts.

### `GET /api/admin/settings/ai` & `PUT /api/admin/settings/ai`
Calibrate scoring weights (Skills %, Experience %, Education %, Projects %, Certifications %).
