import pytest
from datetime import date, time
from fastapi.testclient import TestClient

def test_get_applications_as_recruiter(client: TestClient, recruiter_token: str):
    response = client.get(
        "/api/applications",
        headers={"Authorization": f"Bearer {recruiter_token}"}
    )
    assert response.status_code == 200
    apps = response.json()
    assert isinstance(apps, list)

def test_schedule_and_get_interviews(client: TestClient, recruiter_token: str, db_session):
    # Find an existing application
    apps_resp = client.get("/api/applications", headers={"Authorization": f"Bearer {recruiter_token}"})
    apps = apps_resp.json()
    if not apps:
        pytest.skip("No applications available for interview test")

    target_app_id = apps[0]["id"]
    payload = {
        "application_id": target_app_id,
        "interview_type": "TECHNICAL",
        "title": "System Architecture Review",
        "scheduled_date": "2026-09-20",
        "scheduled_time": "14:00:00",
        "duration_minutes": 60,
        "interviewer_name": "Test Interviewer",
        "meeting_link": "https://meet.google.com/test-link",
        "location": "Google Meet",
        "notes": "Verify backend skills"
    }

    response = client.post(
        "/api/interviews",
        json=payload,
        headers={"Authorization": f"Bearer {recruiter_token}"}
    )
    assert response.status_code in [201, 400]  # 400 only if conflict already scheduled for this slot

    # Get interviews list
    itv_list = client.get("/api/interviews", headers={"Authorization": f"Bearer {recruiter_token}"})
    assert itv_list.status_code == 200
    assert isinstance(itv_list.json(), list)

def test_analytics_dashboard_recruiter(client: TestClient, recruiter_token: str):
    response = client.get(
        "/api/analytics/dashboard",
        headers={"Authorization": f"Bearer {recruiter_token}"}
    )
    assert response.status_code == 200
    data = response.json()
    assert "total_jobs" in data
    assert "hiring_funnel" in data
    assert "applications_timeline" in data
    assert len(data["hiring_funnel"]) >= 4
