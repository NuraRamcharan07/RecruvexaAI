import pytest
from fastapi.testclient import TestClient

def test_register_candidate(client: TestClient):
    payload = {
        "email": "new.candidate.test@example.com",
        "password": "SecurePassword123!",
        "full_name": "Test Candidate",
        "role": "CANDIDATE",
        "headline": "Junior Python Developer",
        "total_experience_years": 2.0
    }
    response = client.post("/api/auth/register", json=payload)
    assert response.status_code == 201
    data = response.json()
    assert "access_token" in data
    assert data["user"]["email"] == "new.candidate.test@example.com"
    assert data["user"]["role"] == "CANDIDATE"

def test_login_success(client: TestClient):
    payload = {
        "email": "new.candidate.test@example.com",
        "password": "SecurePassword123!"
    }
    response = client.post("/api/auth/login", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert data["token_type"] == "bearer"

def test_login_invalid_credentials(client: TestClient):
    payload = {
        "email": "new.candidate.test@example.com",
        "password": "WrongPassword999!"
    }
    response = client.post("/api/auth/login", json=payload)
    assert response.status_code == 401
    assert "Incorrect email or password" in response.json()["detail"]

def test_get_current_user_profile(client: TestClient, candidate_token: str):
    response = client.get("/api/auth/me", headers={"Authorization": f"Bearer {candidate_token}"})
    assert response.status_code == 200
    data = response.json()
    assert "email" in data
    assert data["role"] in ["CANDIDATE", "RECRUITER", "ADMIN"]
