import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.database.session import SessionLocal, get_db
from app.core.security import create_access_token, get_password_hash
from app.models.user import User, RecruiterProfile, CandidateProfile, UserRole
from app.models.job import Job, EmploymentType, JobStatus
from app.utils.seed_data import seed_database

@pytest.fixture(scope="session", autouse=True)
def setup_test_db():
    seed_database()
    yield

@pytest.fixture
def db_session():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@pytest.fixture
def client(db_session):
    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()

@pytest.fixture
def recruiter_token(client, db_session):
    recruiter = db_session.query(User).filter(User.email == "sarah.recruiter@apextech.io").first()
    assert recruiter is not None
    return create_access_token(subject=recruiter.id, role=recruiter.role.value)

@pytest.fixture
def candidate_token(client, db_session):
    cand = db_session.query(User).filter(User.email == "alex.rivers@example.com").first()
    assert cand is not None
    return create_access_token(subject=cand.id, role=cand.role.value)

@pytest.fixture
def admin_token(client, db_session):
    admin = db_session.query(User).filter(User.email == "admin@recruvexa.ai").first()
    assert admin is not None
    return create_access_token(subject=admin.id, role=admin.role.value)
