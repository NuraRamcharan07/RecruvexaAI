import pytest
from fastapi.testclient import TestClient

def test_get_jobs_public(client: TestClient):
    response = client.get("/api/jobs")
    assert response.status_code == 200
    data = response.json()
    assert "items" in data
    assert "total" in data
    assert isinstance(data["items"], list)

def test_create_job_recruiter(client: TestClient, recruiter_token: str):
    payload = {
        "title": "Cloud Security Architect",
        "department": "Security",
        "location": "Remote",
        "employment_type": "FULL_TIME",
        "experience_required": 5.0,
        "min_salary": 140000,
        "max_salary": 180000,
        "salary_currency": "USD",
        "description": "Architect security controls and compliance automation.",
        "responsibilities": "Lead cloud auditing and zero-trust rollouts.",
        "required_skills": "AWS, Docker, Linux, Python",
        "preferred_skills": "Kubernetes, Terraform",
        "education_requirements": "B.S. in Computer Science",
        "status": "PUBLISHED"
    }
    response = client.post(
        "/api/jobs",
        json=payload,
        headers={"Authorization": f"Bearer {recruiter_token}"}
    )
    assert response.status_code == 201
    data = response.json()
    assert data["title"] == "Cloud Security Architect"
    assert data["id"] is not None

def test_candidate_forbidden_to_create_job(client: TestClient, candidate_token: str):
    payload = {
        "title": "Illegal Role Attempt",
        "department": "Engineering",
        "location": "Remote",
        "employment_type": "FULL_TIME",
        "experience_required": 2.0,
        "description": "This should fail because candidate role is not authorized.",
        "required_skills": "Python"
    }
    response = client.post(
        "/api/jobs",
        json=payload,
        headers={"Authorization": f"Bearer {candidate_token}"}
    )
    assert response.status_code == 403
