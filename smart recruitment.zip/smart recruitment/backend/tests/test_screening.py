import pytest
from app.services.ai.resume_parser import ResumeParser
from app.services.ai.scoring_engine import ScoringEngine
from app.services.ai.candidate_matcher import CandidateMatcher
from app.services.ai.resume_analyzer import ResumeAnalyzer

def test_resume_parser_entity_extraction():
    sample_text = """
    Johnathan Doe
    Email: john.doe@innovate.org | Phone: (555) 789-0123 | Location: Seattle, WA

    PROFESSIONAL SUMMARY
    Dedicated software engineer with 5 years of experience architecting web backends and cloud systems.

    TECHNICAL SKILLS
    Languages & Frameworks: Python, FastAPI, React, Node.js, TypeScript, SQL
    Infrastructure: Docker, Kubernetes, AWS, PostgreSQL, Git

    EDUCATION
    Master of Science in Computer Science - University of Washington

    CERTIFICATIONS
    AWS Certified Solutions Architect, Certified Kubernetes Administrator

    PROJECTS
    - Distributed Event Log: Built real-time stream ingestion processing 20,000 events/sec.
    - Cloud Cost Optimizer: Automated AWS resource scaling saving $12,000 monthly.
    """

    parsed = ResumeParser.parse(sample_text)
    assert parsed["email"] == "john.doe@innovate.org"
    assert parsed["phone"] is not None
    assert "Python" in parsed["skills"]
    assert "FastAPI" in parsed["skills"]
    assert "React" in parsed["skills"]
    assert "Docker" in parsed["skills"]
    assert parsed["experience_years"] >= 4.0
    assert len(parsed["projects"]) >= 1

def test_scoring_engine_breakdown():
    candidate_data = {
        "skills": ["Python", "FastAPI", "PostgreSQL", "Docker", "AWS", "React"],
        "experience_years": 5.0,
        "education": ["Master of Science in Computer Science"],
        "projects": ["High throughput API", "Cloud Orchestration"],
        "certifications": ["AWS Certified"]
    }
    job_requirements = {
        "required_skills": ["Python", "FastAPI", "Docker", "PostgreSQL"],
        "preferred_skills": ["AWS", "React"],
        "experience_required": 4.0,
        "education_requirements": "Bachelor's or Master's in Computer Science",
        "certifications": "AWS Certified",
        "description": "Building cloud backends"
    }

    scores = ScoringEngine.calculate_scores(candidate_data, job_requirements)
    assert scores["overall_score"] >= 80.0
    assert scores["skills_match_score"] >= 85.0
    assert scores["experience_match_score"] >= 85.0
    assert scores["education_match_score"] >= 90.0

def test_candidate_matcher_gap_analysis():
    candidate_data = {
        "skills": ["Python", "React", "Docker"],
        "experience_years": 2.0,
        "projects": [],
        "education": []
    }
    job_data = {
        "required_skills": "Python, Docker, Kubernetes, Kafka",
        "preferred_skills": "AWS",
        "experience_required": 5.0,
        "education_requirements": "B.S. Computer Science"
    }

    match_result = CandidateMatcher.match(candidate_data, job_data)
    assert "Python" in match_result["matching_skills"]
    assert "Docker" in match_result["matching_skills"]
    assert "Kubernetes" in match_result["missing_skills"]
    assert "Kafka" in match_result["missing_skills"]
    assert "lower than requested" in match_result["potential_concerns"]

def test_resume_analyzer_executive_summary():
    cand_data = {
        "name": "Jane Developer",
        "skills": ["Python", "FastAPI", "React", "AWS", "PostgreSQL"],
        "experience_years": 6.0,
        "education": ["B.S. in Software Engineering"],
        "projects": ["Enterprise Portal"],
        "certifications": []
    }
    job_data = {
        "title": "Senior Full-Stack Engineer",
        "required_skills": "Python, FastAPI, React",
        "preferred_skills": "AWS",
        "experience_required": 4.0,
        "education_requirements": "Bachelor's degree"
    }

    analysis = ResumeAnalyzer.analyze(cand_data, job_data)
    assert analysis["overall_score"] >= 80.0
    assert "Jane Developer" in analysis["ai_summary"]
    assert analysis["recommendation"] in ["STRONG_MATCH", "GOOD_MATCH"]
