import os
import json
from datetime import datetime, timezone, timedelta, date, time
from sqlalchemy.orm import Session
from app.database.session import SessionLocal, Base, engine
from app.core.security import get_password_hash
from app.models.user import User, RecruiterProfile, CandidateProfile, UserRole
from app.models.job import Job, JobSkill, EmploymentType, JobStatus
from app.models.resume import Resume
from app.models.application import Application, ApplicationStatus, ApplicationStatusHistory
from app.models.screening import CandidateScore
from app.models.interview import Interview, InterviewType, InterviewStatus
from app.models.notification import Notification

def seed_database():
    Base.metadata.create_all(bind=engine)
    db: Session = SessionLocal()

    try:
        # Check if already seeded
        if db.query(User).filter(User.email == "admin@recruvexa.ai").first():
            print("Database already seeded with demo data.")
            return

        print("Seeding RecruVexa AI database...")

        # -------------------------------------------------------------
        # 1. USERS & PROFILES
        # -------------------------------------------------------------
        # Admin
        admin = User(
            email="admin@recruvexa.ai",
            hashed_password=get_password_hash("Admin123!"),
            full_name="Alexander Vance (Admin)",
            phone="+1 (555) 019-2831",
            role=UserRole.ADMIN,
            is_active=True,
            is_verified=True,
        )
        db.add(admin)

        # Recruiter 1
        recruiter1 = User(
            email="sarah.recruiter@apextech.io",
            hashed_password=get_password_hash("Recruiter123!"),
            full_name="Sarah Jenkins",
            phone="+1 (555) 432-8765",
            role=UserRole.RECRUITER,
            is_active=True,
            is_verified=True,
        )
        db.add(recruiter1)
        db.flush()

        rp1 = RecruiterProfile(
            user_id=recruiter1.id,
            company_name="Apex AI Innovations",
            company_website="https://apextech.example.io",
            company_size="250-500",
            industry="Artificial Intelligence & Cloud",
            designatory_title="Director of Global Talent Acquisition",
        )
        db.add(rp1)

        # Recruiter 2
        recruiter2 = User(
            email="david.hr@cloudscale.net",
            hashed_password=get_password_hash("Recruiter123!"),
            full_name="David Sterling",
            phone="+1 (555) 876-5432",
            role=UserRole.RECRUITER,
            is_active=True,
            is_verified=True,
        )
        db.add(recruiter2)
        db.flush()

        rp2 = RecruiterProfile(
            user_id=recruiter2.id,
            company_name="CloudScale Dynamics",
            company_website="https://cloudscale.example.net",
            company_size="500-1000",
            industry="Enterprise Infrastructure",
            designatory_title="Principal Technical Recruiter",
        )
        db.add(rp2)

        # Candidate 1: Full-stack
        cand1 = User(
            email="alex.rivers@example.com",
            hashed_password=get_password_hash("Candidate123!"),
            full_name="Alex Rivers",
            phone="+1 (555) 234-5678",
            role=UserRole.CANDIDATE,
            is_active=True,
            is_verified=True,
        )
        db.add(cand1)
        db.flush()
        cp1 = CandidateProfile(
            user_id=cand1.id,
            headline="Senior Full-Stack Engineer | React, Node.js, Python, AWS",
            summary="Full-stack engineer with 6 years building high-throughput microservices, scalable distributed systems, and real-time reactive frontends.",
            location="San Francisco, CA (Open to Remote)",
            total_experience_years=6.0,
            education_level="B.S. in Computer Science",
            current_company="OmniTech Labs",
            current_title="Senior Software Engineer",
            skills_text="React, TypeScript, Node.js, Python, FastAPI, PostgreSQL, Docker, AWS, GraphQL, Redis",
            github_url="https://github.com/alexrivers-demo",
            linkedin_url="https://linkedin.com/in/alexrivers-demo",
        )
        db.add(cp1)

        # Candidate 2: Backend / Systems
        cand2 = User(
            email="priya.patel@example.com",
            hashed_password=get_password_hash("Candidate123!"),
            full_name="Priya Patel",
            phone="+1 (555) 345-6789",
            role=UserRole.CANDIDATE,
            is_active=True,
            is_verified=True,
        )
        db.add(cand2)
        db.flush()
        cp2 = CandidateProfile(
            user_id=cand2.id,
            headline="Lead Backend Architect | Distributed Systems & High-Scale APIs",
            summary="Architect with 7.5 years specializing in cloud native backend systems, event streaming with Kafka, and container orchestration.",
            location="New York, NY",
            total_experience_years=7.5,
            education_level="M.S. in Computer Science",
            current_company="FinStream Networks",
            current_title="Lead Backend Architect",
            skills_text="Python, Go, FastAPI, PostgreSQL, Kubernetes, Docker, Kafka, AWS, Microservices, CI/CD",
            github_url="https://github.com/priyapatel-demo",
            linkedin_url="https://linkedin.com/in/priyapatel-demo",
        )
        db.add(cp2)

        # Candidate 3: AI / ML
        cand3 = User(
            email="marcus.chen@example.com",
            hashed_password=get_password_hash("Candidate123!"),
            full_name="Marcus Chen",
            phone="+1 (555) 456-7890",
            role=UserRole.CANDIDATE,
            is_active=True,
            is_verified=True,
        )
        db.add(cand3)
        db.flush()
        cp3 = CandidateProfile(
            user_id=cand3.id,
            headline="Machine Learning & NLP Engineer | LLMs, PyTorch, LangChain",
            summary="AI practitioner focused on generative AI workflows, model distillation, and production RAG systems.",
            location="Seattle, WA (Remote)",
            total_experience_years=4.5,
            education_level="M.S. in Artificial Intelligence",
            current_company="Cognitive Core AI",
            current_title="Machine Learning Engineer",
            skills_text="Python, PyTorch, TensorFlow, NLP, LLM, LangChain, FastAPI, Docker, Scikit-Learn, Vector Databases",
            github_url="https://github.com/marcuschen-demo",
            linkedin_url="https://linkedin.com/in/marcuschen-demo",
        )
        db.add(cp3)

        # Candidate 4: Frontend
        cand4 = User(
            email="elena.rostova@example.com",
            hashed_password=get_password_hash("Candidate123!"),
            full_name="Elena Rostova",
            phone="+1 (555) 567-8901",
            role=UserRole.CANDIDATE,
            is_active=True,
            is_verified=True,
        )
        db.add(cand4)
        db.flush()
        cp4 = CandidateProfile(
            user_id=cand4.id,
            headline="Senior Frontend Architect | React, Next.js, Design Systems",
            summary="UI/UX obsessed frontend specialist with 5 years crafting fluid, accessible, high-performance web applications.",
            location="Austin, TX",
            total_experience_years=5.0,
            education_level="B.S. in Software Engineering",
            current_company="DesignCraft Studios",
            current_title="Lead Frontend Developer",
            skills_text="React, Next.js, TypeScript, Tailwind, Redux, HTML, CSS, JavaScript, Vite, Webpack",
            github_url="https://github.com/elenarostova-demo",
            linkedin_url="https://linkedin.com/in/elenarostova-demo",
        )
        db.add(cp4)

        # Candidate 5: DevOps
        cand5 = User(
            email="jordan.hayes@example.com",
            hashed_password=get_password_hash("Candidate123!"),
            full_name="Jordan Hayes",
            phone="+1 (555) 678-9012",
            role=UserRole.CANDIDATE,
            is_active=True,
            is_verified=True,
        )
        db.add(cand5)
        db.flush()
        cp5 = CandidateProfile(
            user_id=cand5.id,
            headline="Principal DevOps & Site Reliability Engineer | AWS, Terraform, K8s",
            summary="Infrastructure engineer with 6.5 years automating multi-region cloud infrastructures, zero-downtime CI/CD pipelines, and observability.",
            location="Chicago, IL",
            total_experience_years=6.5,
            education_level="B.S. in Information Systems",
            current_company="Vanguard Cloud Systems",
            current_title="Staff Site Reliability Engineer",
            skills_text="AWS, Kubernetes, Docker, Terraform, Ansible, CI/CD, GitHub Actions, Linux, Python, Prometheus",
            github_url="https://github.com/jordanhayes-demo",
            linkedin_url="https://linkedin.com/in/jordanhayes-demo",
        )
        db.add(cp5)

        db.flush()

        # -------------------------------------------------------------
        # 2. RESUMES
        # -------------------------------------------------------------
        resume1 = Resume(
            candidate_id=cand1.id,
            filename="demo_alex_rivers_resume.pdf",
            original_name="Alex_Rivers_Resume_2026.pdf",
            file_path="uploads/resumes/demo_alex_rivers_resume.pdf",
            file_size=142800,
            content_type="application/pdf",
            raw_text="Alex Rivers. Email: alex.rivers@example.com. Phone: 555-234-5678. Senior Full-Stack Engineer with 6 years experience in React, TypeScript, Node.js, Python, FastAPI, PostgreSQL, Docker, AWS, GraphQL, Redis. Education: B.S. in Computer Science. Projects: Real-time Analytics Engine, SaaS Payment Orchestration.",
            parsed_name="Alex Rivers",
            parsed_email="alex.rivers@example.com",
            parsed_phone="+1 (555) 234-5678",
            parsed_skills="React, TypeScript, Node.js, Python, FastAPI, PostgreSQL, Docker, AWS, GraphQL, Redis",
            parsed_experience_years=6.0,
            parsed_education="Bachelor of Science in Computer Science",
            parsed_certifications="AWS Certified Solutions Architect",
            parsed_projects="Real-time Analytics Engine; SaaS Payment Orchestrator; Distributed Caching Layer",
            is_primary=True,
        )
        db.add(resume1)

        resume2 = Resume(
            candidate_id=cand2.id,
            filename="demo_priya_patel_resume.pdf",
            original_name="Priya_Patel_Principal_Backend.pdf",
            file_path="uploads/resumes/demo_priya_patel_resume.pdf",
            file_size=158200,
            content_type="application/pdf",
            raw_text="Priya Patel. Email: priya.patel@example.com. Phone: 555-345-6789. Lead Backend Architect with 7.5 years experience in Python, Go, FastAPI, PostgreSQL, Kubernetes, Docker, Kafka, AWS, Microservices, CI/CD. Education: M.S. in Computer Science. Projects: Low-latency Trading Platform, Multi-tenant Data Gateway.",
            parsed_name="Priya Patel",
            parsed_email="priya.patel@example.com",
            parsed_phone="+1 (555) 345-6789",
            parsed_skills="Python, Go, FastAPI, PostgreSQL, Kubernetes, Docker, Kafka, AWS, Microservices, CI/CD",
            parsed_experience_years=7.5,
            parsed_education="Master of Science in Computer Science",
            parsed_certifications="Certified Kubernetes Administrator (CKA), AWS Solutions Architect Professional",
            parsed_projects="Low-latency Trading Platform; Multi-tenant Data Pipeline; Distributed Event Mesh",
            is_primary=True,
        )
        db.add(resume2)

        resume3 = Resume(
            candidate_id=cand3.id,
            filename="demo_marcus_chen_resume.pdf",
            original_name="Marcus_Chen_AI_ML_Resume.pdf",
            file_path="uploads/resumes/demo_marcus_chen_resume.pdf",
            file_size=138400,
            content_type="application/pdf",
            raw_text="Marcus Chen. Email: marcus.chen@example.com. Phone: 555-456-7890. Machine Learning & NLP Engineer with 4.5 years experience in Python, PyTorch, TensorFlow, NLP, LLM, LangChain, FastAPI, Docker, Scikit-Learn. Education: M.S. in Artificial Intelligence. Projects: Domain-specific RAG Assistant, Neural Sentiment Classifier.",
            parsed_name="Marcus Chen",
            parsed_email="marcus.chen@example.com",
            parsed_phone="+1 (555) 456-7890",
            parsed_skills="Python, PyTorch, TensorFlow, NLP, LLM, LangChain, FastAPI, Docker, Scikit-Learn",
            parsed_experience_years=4.5,
            parsed_education="Master of Science in Artificial Intelligence",
            parsed_certifications="Deep Learning Specialization (Coursera), Google Cloud Professional Data Engineer",
            parsed_projects="Enterprise RAG Assistant; Neural Text Summarizer; Fine-tuned Code LLM",
            is_primary=True,
        )
        db.add(resume3)

        resume4 = Resume(
            candidate_id=cand4.id,
            filename="demo_elena_rostova_resume.pdf",
            original_name="Elena_Rostova_Frontend_Resume.pdf",
            file_path="uploads/resumes/demo_elena_rostova_resume.pdf",
            file_size=129000,
            content_type="application/pdf",
            raw_text="Elena Rostova. Email: elena.rostova@example.com. Phone: 555-567-8901. Senior Frontend Architect with 5 years experience in React, Next.js, TypeScript, Tailwind, Redux, HTML, CSS, JavaScript, Vite. Education: B.S. in Software Engineering. Projects: Design System UI Kit, Interactive Financial Dashboard.",
            parsed_name="Elena Rostova",
            parsed_email="elena.rostova@example.com",
            parsed_phone="+1 (555) 567-8901",
            parsed_skills="React, Next.js, TypeScript, Tailwind, Redux, HTML, CSS, JavaScript, Vite",
            parsed_experience_years=5.0,
            parsed_education="Bachelor of Science in Software Engineering",
            parsed_certifications="Meta Certified Frontend Developer",
            parsed_projects="Enterprise Design System Kit; High-performance Stock Screener UI",
            is_primary=True,
        )
        db.add(resume4)

        resume5 = Resume(
            candidate_id=cand5.id,
            filename="demo_jordan_hayes_resume.pdf",
            original_name="Jordan_Hayes_DevOps_Resume.pdf",
            file_path="uploads/resumes/demo_jordan_hayes_resume.pdf",
            file_size=145000,
            content_type="application/pdf",
            raw_text="Jordan Hayes. Email: jordan.hayes@example.com. Phone: 555-678-9012. Principal DevOps Engineer with 6.5 years experience in AWS, Kubernetes, Docker, Terraform, Ansible, CI/CD, Linux, Python. Education: B.S. in Information Systems. Projects: Multi-cloud Infrastructure as Code, Automated Canary Deployments.",
            parsed_name="Jordan Hayes",
            parsed_email="jordan.hayes@example.com",
            parsed_phone="+1 (555) 678-9012",
            parsed_skills="AWS, Kubernetes, Docker, Terraform, Ansible, CI/CD, GitHub Actions, Linux, Python",
            parsed_experience_years=6.5,
            parsed_education="Bachelor of Science in Information Systems",
            parsed_certifications="AWS Certified DevOps Engineer Professional, CKA",
            parsed_projects="Terraform Multi-Region Foundation; Zero-Downtime Canary Pipeline",
            is_primary=True,
        )
        db.add(resume5)

        db.flush()

        # -------------------------------------------------------------
        # 3. JOBS
        # -------------------------------------------------------------
        job1 = Job(
            recruiter_id=recruiter1.id,
            title="Senior Full-Stack AI Application Engineer",
            department="Engineering",
            location="San Francisco, CA (Hybrid)",
            employment_type=EmploymentType.FULL_TIME,
            experience_required=4.0,
            min_salary=145000,
            max_salary=185000,
            salary_currency="USD",
            description="We are seeking an experienced Full-Stack Engineer with strong AI integration fundamentals to architect next-generation intelligent SaaS applications.",
            responsibilities="Architect reactive React/Next.js client portals; build high-performance Python/FastAPI microservices; integrate LLM and vector database workflows; ensure 99.9% reliability.",
            required_skills="React, TypeScript, Python, FastAPI, PostgreSQL, Docker, AWS",
            preferred_skills="Next.js, Tailwind, GraphQL, Redis, LLM, Vector Databases",
            education_requirements="Bachelor's degree in Computer Science or equivalent practical experience",
            certifications="AWS Certified Associate or equivalent cloud certification preferred",
            deadline=datetime.now(timezone.utc) + timedelta(days=30),
            status=JobStatus.PUBLISHED,
            views_count=142
        )
        db.add(job1)

        job2 = Job(
            recruiter_id=recruiter2.id,
            title="Lead Backend Systems Architect (Distributed Systems)",
            department="Platform Engineering",
            location="Remote (North America)",
            employment_type=EmploymentType.FULL_TIME,
            experience_required=6.0,
            min_salary=160000,
            max_salary=205000,
            salary_currency="USD",
            description="Lead backend architecture initiatives for high-concurrency event-driven financial data streaming pipelines across Kubernetes clusters.",
            responsibilities="Design resilient REST/gRPC backend microservices; optimize complex PostgreSQL queries and caching strategies; mentor backend engineers; manage CI/CD pipelines.",
            required_skills="Python, FastAPI, PostgreSQL, Kubernetes, Docker, Kafka, AWS, Microservices",
            preferred_skills="Go, Redis, Terraform, CI/CD, System Design",
            education_requirements="Master's or Bachelor's in Computer Science",
            certifications="CKA or AWS Solutions Architect preferred",
            deadline=datetime.now(timezone.utc) + timedelta(days=25),
            status=JobStatus.PUBLISHED,
            views_count=98
        )
        db.add(job2)

        job3 = Job(
            recruiter_id=recruiter1.id,
            title="Senior Machine Learning & NLP Scientist",
            department="AI Research & Development",
            location="San Francisco, CA / Remote",
            employment_type=EmploymentType.FULL_TIME,
            experience_required=3.5,
            min_salary=155000,
            max_salary=195000,
            salary_currency="USD",
            description="Build domain-adapted NLP models, prompt orchestration pipelines, and advanced retrieval-augmented generation (RAG) engines for recruitment analytics.",
            responsibilities="Conduct experiments with transformer models; optimize vector search latency; collaborate with product engineers to deploy production inference endpoints.",
            required_skills="Python, PyTorch, NLP, Machine Learning, FastAPI, Docker",
            preferred_skills="TensorFlow, LLM, LangChain, Scikit-Learn, Vector Databases",
            education_requirements="Master's or Ph.D. in Computer Science, AI, or Mathematics",
            certifications="Deep Learning credentials preferred",
            deadline=datetime.now(timezone.utc) + timedelta(days=40),
            status=JobStatus.PUBLISHED,
            views_count=210
        )
        db.add(job3)

        job4 = Job(
            recruiter_id=recruiter1.id,
            title="Staff Frontend Engineer (React & Design Systems)",
            department="Product Design & Engineering",
            location="New York, NY (Hybrid)",
            employment_type=EmploymentType.FULL_TIME,
            experience_required=4.0,
            min_salary=135000,
            max_salary=170000,
            salary_currency="USD",
            description="Drive UI consistency, micro-animations, and responsive performance across our suite of recruitment dashboards and candidate-facing applications.",
            responsibilities="Maintain corporate component design system; architect state management; optimize Core Web Vitals; conduct accessible frontend reviews.",
            required_skills="React, Next.js, TypeScript, Tailwind, JavaScript, HTML, CSS",
            preferred_skills="Redux, Vite, Webpack, Responsive Design, WCAG Accessibility",
            education_requirements="Bachelor's degree in Computer Science, Software Engineering, or related",
            certifications="Frontend engineering credentials welcome",
            deadline=datetime.now(timezone.utc) + timedelta(days=20),
            status=JobStatus.PUBLISHED,
            views_count=84
        )
        db.add(job4)

        job5 = Job(
            recruiter_id=recruiter2.id,
            title="Senior DevOps & Infrastructure Security Engineer",
            department="Infrastructure & Operations",
            location="Remote",
            employment_type=EmploymentType.FULL_TIME,
            experience_required=5.0,
            min_salary=150000,
            max_salary=190000,
            salary_currency="USD",
            description="Automate deployment pipelines, enforce least-privilege cloud security postures, and oversee multi-region Kubernetes clusters on AWS.",
            responsibilities="Author Terraform modules; manage GitHub Actions CI/CD workflows; manage monitoring and incident response runbooks.",
            required_skills="AWS, Kubernetes, Docker, Terraform, CI/CD, Linux, Python",
            preferred_skills="Ansible, Prometheus, Grafana, Security Auditing",
            education_requirements="Bachelor's degree or equivalent military/industrial experience",
            certifications="AWS Certified DevOps Engineer or CKA required",
            deadline=datetime.now(timezone.utc) + timedelta(days=35),
            status=JobStatus.PUBLISHED,
            views_count=65
        )
        db.add(job5)

        db.flush()

        # -------------------------------------------------------------
        # 4. APPLICATIONS & AI SCREENING SCORES
        # -------------------------------------------------------------
        # App 1: Alex Rivers -> Job 1 (Senior Full-Stack AI Engineer)
        app1 = Application(
            job_id=job1.id,
            candidate_id=cand1.id,
            resume_id=resume1.id,
            cover_letter="I have spent the last 6 years building production-grade React and Python microservices. I am passionate about assistive AI workflows and would love to contribute to RecruVexa AI.",
            status=ApplicationStatus.SHORTLISTED,
            current_stage="Shortlisted for Interview",
            is_shortlisted=True,
            recruiter_notes="Exceptional candidate with balanced full-stack and cloud skills. Recommended for technical panel.",
            created_at=datetime.now(timezone.utc) - timedelta(days=5)
        )
        db.add(app1)
        db.flush()

        score1 = CandidateScore(
            application_id=app1.id,
            job_id=job1.id,
            candidate_id=cand1.id,
            overall_score=92.5,
            skills_match_score=95.0,
            experience_match_score=96.0,
            education_match_score=92.0,
            project_match_score=88.0,
            certification_match_score=90.0,
            matching_skills=json.dumps(["React", "TypeScript", "Python", "FastAPI", "PostgreSQL", "Docker", "AWS", "Redis"]),
            missing_skills=json.dumps(["Vector Databases"]),
            relevant_experience="6.0 years verified full-stack experience exceeding the 4.0 years requirement.",
            relevant_projects="Production SaaS Payment Orchestration and Real-time Analytics Engine directly applicable.",
            potential_concerns="Minimal hands-on vector database experience noted, though strong general database foundation.",
            ai_summary="Alex Rivers represents a top 5% match for the Senior Full-Stack AI Engineer role. Exceptional mastery of required core frameworks (React, FastAPI, Docker, AWS). Highly recommended for technical screening.",
            recommendation="STRONG_MATCH",
            analyzed_at=datetime.now(timezone.utc) - timedelta(days=5)
        )
        db.add(score1)

        # App 2: Priya Patel -> Job 2 (Lead Backend Systems Architect)
        app2 = Application(
            job_id=job2.id,
            candidate_id=cand2.id,
            resume_id=resume2.id,
            cover_letter="My 7+ years of experience architecting resilient distributed systems with Python, Kafka, and Kubernetes aligns squarely with CloudScale's mission.",
            status=ApplicationStatus.INTERVIEW_SCHEDULED,
            current_stage="Technical Architecture Interview Scheduled",
            is_shortlisted=True,
            recruiter_notes="Top scoring candidate. Scheduled technical architecture interview with VP of Platform.",
            created_at=datetime.now(timezone.utc) - timedelta(days=4)
        )
        db.add(app2)
        db.flush()

        score2 = CandidateScore(
            application_id=app2.id,
            job_id=job2.id,
            candidate_id=cand2.id,
            overall_score=95.8,
            skills_match_score=98.0,
            experience_match_score=98.0,
            education_match_score=95.0,
            project_match_score=94.0,
            certification_match_score=95.0,
            matching_skills=json.dumps(["Python", "FastAPI", "PostgreSQL", "Kubernetes", "Docker", "Kafka", "AWS", "Microservices"]),
            missing_skills=json.dumps([]),
            relevant_experience="7.5 years architecting enterprise distributed backends and event pipelines.",
            relevant_projects="Low-latency Trading Platform and Multi-tenant Data Gateway highlight high throughput capability.",
            potential_concerns="None detected. Candidate credentials align completely with lead architect criteria.",
            ai_summary="Priya Patel is an extraordinary 96% compatibility fit for Lead Backend Architect. Complete overlap across Python, Kubernetes, Kafka, and Microservices combined with CKA and AWS professional credentials.",
            recommendation="STRONG_MATCH",
            analyzed_at=datetime.now(timezone.utc) - timedelta(days=4)
        )
        db.add(score2)

        # App 3: Marcus Chen -> Job 3 (Senior ML & NLP Scientist)
        app3 = Application(
            job_id=job3.id,
            candidate_id=cand3.id,
            resume_id=resume3.id,
            cover_letter="My research and practical engineering in RAG pipelines and transformer fine-tuning will accelerate Apex AI's screening accuracy.",
            status=ApplicationStatus.INTERVIEW_SCHEDULED,
            current_stage="Interview Scheduled",
            is_shortlisted=True,
            recruiter_notes="Strong NLP and PyTorch experience. Video interview planned.",
            created_at=datetime.now(timezone.utc) - timedelta(days=3)
        )
        db.add(app3)
        db.flush()

        score3 = CandidateScore(
            application_id=app3.id,
            job_id=job3.id,
            candidate_id=cand3.id,
            overall_score=89.2,
            skills_match_score=92.0,
            experience_match_score=88.0,
            education_match_score=95.0,
            project_match_score=86.0,
            certification_match_score=82.0,
            matching_skills=json.dumps(["Python", "PyTorch", "NLP", "Machine Learning", "FastAPI", "Docker", "LLM", "LangChain"]),
            missing_skills=json.dumps(["TensorFlow"]),
            relevant_experience="4.5 years hands-on machine learning engineering and RAG production development.",
            relevant_projects="Enterprise RAG Assistant and Fine-tuned Code LLM demonstrate state-of-the-art capability.",
            potential_concerns="Primary focus in PyTorch; minor familiarity gap with legacy TensorFlow stacks.",
            ai_summary="Marcus Chen demonstrates strong domain depth (89%) in modern NLP and Generative AI pipelines. M.S. in AI degree directly bolsters technical credibility.",
            recommendation="STRONG_MATCH",
            analyzed_at=datetime.now(timezone.utc) - timedelta(days=3)
        )
        db.add(score3)

        # App 4: Elena Rostova -> Job 4 (Staff Frontend Engineer)
        app4 = Application(
            job_id=job4.id,
            candidate_id=cand4.id,
            resume_id=resume4.id,
            cover_letter="Design systems and micro-interactions are my core craft. Looking forward to driving frontend excellence at Apex.",
            status=ApplicationStatus.SHORTLISTED,
            current_stage="Shortlisted",
            is_shortlisted=True,
            recruiter_notes="Impressive portfolio and deep React/Tailwind expertise.",
            created_at=datetime.now(timezone.utc) - timedelta(days=2)
        )
        db.add(app4)
        db.flush()

        score4 = CandidateScore(
            application_id=app4.id,
            job_id=job4.id,
            candidate_id=cand4.id,
            overall_score=91.4,
            skills_match_score=96.0,
            experience_match_score=92.0,
            education_match_score=92.0,
            project_match_score=88.0,
            certification_match_score=80.0,
            matching_skills=json.dumps(["React", "Next.js", "TypeScript", "Tailwind", "JavaScript", "HTML", "CSS", "Vite"]),
            missing_skills=json.dumps(["WCAG Accessibility"]),
            relevant_experience="5.0 years designing and implementing component architecture.",
            relevant_projects="Enterprise Design System Kit showcases reusable frontend components and state orchestration.",
            potential_concerns="Formal accessibility (WCAG) audit credentials not documented.",
            ai_summary="Elena Rostova scores 91% alignment for Staff Frontend Engineer. Exemplary grasp of modern React, Next.js, and design token architectures.",
            recommendation="STRONG_MATCH",
            analyzed_at=datetime.now(timezone.utc) - timedelta(days=2)
        )
        db.add(score4)

        # App 5: Jordan Hayes -> Job 5 (Senior DevOps & Infrastructure)
        app5 = Application(
            job_id=job5.id,
            candidate_id=cand5.id,
            resume_id=resume5.id,
            cover_letter="Managing multi-region AWS and Kubernetes setups with Terraform is what I do daily. Ready to strengthen CloudScale's resilience.",
            status=ApplicationStatus.RESUME_SCREENING,
            current_stage="Resume Screening",
            is_shortlisted=False,
            recruiter_notes="Under review by recruiter.",
            created_at=datetime.now(timezone.utc) - timedelta(days=1)
        )
        db.add(app5)
        db.flush()

        score5 = CandidateScore(
            application_id=app5.id,
            job_id=job5.id,
            candidate_id=cand5.id,
            overall_score=88.5,
            skills_match_score=92.0,
            experience_match_score=94.0,
            education_match_score=90.0,
            project_match_score=85.0,
            certification_match_score=80.0,
            matching_skills=json.dumps(["AWS", "Kubernetes", "Docker", "Terraform", "CI/CD", "Linux", "Python"]),
            missing_skills=json.dumps(["Ansible"]),
            relevant_experience="6.5 years automating infrastructure and cloud deployments.",
            relevant_projects="Terraform Multi-Region Foundation demonstrates deep infrastructure-as-code competency.",
            potential_concerns="Ansible experience secondary to Terraform.",
            ai_summary="Jordan Hayes scores 88% compatibility for Senior DevOps Engineer. Solid track record in Kubernetes and AWS automation.",
            recommendation="GOOD_MATCH",
            analyzed_at=datetime.now(timezone.utc) - timedelta(days=1)
        )
        db.add(score5)

        # App 6: Alex Rivers -> Job 4 (Cross application example)
        app6 = Application(
            job_id=job4.id,
            candidate_id=cand1.id,
            resume_id=resume1.id,
            cover_letter="Also applying to the frontend role as my React and design system experience is extensive.",
            status=ApplicationStatus.APPLIED,
            current_stage="Application Submitted",
            is_shortlisted=False,
            created_at=datetime.now(timezone.utc) - timedelta(hours=8)
        )
        db.add(app6)
        db.flush()

        score6 = CandidateScore(
            application_id=app6.id,
            job_id=job4.id,
            candidate_id=cand1.id,
            overall_score=84.0,
            skills_match_score=88.0,
            experience_match_score=94.0,
            education_match_score=92.0,
            project_match_score=80.0,
            certification_match_score=70.0,
            matching_skills=json.dumps(["React", "TypeScript", "JavaScript", "HTML", "CSS"]),
            missing_skills=json.dumps(["Next.js", "Tailwind"]),
            relevant_experience="6 years full-stack experience with significant frontend component delivery.",
            relevant_projects="Real-time UI interfaces and payment dashboards.",
            potential_concerns="Tailwind and Next.js are not listed as primary skills.",
            ai_summary="Alex Rivers displays an 84% fit for Staff Frontend Engineer. Solid React grounding with opportunity to adapt to Next.js and Tailwind.",
            recommendation="GOOD_MATCH",
            analyzed_at=datetime.now(timezone.utc) - timedelta(hours=8)
        )
        db.add(score6)

        db.flush()

        # -------------------------------------------------------------
        # 5. INTERVIEWS
        # -------------------------------------------------------------
        interview1 = Interview(
            application_id=app2.id,
            job_id=job2.id,
            candidate_id=cand2.id,
            recruiter_id=recruiter2.id,
            title="Technical Architecture & Distributed Systems Deep Dive",
            interview_type=InterviewType.TECHNICAL,
            scheduled_date=(datetime.now(timezone.utc) + timedelta(days=2)).date(),
            scheduled_time=time(14, 30),
            duration_minutes=60,
            interviewer_name="Evelyn Thorne (VP of Engineering)",
            interviewer_email="evelyn.thorne@cloudscale.net",
            meeting_link="https://meet.google.com/rvx-arch-tech",
            location="Google Meet Video Conference",
            notes="Focus on Kafka consumer rebalancing, distributed transaction rollbacks, and PostgreSQL partitioning strategies.",
            status=InterviewStatus.SCHEDULED
        )
        db.add(interview1)

        interview2 = Interview(
            application_id=app3.id,
            job_id=job3.id,
            candidate_id=cand3.id,
            recruiter_id=recruiter1.id,
            title="ML Research & RAG Architecture Panel",
            interview_type=InterviewType.VIDEO,
            scheduled_date=(datetime.now(timezone.utc) + timedelta(days=3)).date(),
            scheduled_time=time(11, 0),
            duration_minutes=45,
            interviewer_name="Dr. Julian Ross (Lead AI Scientist)",
            interviewer_email="julian.ross@apextech.io",
            meeting_link="https://zoom.us/j/9876543210?pwd=recruvexa_demo",
            location="Zoom Video Meeting",
            notes="Candidate to present past work on fine-tuning and inference latency optimizations.",
            status=InterviewStatus.SCHEDULED
        )
        db.add(interview2)

        interview3 = Interview(
            application_id=app1.id,
            job_id=job1.id,
            candidate_id=cand1.id,
            recruiter_id=recruiter1.id,
            title="Full-Stack Technical System Design",
            interview_type=InterviewType.TECHNICAL,
            scheduled_date=(datetime.now(timezone.utc) + timedelta(days=4)).date(),
            scheduled_time=time(15, 0),
            duration_minutes=60,
            interviewer_name="Sarah Jenkins & Lead Architect",
            interviewer_email="sarah.recruiter@apextech.io",
            meeting_link="https://meet.google.com/rvx-fullstack-panel",
            location="Google Meet Video",
            notes="Live design exercise on architecting a real-time collaborative workspace with FastAPI and React websockets.",
            status=InterviewStatus.SCHEDULED
        )
        db.add(interview3)

        # Completed interview example
        interview4 = Interview(
            application_id=app4.id,
            job_id=job4.id,
            candidate_id=cand4.id,
            recruiter_id=recruiter1.id,
            title="Frontend Portfolio & Architecture Screening",
            interview_type=InterviewType.HR,
            scheduled_date=(datetime.now(timezone.utc) - timedelta(days=1)).date(),
            scheduled_time=time(10, 0),
            duration_minutes=30,
            interviewer_name="Sarah Jenkins",
            interviewer_email="sarah.recruiter@apextech.io",
            meeting_link="https://meet.google.com/rvx-hr-screen",
            location="Google Meet Video",
            notes="Initial culture, salary expectation, and portfolio alignment review.",
            status=InterviewStatus.COMPLETED,
            feedback="Strong communication skills and great cultural alignment. Strong endorsement.",
            rating=4.8
        )
        db.add(interview4)

        # -------------------------------------------------------------
        # 6. NOTIFICATIONS
        # -------------------------------------------------------------
        db.add(Notification(
            user_id=cand1.id,
            title="Application Shortlisted!",
            message="Congratulations! Your application for Senior Full-Stack AI Engineer has been shortlisted.",
            notification_type="SUCCESS",
            link="/candidate/applications"
        ))
        db.add(Notification(
            user_id=cand2.id,
            title="Interview Invitation Confirmed",
            message="Your Technical Architecture interview has been scheduled for CloudScale Dynamics.",
            notification_type="INTERVIEW",
            link="/candidate/interviews"
        ))
        db.add(Notification(
            user_id=recruiter1.id,
            title="New AI Screening Completed",
            message="AI Screening completed for Alex Rivers (Score: 92.5%).",
            notification_type="INFO",
            link="/recruiter/screening"
        ))

        db.commit()
        print("Database seeding completed successfully!")

    except Exception as e:
        db.rollback()
        print(f"Error seeding database: {e}")
        raise e
    finally:
        db.close()

if __name__ == "__main__":
    seed_database()
