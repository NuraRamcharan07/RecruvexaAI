from typing import Dict, List, Any

class ScoringEngine:
    """
    Computes granular match scores across required dimensions:
    - Skills (35% weight)
    - Experience (25% weight)
    - Education (15% weight)
    - Projects (15% weight)
    - Certifications (10% weight)
    """

    DEFAULT_WEIGHTS = {
        "skills": 0.35,
        "experience": 0.25,
        "education": 0.15,
        "projects": 0.15,
        "certifications": 0.10,
    }

    @classmethod
    def calculate_scores(
        cls,
        candidate_data: Dict[str, Any],
        job_requirements: Dict[str, Any],
        weights: Dict[str, float] = None
    ) -> Dict[str, float]:
        w = weights or cls.DEFAULT_WEIGHTS

        # 1. Skills Match Score
        skills_score = cls._score_skills(
            candidate_skills=candidate_data.get("skills", []),
            required_skills=job_requirements.get("required_skills", []),
            preferred_skills=job_requirements.get("preferred_skills", [])
        )

        # 2. Experience Match Score
        exp_score = cls._score_experience(
            candidate_exp=candidate_data.get("experience_years", 0.0),
            required_exp=job_requirements.get("experience_required", 0.0)
        )

        # 3. Education Match Score
        edu_score = cls._score_education(
            candidate_edu=candidate_data.get("education", []),
            required_edu=job_requirements.get("education_requirements", "")
        )

        # 4. Project Match Score
        proj_score = cls._score_projects(
            candidate_projects=candidate_data.get("projects", []),
            job_description=job_requirements.get("description", "")
        )

        # 5. Certification Match Score
        cert_score = cls._score_certifications(
            candidate_certs=candidate_data.get("certifications", []),
            required_certs=job_requirements.get("certifications", "")
        )

        # Overall Weighted Score
        overall = (
            w["skills"] * skills_score +
            w["experience"] * exp_score +
            w["education"] * edu_score +
            w["projects"] * proj_score +
            w["certifications"] * cert_score
        )
        overall = max(10.0, min(99.5, round(overall, 1)))

        return {
            "overall_score": overall,
            "skills_match_score": round(skills_score, 1),
            "experience_match_score": round(exp_score, 1),
            "education_match_score": round(edu_score, 1),
            "project_match_score": round(proj_score, 1),
            "certification_match_score": round(cert_score, 1),
        }

    @staticmethod
    def _score_skills(candidate_skills: List[str], required_skills: List[str], preferred_skills: List[str]) -> float:
        cand_set = {s.lower().strip() for s in candidate_skills}
        req_set = {s.lower().strip() for s in required_skills if s.strip()}
        pref_set = {s.lower().strip() for s in preferred_skills if s.strip()}

        if not req_set:
            return 85.0 if cand_set else 60.0

        matched_req = cand_set.intersection(req_set)
        req_ratio = len(matched_req) / len(req_set)
        base_score = req_ratio * 80.0  # Up to 80 points for required skills

        # Up to 20 bonus points for preferred skills
        if pref_set:
            matched_pref = cand_set.intersection(pref_set)
            pref_ratio = len(matched_pref) / len(pref_set)
            base_score += pref_ratio * 20.0
        else:
            # If no preferred skills defined, scale required to 100
            base_score = req_ratio * 100.0

        return max(15.0, min(98.0, base_score))

    @staticmethod
    def _score_experience(candidate_exp: float, required_exp: float) -> float:
        if required_exp <= 0:
            return 90.0 if candidate_exp > 0 else 75.0

        ratio = candidate_exp / required_exp
        if ratio >= 1.5:
            return 98.0  # Exceeds requirements
        elif ratio >= 1.0:
            # Meets requirement
            return 85.0 + (ratio - 1.0) * 20.0
        elif ratio >= 0.7:
            # Close to requirement
            return 65.0 + ((ratio - 0.7) / 0.3) * 20.0
        elif ratio >= 0.4:
            # Significantly junior
            return 45.0 + ((ratio - 0.4) / 0.3) * 20.0
        else:
            return max(20.0, ratio * 100.0)

    @staticmethod
    def _score_education(candidate_edu: List[str], required_edu: str) -> float:
        if not required_edu:
            return 85.0

        req_lower = required_edu.lower()
        cand_str = " ".join(candidate_edu).lower()

        # Check for exact or higher degrees
        if "phd" in cand_str or "doctorate" in cand_str:
            return 98.0
        if "master" in req_lower or "m.s" in req_lower or "m.tech" in req_lower:
            if "master" in cand_str or "m.s" in cand_str or "m.tech" in cand_str:
                return 95.0
            elif "bachelor" in cand_str or "b.s" in cand_str or "b.tech" in cand_str:
                return 75.0
            return 50.0

        if "bachelor" in req_lower or "b.s" in req_lower or "b.tech" in req_lower or "degree" in req_lower:
            if any(term in cand_str for term in ["bachelor", "b.s", "b.tech", "master", "m.s", "phd"]):
                return 92.0
            return 60.0

        return 80.0

    @staticmethod
    def _score_projects(candidate_projects: List[str], job_description: str) -> float:
        if not candidate_projects:
            return 55.0
        # If candidate has projects listed, baseline 70-90
        count = len(candidate_projects)
        score = 65.0 + min(count * 8.0, 25.0)
        return min(score, 94.0)

    @staticmethod
    def _score_certifications(candidate_certs: List[str], required_certs: str) -> float:
        if not required_certs:
            # Not strictly required; having any cert is a bonus
            return 90.0 if candidate_certs else 75.0

        cand_str = " ".join(candidate_certs).lower()
        if any(w in cand_str for w in required_certs.lower().split(",")):
            return 95.0
        elif candidate_certs:
            return 75.0
        return 45.0
