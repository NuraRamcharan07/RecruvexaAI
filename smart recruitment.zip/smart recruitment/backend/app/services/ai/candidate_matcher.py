from typing import Dict, List, Any

class CandidateMatcher:
    """
    Compares candidate profile attributes with job requirements
    to isolate matches, gaps, concerns, and qualitative insights.
    """

    @classmethod
    def match(
        cls,
        candidate_data: Dict[str, Any],
        job_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        cand_skills = candidate_data.get("skills", [])
        cand_skills_lower = {s.lower().strip(): s for s in cand_skills}

        # Parse required and preferred skills
        req_skills_raw = job_data.get("required_skills", "")
        if isinstance(req_skills_raw, str):
            req_skills = [s.strip() for s in req_skills_raw.replace(";", ",").split(",") if s.strip()]
        else:
            req_skills = list(req_skills_raw)

        pref_skills_raw = job_data.get("preferred_skills", "")
        if isinstance(pref_skills_raw, str):
            pref_skills = [s.strip() for s in pref_skills_raw.replace(";", ",").split(",") if s.strip()]
        else:
            pref_skills = list(pref_skills_raw)

        all_target_skills = req_skills + pref_skills

        # 1. Matching & Missing Skills
        matching_skills = []
        missing_skills = []

        for req in req_skills:
            if req.lower() in cand_skills_lower:
                matching_skills.append(cand_skills_lower[req.lower()])
            else:
                missing_skills.append(req)

        for pref in pref_skills:
            if pref.lower() in cand_skills_lower:
                if cand_skills_lower[pref.lower()] not in matching_skills:
                    matching_skills.append(cand_skills_lower[pref.lower()])

        # 2. Experience Analysis
        cand_exp = candidate_data.get("experience_years", 0.0)
        req_exp = job_data.get("experience_required", 0.0)
        exp_delta = cand_exp - req_exp

        if exp_delta >= 2:
            rel_exp = f"Strong experience profile: {cand_exp} years exceeds required {req_exp} years."
        elif exp_delta >= 0:
            rel_exp = f"Target aligned: {cand_exp} years meets target threshold of {req_exp} years."
        else:
            rel_exp = f"Slightly below target: {cand_exp} years compared to {req_exp} years specified."

        # 3. Project Highlights
        cand_projects = candidate_data.get("projects", [])
        if cand_projects:
            rel_proj = "Demonstrated practical experience in: " + ", ".join(cand_projects[:3])
        else:
            rel_proj = "No explicitly partitioned portfolio projects documented in resume."

        # 4. Potential Concerns (Assistive flags for recruiters)
        concerns = []
        if exp_delta < -1:
            concerns.append(f"Candidate experience ({cand_exp} yrs) is lower than requested ({req_exp} yrs).")
        if missing_skills:
            concerns.append(f"Key required skills not identified in resume text: {', '.join(missing_skills[:4])}.")
        if not candidate_data.get("education") and job_data.get("education_requirements"):
            concerns.append(f"Formal education credentials not clearly recognized matching '{job_data.get('education_requirements')}'.")

        potential_concerns_str = "; ".join(concerns) if concerns else "None detected. Candidate credentials align closely with job specifications."

        return {
            "matching_skills": matching_skills,
            "missing_skills": missing_skills,
            "relevant_experience": rel_exp,
            "relevant_projects": rel_proj,
            "potential_concerns": potential_concerns_str
        }
