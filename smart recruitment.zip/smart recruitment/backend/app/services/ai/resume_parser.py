import re
import os
from typing import Dict, Any, List, Optional
from pypdf import PdfReader
from docx import Document

# Comprehensive taxonomy of industry skills across tech, data, and management
COMMON_SKILLS_TAXONOMY = [
    # Languages
    "python", "javascript", "typescript", "java", "c++", "c#", "go", "golang", "ruby", "php", "swift", "kotlin", "rust", "scala", "html", "css", "sql", "r",
    # Frontend
    "react", "react.js", "vue", "vue.js", "angular", "next.js", "nuxt", "svelte", "tailwind", "tailwindcss", "redux", "webpack", "vite", "bootstrap", "sass",
    # Backend & Frameworks
    "node.js", "nodejs", "express", "express.js", "fastapi", "django", "flask", "spring", "spring boot", "asp.net", "laravel", "rails", "nestjs", "graphql", "rest api", "grpc",
    # Databases & Storage
    "postgresql", "postgres", "mysql", "mongodb", "sqlite", "redis", "elasticsearch", "dynamodb", "cassandra", "firebase", "supabase", "mariadb", "oracle",
    # Cloud & DevOps
    "aws", "amazon web services", "azure", "google cloud", "gcp", "docker", "kubernetes", "k8s", "terraform", "ansible", "jenkins", "github actions", "gitlab ci", "ci/cd", "linux", "nginx",
    # AI / ML / Data
    "machine learning", "deep learning", "nlp", "computer vision", "tensorflow", "pytorch", "scikit-learn", "pandas", "numpy", "opencv", "llm", "langchain", "data science", "data analysis",
    # Architecture & Practices
    "microservices", "system design", "agile", "scrum", "kanban", "test-driven development", "tdd", "git", "github", "unit testing", "oop",
    # Soft Skills & Business
    "leadership", "project management", "communication", "problem solving", "mentoring", "cross-functional collaboration"
]

COMMON_DEGREES = [
    "ph.d", "phd", "doctorate", "master", "m.s.", "ms", "m.sc", "m.tech", "mba",
    "bachelor", "b.s.", "bs", "b.sc", "b.tech", "b.e.", "bba", "associate"
]

COMMON_CERTIFICATIONS = [
    "aws certified", "solutions architect", "cloud practitioner", "developer associate",
    "azure fundamentals", "google cloud certified", "cka", "ckad", "certified kubernetes",
    "pmp", "project management professional", "scrum master", "csm", "comptia", "cissp"
]

class ResumeParser:
    """
    Extracts text and structured entities from resumes (PDF, DOCX, TXT).
    """

    @staticmethod
    def extract_text(file_path: str, content_type: Optional[str] = None) -> str:
        if not os.path.exists(file_path):
            return ""

        ext = os.path.splitext(file_path)[1].lower()

        try:
            if ext == ".pdf" or (content_type and "pdf" in content_type):
                text_parts = []
                reader = PdfReader(file_path)
                for page in reader.pages:
                    extracted = page.extract_text()
                    if extracted:
                        text_parts.append(extracted)
                return "\n".join(text_parts)

            elif ext in [".docx", ".doc"] or (content_type and "word" in content_type):
                doc = Document(file_path)
                return "\n".join([p.text for p in doc.paragraphs if p.text])

            else:
                with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                    return f.read()

        except Exception as e:
            print(f"Error extracting text from {file_path}: {e}")
            return ""

    @classmethod
    def parse(cls, text: str) -> Dict[str, Any]:
        """
        Parses raw resume text into structured fields.
        """
        email = cls._extract_email(text)
        phone = cls._extract_phone(text)
        name = cls._extract_name(text, email)
        skills = cls._extract_skills(text)
        experience_years = cls._extract_experience_years(text)
        education = cls._extract_education(text)
        certifications = cls._extract_certifications(text)
        projects = cls._extract_projects(text)

        return {
            "name": name,
            "email": email,
            "phone": phone,
            "skills": skills,
            "experience_years": experience_years,
            "education": education,
            "certifications": certifications,
            "projects": projects
        }

    @staticmethod
    def _extract_email(text: str) -> Optional[str]:
        match = re.search(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", text)
        return match.group(0) if match else None

    @staticmethod
    def _extract_phone(text: str) -> Optional[str]:
        match = re.search(r"(\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}", text)
        return match.group(0) if match else None

    @staticmethod
    def _extract_name(text: str, email: Optional[str] = None) -> Optional[str]:
        lines = [line.strip() for line in text.split("\n") if line.strip()]
        for line in lines[:6]:
            # If line is short and doesn't have digits, punctuation, or email
            if 2 <= len(line.split()) <= 4 and not re.search(r"\d|@|www|\.com|http", line):
                # Filter out generic headers
                if not any(header in line.lower() for header in ["resume", "curriculum", "cv", "profile", "page"]):
                    return line
        if email:
            # Fallback: clean email username
            clean = email.split("@")[0].replace(".", " ").replace("_", " ").title()
            return clean
        return "Candidate"

    @classmethod
    def _extract_skills(cls, text: str) -> List[str]:
        text_lower = text.lower()
        found_skills = []
        for skill in COMMON_SKILLS_TAXONOMY:
            # Match whole words or boundary conditions
            pattern = r"(?:\b|_)" + re.escape(skill) + r"(?:\b|_)"
            if re.search(pattern, text_lower):
                # Standardize casing
                found_skills.append(cls._format_skill_name(skill))
        return list(dict.fromkeys(found_skills))  # unique preserved order

    @staticmethod
    def _format_skill_name(skill: str) -> str:
        special_names = {
            "aws": "AWS",
            "gcp": "GCP",
            "sql": "SQL",
            "html": "HTML",
            "css": "CSS",
            "javascript": "JavaScript",
            "typescript": "TypeScript",
            "postgresql": "PostgreSQL",
            "mongodb": "MongoDB",
            "fastapi": "FastAPI",
            "react": "React",
            "vue": "Vue.js",
            "nlp": "NLP",
            "llm": "LLM",
            "ci/cd": "CI/CD",
            "node.js": "Node.js",
            "k8s": "Kubernetes",
            "docker": "Docker"
        }
        return special_names.get(skill.lower(), skill.title())

    @staticmethod
    def _extract_experience_years(text: str) -> float:
        # Pattern 1: explicit mentions like "5+ years of experience"
        exp_match = re.search(r"(\d+(?:\.\d+)?)\+?\s*(?:years?|yrs?)(?:\s+of)?\s+experience", text, re.IGNORECASE)
        if exp_match:
            try:
                return float(exp_match.group(1))
            except ValueError:
                pass

        # Pattern 2: count year ranges e.g. 2018 - 2023 or 2020 - Present
        year_ranges = re.findall(r"(20\d\d|19\d\d)\s*(?:-|–|to)\s*(20\d\d|present|current)", text, re.IGNORECASE)
        total_years = 0.0
        current_year = 2026

        for start, end in year_ranges:
            try:
                s = int(start)
                e = current_year if end.lower() in ["present", "current"] else int(end)
                diff = max(0, e - s)
                if diff < 30:  # avoid spurious ranges
                    total_years += diff
            except ValueError:
                continue

        if total_years > 0:
            return round(min(total_years, 25.0), 1)

        return 2.0  # Default baseline assumption if not explicitly extracted

    @classmethod
    def _extract_education(cls, text: str) -> List[str]:
        text_lower = text.lower()
        found = []
        for degree in COMMON_DEGREES:
            if re.search(r"\b" + re.escape(degree) + r"\b", text_lower):
                found.append(degree.upper() if len(degree) <= 4 else degree.title())
        return list(dict.fromkeys(found))

    @classmethod
    def _extract_certifications(cls, text: str) -> List[str]:
        text_lower = text.lower()
        found = []
        for cert in COMMON_CERTIFICATIONS:
            if re.search(r"\b" + re.escape(cert) + r"\b", text_lower):
                found.append(cert.title())
        return list(dict.fromkeys(found))

    @staticmethod
    def _extract_projects(text: str) -> List[str]:
        # Search for sections named Projects or project bullet points
        projects = []
        lines = text.split("\n")
        in_project_section = False

        for line in lines:
            line_str = line.strip()
            if not line_str:
                continue
            if re.search(r"^(?:projects|personal projects|key projects|academic projects)", line_str, re.IGNORECASE):
                in_project_section = True
                continue
            if in_project_section:
                # Stop if another main section starts
                if re.search(r"^(?:education|experience|skills|certifications|awards|summary)", line_str, re.IGNORECASE):
                    break
                # If bullet point or short bold-like line
                if line_str.startswith(("-", "•", "*", "–")) or len(line_str.split()) < 8:
                    clean = re.sub(r"^[-•*–]\s*", "", line_str)
                    if len(clean) > 8 and not any(p in clean.lower() for p in ["github", "link", "demo"]):
                        projects.append(clean[:80])
                        if len(projects) >= 4:
                            break

        return projects
