import json
from typing import Dict, Any
from app.services.ai.scoring_engine import ScoringEngine
from app.services.ai.candidate_matcher import CandidateMatcher

class ResumeAnalyzer:
    """
    Unified AI analysis pipeline comparing candidate data against job specifications.
    Employs assistive decision support principles (human-in-the-loop).
    """

    @classmethod
    def analyze(cls, candidate_data: Dict[str, Any], job_data: Dict[str, Any]) -> Dict[str, Any]:
        # 1. Match skills, gaps, concerns
        match_info = CandidateMatcher.match(candidate_data, job_data)

        # 2. Score across all 5 dimensions
        req_skills_raw = job_data.get("required_skills", "")
        if isinstance(req_skills_raw, str):
            req_skills = [s.strip() for s in req_skills_raw.replace(";", ",").split(",") if s.strip()]
        else:
            req_skills = list(req_skills_raw)

        pref_skills_raw = job_data.get("preferred_skills", "")
        if isinstance(pref_skills_raw, str):
            pref_skills = [s.strip() for s in pref_skills_raw.replace(";", ",").split(",") if s.strip()]
        else:
            pref_skills = list(pref_skills_raw)

        job_reqs_for_scoring = {
            "required_skills": req_skills,
            "preferred_skills": pref_skills,
            "experience_required": job_data.get("experience_required", 0.0),
            "education_requirements": job_data.get("education_requirements", ""),
            "certifications": job_data.get("certifications", ""),
            "description": job_data.get("description", "")
        }

        scores = ScoringEngine.calculate_scores(candidate_data, job_reqs_for_scoring)

        overall = scores["overall_score"]

        # 3. Categorize recommendation tier
        if overall >= 85.0:
            recommendation = "STRONG_MATCH"
        elif overall >= 72.0:
            recommendation = "GOOD_MATCH"
        elif overall >= 55.0:
            recommendation = "PARTIAL_MATCH"
        else:
            recommendation = "LOW_MATCH"

        # 4. Generate AI Executive Summary
        cand_name = candidate_data.get("name", "The candidate")
        job_title = job_data.get("title", "this position")
        cand_exp = candidate_data.get("experience_years", 0)
        matching_count = len(match_info["matching_skills"])
        missing_count = len(match_info["missing_skills"])

        ai_summary = (
            f"{cand_name} presents an overall {overall}% compatibility rating for the {job_title} role. "
            f"Demonstrates {cand_exp} years of relevant domain experience and satisfies {matching_count} core technical skills. "
        )

        if missing_count > 0:
            missing_preview = ", ".join(match_info["missing_skills"][:3])
            ai_summary += f"Screening indicates secondary skill development opportunities in {missing_preview}. "
        else:
            ai_summary += "Demonstrates comprehensive technical coverage across all specified requirements. "

        if overall >= 80:
            ai_summary += "Recommended for immediate recruiter interview screening."
        elif overall >= 65:
            ai_summary += "Suitable candidate for technical assessment and phone review."
        else:
            ai_summary += "Recruiter review recommended to evaluate transferable capabilities."

        return {
            **scores,
            "matching_skills": json.dumps(match_info["matching_skills"]),
            "missing_skills": json.dumps(match_info["missing_skills"]),
            "relevant_experience": match_info["relevant_experience"],
            "relevant_projects": match_info["relevant_projects"],
            "potential_concerns": match_info["potential_concerns"],
            "ai_summary": ai_summary,
            "recommendation": recommendation,
        }
