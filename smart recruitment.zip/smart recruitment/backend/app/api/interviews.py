from typing import List, Optional
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from sqlalchemy import desc, or_
from app.database.session import get_db
from app.models.interview import Interview, InterviewType, InterviewStatus
from app.models.application import Application, ApplicationStatus, ApplicationStatusHistory
from app.models.job import Job
from app.models.user import User, UserRole
from app.models.notification import Notification
from app.schemas.interview import InterviewCreate, InterviewUpdate, InterviewResponse
from app.api.deps import get_current_user, require_role, log_audit

router = APIRouter(prefix="/interviews", tags=["Interviews"])

def build_interview_response(itv: Interview) -> InterviewResponse:
    cand_name = itv.candidate.full_name if itv.candidate else "Candidate"
    cand_email = itv.candidate.email if itv.candidate else ""
    job_title = itv.job.title if itv.job else "Position"
    company_name = itv.recruiter.recruiter_profile.company_name if (itv.recruiter and itv.recruiter.recruiter_profile) else "Enterprise Partner"

    return InterviewResponse(
        id=itv.id,
        application_id=itv.application_id,
        job_id=itv.job_id,
        candidate_id=itv.candidate_id,
        recruiter_id=itv.recruiter_id,
        title=itv.title,
        interview_type=itv.interview_type,
        scheduled_date=itv.scheduled_date,
        scheduled_time=itv.scheduled_time,
        duration_minutes=itv.duration_minutes,
        interviewer_name=itv.interviewer_name,
        interviewer_email=itv.interviewer_email,
        meeting_link=itv.meeting_link,
        location=itv.location,
        notes=itv.notes,
        status=itv.status,
        feedback=itv.feedback,
        rating=itv.rating,
        created_at=itv.created_at,
        candidate_name=cand_name,
        candidate_email=cand_email,
        job_title=job_title,
        company_name=company_name
    )

@router.post("", response_model=InterviewResponse, status_code=status.HTTP_201_CREATED)
def schedule_interview(
    itv_in: InterviewCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([UserRole.RECRUITER, UserRole.ADMIN]))
):
    app = db.query(Application).filter(Application.id == itv_in.application_id).first()
    if not app:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Application not found")

    job = app.job
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Associated job not found")

    # Conflict check: Check if candidate already has an interview on the same date/time
    conflict = db.query(Interview).filter(
        Interview.candidate_id == app.candidate_id,
        Interview.scheduled_date == itv_in.scheduled_date,
        Interview.scheduled_time == itv_in.scheduled_time,
        Interview.status == InterviewStatus.SCHEDULED
    ).first()
    if conflict:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Scheduling conflict: Candidate already has an interview scheduled for {itv_in.scheduled_date} at {itv_in.scheduled_time}."
        )

    interview = Interview(
        application_id=app.id,
        job_id=job.id,
        candidate_id=app.candidate_id,
        recruiter_id=current_user.id,
        title=itv_in.title,
        interview_type=itv_in.interview_type,
        scheduled_date=itv_in.scheduled_date,
        scheduled_time=itv_in.scheduled_time,
        duration_minutes=itv_in.duration_minutes,
        interviewer_name=itv_in.interviewer_name,
        interviewer_email=itv_in.interviewer_email,
        meeting_link=itv_in.meeting_link,
        location=itv_in.location,
        notes=itv_in.notes,
        status=InterviewStatus.SCHEDULED,
    )
    db.add(interview)

    # Advance application status to INTERVIEW_SCHEDULED
    previous_status = app.status.value
    app.status = ApplicationStatus.INTERVIEW_SCHEDULED
    app.current_stage = "Interview Scheduled"

    history = ApplicationStatusHistory(
        application_id=app.id,
        previous_status=previous_status,
        new_status=ApplicationStatus.INTERVIEW_SCHEDULED.value,
        changed_by_user_id=current_user.id,
        notes=f"Scheduled {itv_in.interview_type.value} interview with {itv_in.interviewer_name}"
    )
    db.add(history)

    # Dispatch notification to Candidate
    date_formatted = itv_in.scheduled_date.strftime("%B %d, %Y")
    time_formatted = itv_in.scheduled_time.strftime("%I:%M %p")
    cand_notif = Notification(
        user_id=app.candidate_id,
        title=f"Interview Invitation: {job.title}",
        message=f"You have been invited for a {itv_in.interview_type.value.replace('_', ' ').title()} Interview on {date_formatted} at {time_formatted}.",
        notification_type="INTERVIEW",
        link="/candidate/interviews"
    )
    db.add(cand_notif)

    db.commit()
    db.refresh(interview)

    log_audit(db, current_user.id, "SCHEDULE_INTERVIEW", "INTERVIEW", interview.id, f"Scheduled interview for {job.title}")

    return build_interview_response(interview)

@router.get("", response_model=List[InterviewResponse])
def get_interviews(
    status_filter: Optional[InterviewStatus] = Query(None, alias="status"),
    interview_type: Optional[InterviewType] = Query(None),
    job_id: Optional[int] = Query(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    query = db.query(Interview)

    if current_user.role == UserRole.CANDIDATE:
        query = query.filter(Interview.candidate_id == current_user.id)
    elif current_user.role == UserRole.RECRUITER:
        query = query.filter(Interview.recruiter_id == current_user.id)

    if status_filter:
        query = query.filter(Interview.status == status_filter)
    if interview_type:
        query = query.filter(Interview.interview_type == interview_type)
    if job_id:
        query = query.filter(Interview.job_id == job_id)

    interviews = query.order_by(Interview.scheduled_date.asc(), Interview.scheduled_time.asc()).all()
    return [build_interview_response(i) for i in interviews]

@router.get("/{id}", response_model=InterviewResponse)
def get_interview(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    itv = db.query(Interview).filter(Interview.id == id).first()
    if not itv:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Interview not found")

    if current_user.role == UserRole.CANDIDATE and itv.candidate_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    return build_interview_response(itv)

@router.put("/{id}", response_model=InterviewResponse)
def update_interview(
    id: int,
    itv_update: InterviewUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([UserRole.RECRUITER, UserRole.ADMIN]))
):
    itv = db.query(Interview).filter(Interview.id == id).first()
    if not itv:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Interview not found")

    update_dict = itv_update.dict(exclude_unset=True)
    old_status = itv.status

    for key, value in update_dict.items():
        setattr(itv, key, value)

    itv.updated_at = datetime.now(timezone.utc)

    # If status transitioned to COMPLETED, update application status if needed
    if itv.status == InterviewStatus.COMPLETED and old_status != InterviewStatus.COMPLETED:
        app = db.query(Application).filter(Application.id == itv.application_id).first()
        if app:
            app.status = ApplicationStatus.INTERVIEW_COMPLETED
            app.current_stage = "Interview Completed"
            history = ApplicationStatusHistory(
                application_id=app.id,
                previous_status=old_status.value,
                new_status=ApplicationStatus.INTERVIEW_COMPLETED.value,
                changed_by_user_id=current_user.id,
                notes=f"Completed {itv.interview_type.value} interview with rating {itv.rating or 'N/A'}"
            )
            db.add(history)

    db.commit()
    db.refresh(itv)

    log_audit(db, current_user.id, "UPDATE_INTERVIEW", "INTERVIEW", itv.id, "Updated interview details")

    return build_interview_response(itv)

@router.delete("/{id}")
def cancel_interview(
    id: int,
    reason: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([UserRole.RECRUITER, UserRole.ADMIN]))
):
    itv = db.query(Interview).filter(Interview.id == id).first()
    if not itv:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Interview not found")

    itv.status = InterviewStatus.CANCELLED
    itv.notes = f"Cancelled: {reason}" if reason else "Cancelled by recruiter"
    itv.updated_at = datetime.now(timezone.utc)

    # Notify candidate
    notif = Notification(
        user_id=itv.candidate_id,
        title="Interview Cancelled",
        message=f"Your scheduled interview for {itv.job.title} has been cancelled.",
        notification_type="WARNING",
        link="/candidate/interviews"
    )
    db.add(notif)

    db.commit()
    log_audit(db, current_user.id, "CANCEL_INTERVIEW", "INTERVIEW", id, reason or "Cancelled")

    return {"message": "Interview cancelled successfully"}
