from typing import List, Optional
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from sqlalchemy import or_, desc
from app.database.session import get_db
from app.models.user import User, CandidateProfile, UserRole
from app.models.application import Application
from app.models.resume import Resume
from app.schemas.user import CandidateProfileUpdate, CandidateProfileResponse, UserProfileResponse
from app.schemas.application import ApplicationResponse
from app.api.deps import get_current_user, require_role, log_audit

router = APIRouter(prefix="/candidates", tags=["Candidates"])

@router.get("", response_model=List[UserProfileResponse])
def get_candidates(
    q: Optional[str] = Query(None, description="Search by name, headline, skills, or location"),
    min_experience: Optional[float] = Query(None),
    skill: Optional[str] = Query(None),
    location: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([UserRole.RECRUITER, UserRole.ADMIN]))
):
    query = db.query(User).filter(User.role == UserRole.CANDIDATE, User.is_active == True)

    if q or min_experience or skill or location:
        query = query.join(CandidateProfile)

        if q:
            search_pattern = f"%{q}%"
            query = query.filter(
                or_(
                    User.full_name.ilike(search_pattern),
                    User.email.ilike(search_pattern),
                    CandidateProfile.headline.ilike(search_pattern),
                    CandidateProfile.skills_text.ilike(search_pattern),
                    CandidateProfile.location.ilike(search_pattern)
                )
            )
        if min_experience is not None:
            query = query.filter(CandidateProfile.total_experience_years >= min_experience)
        if skill:
            query = query.filter(CandidateProfile.skills_text.ilike(f"%{skill}%"))
        if location:
            query = query.filter(CandidateProfile.location.ilike(f"%{location}%"))

    candidates = query.order_by(desc(User.created_at)).all()
    return candidates

@router.get("/{id}", response_model=UserProfileResponse)
def get_candidate(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    user = db.query(User).filter(User.id == id, User.role == UserRole.CANDIDATE).first()
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Candidate not found")

    return user

@router.put("/profile", response_model=CandidateProfileResponse)
def update_candidate_profile(
    profile_in: CandidateProfileUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([UserRole.CANDIDATE, UserRole.ADMIN]))
):
    profile = db.query(CandidateProfile).filter(CandidateProfile.user_id == current_user.id).first()
    if not profile:
        profile = CandidateProfile(user_id=current_user.id)
        db.add(profile)

    update_data = profile_in.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(profile, field, value)

    profile.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(profile)

    log_audit(db, current_user.id, "UPDATE_PROFILE", "CANDIDATE_PROFILE", profile.id, "Updated candidate profile")

    return profile
