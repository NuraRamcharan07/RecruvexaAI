import os
import uuid
from typing import List
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, status
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from app.database.session import get_db
from app.core.config import settings
from app.models.resume import Resume
from app.models.user import User, UserRole
from app.schemas.resume import ResumeResponse
from app.services.ai.resume_parser import ResumeParser
from app.api.deps import get_current_user, require_role, log_audit

router = APIRouter(prefix="/resumes", tags=["Resumes"])

@router.post("/upload", response_model=ResumeResponse, status_code=status.HTTP_201_CREATED)
async def upload_resume(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Validate extension
    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in settings.ALLOWED_RESUME_EXTENSIONS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported file format '{ext}'. Allowed formats: {', '.join(settings.ALLOWED_RESUME_EXTENSIONS)}"
        )

    # Read content and check size limit
    content = await file.read()
    if len(content) > settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"File exceeds maximum size of {settings.MAX_UPLOAD_SIZE_MB}MB"
        )

    # Save to disk
    unique_filename = f"{uuid.uuid4()}{ext}"
    file_path = os.path.join(settings.UPLOAD_DIR, unique_filename)
    with open(file_path, "wb") as f:
        f.write(content)

    # Extract text and parse entities via AI ResumeParser
    extracted_text = ResumeParser.extract_text(file_path, file.content_type)
    parsed_info = ResumeParser.parse(extracted_text)

    # Mark existing resumes as non-primary if this is primary
    db.query(Resume).filter(Resume.candidate_id == current_user.id).update({"is_primary": False})

    resume = Resume(
        candidate_id=current_user.id,
        filename=unique_filename,
        original_name=file.filename,
        file_path=file_path,
        file_size=len(content),
        content_type=file.content_type or "application/octet-stream",
        raw_text=extracted_text,
        parsed_name=parsed_info.get("name") or current_user.full_name,
        parsed_email=parsed_info.get("email") or current_user.email,
        parsed_phone=parsed_info.get("phone") or current_user.phone,
        parsed_skills=", ".join(parsed_info.get("skills", [])),
        parsed_experience_years=parsed_info.get("experience_years", 0.0),
        parsed_education=", ".join(parsed_info.get("education", [])),
        parsed_certifications=", ".join(parsed_info.get("certifications", [])),
        parsed_projects="; ".join(parsed_info.get("projects", [])),
        is_primary=True,
    )
    db.add(resume)

    # Update candidate profile if fields are empty
    if current_user.candidate_profile:
        cp = current_user.candidate_profile
        if not cp.skills_text and resume.parsed_skills:
            cp.skills_text = resume.parsed_skills
        if (cp.total_experience_years is None or cp.total_experience_years == 0) and resume.parsed_experience_years:
            cp.total_experience_years = resume.parsed_experience_years
        if not cp.education_level and resume.parsed_education:
            cp.education_level = resume.parsed_education

    db.commit()
    db.refresh(resume)

    log_audit(db, current_user.id, "UPLOAD_RESUME", "RESUME", resume.id, f"Uploaded {file.filename}")

    return resume

@router.get("/my", response_model=List[ResumeResponse])
def get_my_resumes(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    return db.query(Resume).filter(Resume.candidate_id == current_user.id).order_by(Resume.created_at.desc()).all()

@router.get("/{id}", response_model=ResumeResponse)
def get_resume(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    resume = db.query(Resume).filter(Resume.id == id).first()
    if not resume:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Resume not found")

    # Authorization check
    if current_user.role == UserRole.CANDIDATE and resume.candidate_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    return resume

@router.get("/{id}/download")
def download_resume(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    resume = db.query(Resume).filter(Resume.id == id).first()
    if not resume:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Resume not found")

    if current_user.role == UserRole.CANDIDATE and resume.candidate_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    if not os.path.exists(resume.file_path):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Physical file missing on server")

    return FileResponse(
        path=resume.file_path,
        filename=resume.original_name,
        media_type=resume.content_type
    )

@router.delete("/{id}")
def delete_resume(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    resume = db.query(Resume).filter(Resume.id == id).first()
    if not resume:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Resume not found")

    if current_user.role == UserRole.CANDIDATE and resume.candidate_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    if os.path.exists(resume.file_path):
        try:
            os.remove(resume.file_path)
        except Exception:
            pass

    db.delete(resume)
    db.commit()

    log_audit(db, current_user.id, "DELETE_RESUME", "RESUME", id, "Deleted resume file")
    return {"message": "Resume deleted successfully"}
