from typing import Optional, List
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from sqlalchemy import or_, desc
from app.database.session import get_db
from app.models.job import Job, JobSkill, JobStatus, EmploymentType
from app.models.user import User, UserRole
from app.models.application import Application
from app.schemas.job import JobCreate, JobUpdate, JobResponse, JobListResponse, JobRecruiterInfo
from app.api.deps import get_current_user, get_current_user_optional, require_role, log_audit

router = APIRouter(prefix="/jobs", tags=["Jobs"])

@router.get("", response_model=JobListResponse)
def get_jobs(
    q: Optional[str] = Query(None, description="Search keyword in title, description, or skills"),
    department: Optional[str] = Query(None),
    employment_type: Optional[EmploymentType] = Query(None),
    location: Optional[str] = Query(None),
    status_filter: Optional[JobStatus] = Query(None, alias="status"),
    recruiter_only: bool = Query(False),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    query = db.query(Job)

    # If recruiter specifically requested their own jobs
    if recruiter_only and current_user:
        query = query.filter(Job.recruiter_id == current_user.id)
    elif not current_user or current_user.role == UserRole.CANDIDATE:
        # Candidates and public only see PUBLISHED jobs
        query = query.filter(Job.status == JobStatus.PUBLISHED)
    elif status_filter:
        query = query.filter(Job.status == status_filter)

    # Keyword search
    if q:
        search_pattern = f"%{q}%"
        query = query.filter(
            or_(
                Job.title.ilike(search_pattern),
                Job.description.ilike(search_pattern),
                Job.required_skills.ilike(search_pattern),
                Job.department.ilike(search_pattern)
            )
        )

    if department:
        query = query.filter(Job.department.ilike(f"%{department}%"))
    if employment_type:
        query = query.filter(Job.employment_type == employment_type)
    if location:
        query = query.filter(Job.location.ilike(f"%{location}%"))

    total = query.count()
    jobs = query.order_by(desc(Job.created_at)).offset((page - 1) * page_size).limit(page_size).all()

    # Enrich with application count and recruiter details
    items = []
    for j in jobs:
        app_count = db.query(Application).filter(Application.job_id == j.id).count()
        recruiter_info = None
        if j.recruiter:
            company = j.recruiter.recruiter_profile.company_name if j.recruiter.recruiter_profile else "Enterprise Partner"
            recruiter_info = JobRecruiterInfo(
                id=j.recruiter.id,
                full_name=j.recruiter.full_name,
                email=j.recruiter.email,
                company_name=company
            )

        resp = JobResponse(
            id=j.id,
            recruiter_id=j.recruiter_id,
            title=j.title,
            department=j.department,
            location=j.location,
            employment_type=j.employment_type,
            experience_required=j.experience_required,
            min_salary=j.min_salary,
            max_salary=j.max_salary,
            salary_currency=j.salary_currency,
            description=j.description,
            responsibilities=j.responsibilities,
            required_skills=j.required_skills,
            preferred_skills=j.preferred_skills,
            education_requirements=j.education_requirements,
            certifications=j.certifications,
            deadline=j.deadline,
            status=j.status,
            views_count=j.views_count,
            created_at=j.created_at,
            updated_at=j.updated_at,
            applications_count=app_count,
            recruiter=recruiter_info
        )
        items.append(resp)

    return JobListResponse(
        items=items,
        total=total,
        page=page,
        page_size=page_size
    )

@router.post("", response_model=JobResponse, status_code=status.HTTP_201_CREATED)
def create_job(
    job_in: JobCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([UserRole.RECRUITER, UserRole.ADMIN]))
):
    job = Job(
        recruiter_id=current_user.id,
        title=job_in.title,
        department=job_in.department,
        location=job_in.location,
        employment_type=job_in.employment_type,
        experience_required=job_in.experience_required,
        min_salary=job_in.min_salary,
        max_salary=job_in.max_salary,
        salary_currency=job_in.salary_currency,
        description=job_in.description,
        responsibilities=job_in.responsibilities,
        required_skills=job_in.required_skills,
        preferred_skills=job_in.preferred_skills,
        education_requirements=job_in.education_requirements,
        certifications=job_in.certifications,
        deadline=job_in.deadline,
        status=job_in.status,
    )
    db.add(job)
    db.flush()

    # Index required skills into job_skills
    skills_list = [s.strip() for s in job_in.required_skills.split(",") if s.strip()]
    for s in skills_list:
        db.add(JobSkill(job_id=job.id, skill_name=s, is_required=True, weight=1.0))

    db.commit()
    db.refresh(job)

    log_audit(db, current_user.id, "CREATE_JOB", "JOB", job.id, f"Created job posting: {job.title}")

    return job

@router.get("/{id}", response_model=JobResponse)
def get_job(id: int, db: Session = Depends(get_db)):
    job = db.query(Job).filter(Job.id == id).first()
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job position not found")

    # Increment view count
    job.views_count += 1
    db.commit()

    app_count = db.query(Application).filter(Application.job_id == job.id).count()
    recruiter_info = None
    if job.recruiter:
        company = job.recruiter.recruiter_profile.company_name if job.recruiter.recruiter_profile else "Enterprise Partner"
        recruiter_info = JobRecruiterInfo(
            id=job.recruiter.id,
            full_name=job.recruiter.full_name,
            email=job.recruiter.email,
            company_name=company
        )

    return JobResponse(
        id=job.id,
        recruiter_id=job.recruiter_id,
        title=job.title,
        department=job.department,
        location=job.location,
        employment_type=job.employment_type,
        experience_required=job.experience_required,
        min_salary=job.min_salary,
        max_salary=job.max_salary,
        salary_currency=job.salary_currency,
        description=job.description,
        responsibilities=job.responsibilities,
        required_skills=job.required_skills,
        preferred_skills=job.preferred_skills,
        education_requirements=job.education_requirements,
        certifications=job.certifications,
        deadline=job.deadline,
        status=job.status,
        views_count=job.views_count,
        created_at=job.created_at,
        updated_at=job.updated_at,
        applications_count=app_count,
        recruiter=recruiter_info
    )

@router.put("/{id}", response_model=JobResponse)
def update_job(
    id: int,
    job_in: JobUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([UserRole.RECRUITER, UserRole.ADMIN]))
):
    job = db.query(Job).filter(Job.id == id).first()
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job position not found")

    if current_user.role != UserRole.ADMIN and job.recruiter_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="You can only edit your own jobs")

    update_data = job_in.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(job, field, value)

    job.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(job)

    log_audit(db, current_user.id, "UPDATE_JOB", "JOB", job.id, f"Updated job posting: {job.title}")
    return job

@router.delete("/{id}")
def delete_job(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([UserRole.RECRUITER, UserRole.ADMIN]))
):
    job = db.query(Job).filter(Job.id == id).first()
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job position not found")

    if current_user.role != UserRole.ADMIN and job.recruiter_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="You can only delete your own jobs")

    db.delete(job)
    db.commit()
    log_audit(db, current_user.id, "DELETE_JOB", "JOB", id, "Deleted job posting")
    return {"message": "Job deleted successfully"}

@router.post("/{id}/duplicate", response_model=JobResponse)
def duplicate_job(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([UserRole.RECRUITER, UserRole.ADMIN]))
):
    source = db.query(Job).filter(Job.id == id).first()
    if not source:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job position not found")

    duplicated = Job(
        recruiter_id=current_user.id,
        title=f"{source.title} (Copy)",
        department=source.department,
        location=source.location,
        employment_type=source.employment_type,
        experience_required=source.experience_required,
        min_salary=source.min_salary,
        max_salary=source.max_salary,
        salary_currency=source.salary_currency,
        description=source.description,
        responsibilities=source.responsibilities,
        required_skills=source.required_skills,
        preferred_skills=source.preferred_skills,
        education_requirements=source.education_requirements,
        certifications=source.certifications,
        deadline=source.deadline,
        status=JobStatus.DRAFT,
    )
    db.add(duplicated)
    db.commit()
    db.refresh(duplicated)

    log_audit(db, current_user.id, "DUPLICATE_JOB", "JOB", duplicated.id, f"Duplicated from job {source.id}")
    return duplicated

@router.post("/{id}/status", response_model=JobResponse)
def set_job_status(
    id: int,
    status_target: JobStatus = Query(..., alias="status"),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([UserRole.RECRUITER, UserRole.ADMIN]))
):
    job = db.query(Job).filter(Job.id == id).first()
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job position not found")

    if current_user.role != UserRole.ADMIN and job.recruiter_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="You can only alter your own jobs")

    job.status = status_target
    job.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(job)

    log_audit(db, current_user.id, "SET_JOB_STATUS", "JOB", job.id, f"Changed status to {status_target.value}")
    return job
