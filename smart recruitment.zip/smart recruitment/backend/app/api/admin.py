from typing import List
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from sqlalchemy import desc
from app.database.session import get_db
from app.models.user import User, UserRole
from app.models.job import Job
from app.models.application import Application
from app.models.interview import Interview, InterviewStatus
from app.schemas.admin import AdminSystemOverview, AdminUserItem, AISettingsConfig
from app.api.deps import get_current_admin, log_audit

router = APIRouter(prefix="/admin", tags=["Administration"])

# Memory cache for AI config settings during session
CURRENT_AI_CONFIG = {
    "provider": "local",
    "skills_weight": 0.35,
    "experience_weight": 0.25,
    "education_weight": 0.15,
    "project_weight": 0.15,
    "certification_weight": 0.10,
    "auto_tagging_enabled": True,
    "minimum_shortlist_threshold": 75.0
}

@router.get("/overview", response_model=AdminSystemOverview)
def get_system_overview(
    db: Session = Depends(get_db),
    admin_user: User = Depends(get_current_admin)
):
    total_users = db.query(User).count()
    total_recruiters = db.query(User).filter(User.role == UserRole.RECRUITER).count()
    total_candidates = db.query(User).filter(User.role == UserRole.CANDIDATE).count()
    total_jobs = db.query(Job).count()
    total_applications = db.query(Application).count()
    active_itvs = db.query(Interview).filter(Interview.status == InterviewStatus.SCHEDULED).count()

    return AdminSystemOverview(
        total_users=total_users,
        total_recruiters=total_recruiters,
        total_candidates=total_candidates,
        total_jobs=total_jobs,
        total_applications=total_applications,
        active_interviews=active_itvs,
        system_health="OPTIMAL",
        ai_status="READY (Deterministic & Semantic Engine Active)",
        storage_used_mb=18.6
    )

@router.get("/users", response_model=List[AdminUserItem])
def list_users(
    role: str = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db),
    admin_user: User = Depends(get_current_admin)
):
    query = db.query(User)
    if role:
        query = query.filter(User.role == role)

    users = query.order_by(desc(User.created_at)).offset((page - 1) * page_size).limit(page_size).all()

    items = []
    for u in users:
        app_count = db.query(Application).filter(Application.candidate_id == u.id).count()
        job_count = db.query(Job).filter(Job.recruiter_id == u.id).count()
        items.append(AdminUserItem(
            id=u.id,
            email=u.email,
            full_name=u.full_name,
            role=u.role,
            is_active=u.is_active,
            is_verified=u.is_verified,
            created_at=u.created_at,
            applications_count=app_count,
            jobs_count=job_count
        ))

    return items

@router.put("/users/{id}/toggle-active")
def toggle_user_active(
    id: int,
    db: Session = Depends(get_db),
    admin_user: User = Depends(get_current_admin)
):
    user = db.query(User).filter(User.id == id).first()
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

    user.is_active = not user.is_active
    db.commit()

    log_audit(db, admin_user.id, "TOGGLE_USER_STATUS", "USER", user.id, f"Set active: {user.is_active}")
    return {"message": f"User {user.email} active status set to {user.is_active}", "is_active": user.is_active}

@router.get("/settings/ai", response_model=AISettingsConfig)
def get_ai_settings(admin_user: User = Depends(get_current_admin)):
    return AISettingsConfig(**CURRENT_AI_CONFIG)

@router.put("/settings/ai", response_model=AISettingsConfig)
def update_ai_settings(
    config: AISettingsConfig,
    db: Session = Depends(get_db),
    admin_user: User = Depends(get_current_admin)
):
    global CURRENT_AI_CONFIG
    CURRENT_AI_CONFIG = config.dict()
    log_audit(db, admin_user.id, "UPDATE_AI_CONFIG", "SYSTEM", None, "Updated AI scoring weights")
    return config
