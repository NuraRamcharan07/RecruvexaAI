import json
from typing import List, Optional
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from sqlalchemy import desc
from app.database.session import get_db
from app.models.application import Application, ApplicationStatus
from app.models.job import Job
from app.models.resume import Resume
from app.models.user import User, UserRole
from app.models.screening import CandidateScore
from app.schemas.screening import CandidateScoreResponse, CandidateRankItem
from app.services.ai.resume_analyzer import ResumeAnalyzer
from app.api.deps import get_current_user, require_role, log_audit

router = APIRouter(prefix="/screening", tags=["AI Screening"])

@router.post("/analyze/{application_id}", response_model=CandidateScoreResponse)
def trigger_screening_analysis(
    application_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([UserRole.RECRUITER, UserRole.ADMIN]))
):
    app = db.query(Application).filter(Application.id == application_id).first()
    if not app:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Application not found")

    job = app.job
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found")

    resume = app.resume
    if not resume:
        # Try finding the candidate's primary resume
        resume = db.query(Resume).filter(Resume.candidate_id == app.candidate_id, Resume.is_primary == True).first()
        if not resume:
            resume = db.query(Resume).filter(Resume.candidate_id == app.candidate_id).order_by(Resume.created_at.desc()).first()

    candidate = app.candidate
    cand_profile = candidate.candidate_profile if candidate else None

    # Compile candidate profile
    skills = []
    if resume and resume.parsed_skills:
        skills = [s.strip() for s in resume.parsed_skills.split(",") if s.strip()]
    elif cand_profile and cand_profile.skills_text:
        skills = [s.strip() for s in cand_profile.skills_text.split(",") if s.strip()]

    exp = (resume.parsed_experience_years if resume else None) or (cand_profile.total_experience_years if cand_profile else 0.0)
    education = [resume.parsed_education] if (resume and resume.parsed_education) else ([cand_profile.education_level] if (cand_profile and cand_profile.education_level) else [])
    certifications = [resume.parsed_certifications] if (resume and resume.parsed_certifications) else []
    projects = [p.strip() for p in (resume.parsed_projects or "").split(";") if p.strip()] if resume else []

    candidate_dict = {
        "name": candidate.full_name if candidate else "Candidate",
        "skills": skills,
        "experience_years": exp or 0.0,
        "education": education,
        "certifications": certifications,
        "projects": projects
    }

    job_dict = {
        "title": job.title,
        "required_skills": job.required_skills,
        "preferred_skills": job.preferred_skills,
        "experience_required": job.experience_required,
        "education_requirements": job.education_requirements,
        "certifications": job.certifications,
        "description": job.description
    }

    ai_result = ResumeAnalyzer.analyze(candidate_dict, job_dict)

    # Save or update CandidateScore record
    score_record = db.query(CandidateScore).filter(CandidateScore.application_id == app.id).first()
    if not score_record:
        score_record = CandidateScore(
            application_id=app.id,
            job_id=job.id,
            candidate_id=candidate.id,
            overall_score=ai_result["overall_score"],
            skills_match_score=ai_result["skills_match_score"],
            experience_match_score=ai_result["experience_match_score"],
            education_match_score=ai_result["education_match_score"],
            project_match_score=ai_result["project_match_score"],
            certification_match_score=ai_result["certification_match_score"],
            matching_skills=ai_result["matching_skills"],
            missing_skills=ai_result["missing_skills"],
            relevant_experience=ai_result["relevant_experience"],
            relevant_projects=ai_result["relevant_projects"],
            potential_concerns=ai_result["potential_concerns"],
            ai_summary=ai_result["ai_summary"],
            recommendation=ai_result["recommendation"],
            analyzed_at=datetime.now(timezone.utc)
        )
        db.add(score_record)
    else:
        score_record.overall_score = ai_result["overall_score"]
        score_record.skills_match_score = ai_result["skills_match_score"]
        score_record.experience_match_score = ai_result["experience_match_score"]
        score_record.education_match_score = ai_result["education_match_score"]
        score_record.project_match_score = ai_result["project_match_score"]
        score_record.certification_match_score = ai_result["certification_match_score"]
        score_record.matching_skills = ai_result["matching_skills"]
        score_record.missing_skills = ai_result["missing_skills"]
        score_record.relevant_experience = ai_result["relevant_experience"]
        score_record.relevant_projects = ai_result["relevant_projects"]
        score_record.potential_concerns = ai_result["potential_concerns"]
        score_record.ai_summary = ai_result["ai_summary"]
        score_record.recommendation = ai_result["recommendation"]
        score_record.analyzed_at = datetime.now(timezone.utc)

    # If application is in APPLIED status, advance it to RESUME_SCREENING
    if app.status == ApplicationStatus.APPLIED:
        app.status = ApplicationStatus.RESUME_SCREENING
        app.current_stage = "Resume Screening"

    db.commit()
    db.refresh(score_record)

    log_audit(db, current_user.id, "AI_SCREENING", "APPLICATION", app.id, f"AI Score computed: {score_record.overall_score}%")

    return score_record

@router.get("/{application_id}", response_model=CandidateScoreResponse)
def get_screening_result(
    application_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    score = db.query(CandidateScore).filter(CandidateScore.application_id == application_id).first()
    if not score:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Screening result not generated yet")

    return score

@router.get("/jobs/{job_id}/ranking", response_model=List[CandidateRankItem])
def get_candidate_ranking_for_job(
    job_id: int,
    sort_by: str = Query("ai_score", regex="^(ai_score|experience|date)$"),
    status_filter: Optional[ApplicationStatus] = Query(None, alias="status"),
    min_score: Optional[float] = Query(None),
    min_experience: Optional[float] = Query(None),
    skill_filter: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([UserRole.RECRUITER, UserRole.ADMIN]))
):
    job = db.query(Job).filter(Job.id == job_id).first()
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found")

    query = db.query(Application).filter(Application.job_id == job_id)
    if status_filter:
        query = query.filter(Application.status == status_filter)

    applications = query.all()

    items: List[CandidateRankItem] = []
    for app in applications:
        cand = app.candidate
        score = app.screening_score
        prof = cand.candidate_profile if cand else None

        cand_exp = prof.total_experience_years if prof else 0.0
        if app.resume and app.resume.parsed_experience_years:
            cand_exp = app.resume.parsed_experience_years

        ovr_score = score.overall_score if score else 0.0

        # Filter by min_score
        if min_score is not None and ovr_score < min_score:
            continue

        # Filter by min_experience
        if min_experience is not None and cand_exp < min_experience:
            continue

        match_skills = []
        miss_skills = []
        if score and score.matching_skills:
            try:
                match_skills = json.loads(score.matching_skills)
            except Exception:
                match_skills = []
        if score and score.missing_skills:
            try:
                miss_skills = json.loads(score.missing_skills)
            except Exception:
                miss_skills = []

        # Filter by skill keyword
        if skill_filter:
            skill_clean = skill_filter.lower()
            all_skills = [s.lower() for s in match_skills]
            if cand and prof and prof.skills_text:
                all_skills.extend([s.lower().strip() for s in prof.skills_text.split(",")])
            if not any(skill_clean in s for s in all_skills):
                continue

        item = CandidateRankItem(
            application_id=app.id,
            candidate_id=app.candidate_id,
            candidate_name=cand.full_name if cand else "Candidate",
            candidate_email=cand.email if cand else "",
            headline=prof.headline if prof else None,
            applied_at=app.created_at,
            status=app.status.value,
            is_shortlisted=app.is_shortlisted,
            total_experience_years=cand_exp,
            overall_score=ovr_score,
            skills_match_score=score.skills_match_score if score else 0.0,
            experience_match_score=score.experience_match_score if score else 0.0,
            education_match_score=score.education_match_score if score else 0.0,
            project_match_score=score.project_match_score if score else 0.0,
            certification_match_score=score.certification_match_score if score else 0.0,
            matching_skills=match_skills,
            missing_skills=miss_skills,
            ai_summary=score.ai_summary if score else "Pending evaluation",
            recommendation=score.recommendation if score else "PENDING",
            rank=1
        )
        items.append(item)

    # Sort
    if sort_by == "ai_score":
        items.sort(key=lambda x: x.overall_score, reverse=True)
    elif sort_by == "experience":
        items.sort(key=lambda x: x.total_experience_years, reverse=True)
    elif sort_by == "date":
        items.sort(key=lambda x: x.applied_at, reverse=True)

    # Assign sequential ranks
    for idx, item in enumerate(items, 1):
        item.rank = idx

    return items
