from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database.session import get_db
from app.models.user import User, RecruiterProfile, CandidateProfile, UserRole
from app.schemas.auth import UserRegister, UserLogin, Token
from app.schemas.user import UserProfileResponse
from app.core.security import verify_password, get_password_hash, create_access_token
from app.api.deps import get_current_user, log_audit

router = APIRouter(prefix="/auth", tags=["Authentication"])

@router.post("/register", response_model=Token, status_code=status.HTTP_201_CREATED)
def register(user_in: UserRegister, db: Session = Depends(get_db)):
    # Check if user already exists
    existing = db.query(User).filter(User.email == user_in.email.lower()).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="A user with this email address already exists.",
        )

    # Create new user
    user = User(
        email=user_in.email.lower(),
        hashed_password=get_password_hash(user_in.password),
        full_name=user_in.full_name,
        phone=user_in.phone,
        role=user_in.role,
        is_active=True,
        is_verified=True,
    )
    db.add(user)
    db.flush()

    # Create corresponding profile
    if user.role == UserRole.RECRUITER:
        recruiter_profile = RecruiterProfile(
            user_id=user.id,
            company_name=user_in.company_name or "Enterprise Hiring Partner",
            company_website=user_in.company_website,
            industry=user_in.industry or "Technology",
            designatory_title=user_in.designatory_title or "Talent Acquisition Specialist",
        )
        db.add(recruiter_profile)
    elif user.role == UserRole.CANDIDATE:
        candidate_profile = CandidateProfile(
            user_id=user.id,
            headline=user_in.headline or "Passionate Professional",
            location=user_in.location,
            total_experience_years=user_in.total_experience_years or 0.0,
        )
        db.add(candidate_profile)

    db.commit()
    db.refresh(user)

    log_audit(db, user.id, "REGISTER", "USER", user.id, f"Registered as {user.role.value}")

    token = create_access_token(subject=user.id, role=user.role.value)
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": user
    }

@router.post("/login", response_model=Token)
def login(login_in: UserLogin, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == login_in.email.lower()).first()
    if not user or not verify_password(login_in.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Account is inactive. Please contact support.",
        )

    log_audit(db, user.id, "LOGIN", "USER", user.id, "User logged in")

    token = create_access_token(subject=user.id, role=user.role.value)
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": user
    }

@router.get("/me", response_model=UserProfileResponse)
def get_current_user_profile(current_user: User = Depends(get_current_user)):
    return current_user

@router.post("/logout")
def logout(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    log_audit(db, current_user.id, "LOGOUT", "USER", current_user.id, "User logged out")
    return {"message": "Logged out successfully"}
