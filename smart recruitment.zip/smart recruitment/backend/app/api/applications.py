import json
from typing import List, Optional
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from sqlalchemy import desc
from app.database.session import get_db
from app.models.application import Application, ApplicationStatus, ApplicationStatusHistory
from app.models.job import Job, JobStatus
from app.models.resume import Resume
from app.models.user import User, UserRole
from app.models.notification import Notification
from app.models.screening import CandidateScore
from app.schemas.application import (
    ApplicationCreate,
    ApplicationResponse,
    ApplicationDetailResponse,
    ApplicationStatusUpdate,
    StatusHistoryItem
)
from app.schemas.screening import CandidateScoreResponse
from app.services.ai.resume_analyzer import ResumeAnalyzer
from app.api.deps import get_current_user, require_role, log_audit

router = APIRouter(prefix="/applications", tags=["Applications"])

def build_app_response(app: Application, db: Session) -> ApplicationResponse:
    job = app.job
    candidate = app.candidate
    score_model = app.screening_score

    score_resp = None
    if score_model:
        score_resp = CandidateScoreResponse(
            id=score_model.id,
            application_id=score_model.application_id,
            candidate_id=score_model.candidate_id,
            job_id=score_model.job_id,
            overall_score=score_model.overall_score,
            skills_match_score=score_model.skills_match_score,
            experience_match_score=score_model.experience_match_score,
            education_match_score=score_model.education_match_score,
            project_match_score=score_model.project_match_score,
            certification_match_score=score_model.certification_match_score,
            matching_skills=score_model.matching_skills or "[]",
            missing_skills=score_model.missing_skills or "[]",
            relevant_experience=score_model.relevant_experience,
            relevant_projects=score_model.relevant_projects,
            potential_concerns=score_model.potential_concerns,
            ai_summary=score_model.ai_summary,
            recommendation=score_model.recommendation,
            analyzed_at=score_model.analyzed_at
        )

    cand_profile = candidate.candidate_profile if candidate else None
    exp = cand_profile.total_experience_years if cand_profile else 0.0
    if app.resume and app.resume.parsed_experience_years:
        exp = app.resume.parsed_experience_years

    return ApplicationResponse(
        id=app.id,
        job_id=app.job_id,
        candidate_id=app.candidate_id,
        resume_id=app.resume_id,
        cover_letter=app.cover_letter,
        status=app.status,
        current_stage=app.current_stage,
        recruiter_notes=app.recruiter_notes,
        is_shortlisted=app.is_shortlisted,
        created_at=app.created_at,
        updated_at=app.updated_at,
        job_title=job.title if job else "Unknown Position",
        job_department=job.department if job else "",
        candidate_name=candidate.full_name if candidate else "Anonymous",
        candidate_email=candidate.email if candidate else "",
        candidate_phone=candidate.phone if candidate else "",
        total_experience_years=exp,
        overall_match_score=score_model.overall_score if score_model else None,
        screening_score=score_resp
    )

@router.post("", response_model=ApplicationResponse, status_code=status.HTTP_201_CREATED)
def apply_for_job(
    app_in: ApplicationCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([UserRole.CANDIDATE, UserRole.ADMIN]))
):
    job = db.query(Job).filter(Job.id == app_in.job_id).first()
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found")

    if job.status != JobStatus.PUBLISHED:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="This position is not currently accepting applications")

    # Check for duplicate active application
    existing = db.query(Application).filter(
        Application.job_id == app_in.job_id,
        Application.candidate_id == current_user.id
    ).first()
    if existing:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="You have already applied for this position")

    # Determine resume
    resume_id = app_in.resume_id
    if not resume_id:
        # Find user's primary resume
        primary_resume = db.query(Resume).filter(
            Resume.candidate_id == current_user.id,
            Resume.is_primary == True
        ).first()
        if not primary_resume:
            primary_resume = db.query(Resume).filter(Resume.candidate_id == current_user.id).order_by(Resume.created_at.desc()).first()
        if primary_resume:
            resume_id = primary_resume.id

    application = Application(
        job_id=app_in.job_id,
        candidate_id=current_user.id,
        resume_id=resume_id,
        cover_letter=app_in.cover_letter,
        status=ApplicationStatus.APPLIED,
        current_stage="Application Submitted",
    )
    db.add(application)
    db.flush()

    # Add initial history entry
    history_entry = ApplicationStatusHistory(
        application_id=application.id,
        previous_status=None,
        new_status=ApplicationStatus.APPLIED.value,
        changed_by_user_id=current_user.id,
        notes="Application submitted by candidate"
    )
    db.add(history_entry)

    # Perform automated AI Screening Analysis if resume exists
    if resume_id:
        resume = db.query(Resume).filter(Resume.id == resume_id).first()
        if resume:
            candidate_dict = {
                "name": resume.parsed_name or current_user.full_name,
                "skills": [s.strip() for s in (resume.parsed_skills or "").split(",") if s.strip()],
                "experience_years": resume.parsed_experience_years or 0.0,
                "education": [e.strip() for e in (resume.parsed_education or "").split(",") if e.strip()],
                "certifications": [c.strip() for c in (resume.parsed_certifications or "").split(",") if c.strip()],
                "projects": [p.strip() for p in (resume.parsed_projects or "").split(";") if p.strip()]
            }
            job_dict = {
                "title": job.title,
                "required_skills": job.required_skills,
                "preferred_skills": job.preferred_skills,
                "experience_required": job.experience_required,
                "education_requirements": job.education_requirements,
                "certifications": job.certifications,
                "description": job.description
            }
            ai_analysis = ResumeAnalyzer.analyze(candidate_dict, job_dict)

            score_record = CandidateScore(
                application_id=application.id,
                job_id=job.id,
                candidate_id=current_user.id,
                overall_score=ai_analysis["overall_score"],
                skills_match_score=ai_analysis["skills_match_score"],
                experience_match_score=ai_analysis["experience_match_score"],
                education_match_score=ai_analysis["education_match_score"],
                project_match_score=ai_analysis["project_match_score"],
                certification_match_score=ai_analysis["certification_match_score"],
                matching_skills=ai_analysis["matching_skills"],
                missing_skills=ai_analysis["missing_skills"],
                relevant_experience=ai_analysis["relevant_experience"],
                relevant_projects=ai_analysis["relevant_projects"],
                potential_concerns=ai_analysis["potential_concerns"],
                ai_summary=ai_analysis["ai_summary"],
                recommendation=ai_analysis["recommendation"]
            )
            db.add(score_record)

    # Add notification for recruiter
    if job.recruiter_id:
        notif = Notification(
            user_id=job.recruiter_id,
            title="New Application Received",
            message=f"{current_user.full_name} applied for {job.title}",
            notification_type="INFO",
            link=f"/recruiter/applications"
        )
        db.add(notif)

    db.commit()
    db.refresh(application)

    log_audit(db, current_user.id, "APPLY_JOB", "APPLICATION", application.id, f"Applied for job {job.title}")

    return build_app_response(application, db)

@router.get("", response_model=List[ApplicationResponse])
def get_applications(
    job_id: Optional[int] = Query(None),
    status_filter: Optional[ApplicationStatus] = Query(None, alias="status"),
    is_shortlisted: Optional[bool] = Query(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    query = db.query(Application)

    if current_user.role == UserRole.CANDIDATE:
        # Candidate only sees their own applications
        query = query.filter(Application.candidate_id == current_user.id)
    elif current_user.role == UserRole.RECRUITER:
        # Recruiter sees applications for their posted jobs
        query = query.join(Job).filter(Job.recruiter_id == current_user.id)

    if job_id:
        query = query.filter(Application.job_id == job_id)
    if status_filter:
        query = query.filter(Application.status == status_filter)
    if is_shortlisted is not None:
        query = query.filter(Application.is_shortlisted == is_shortlisted)

    applications = query.order_by(desc(Application.created_at)).all()
    return [build_app_response(a, db) for a in applications]

@router.get("/{id}", response_model=ApplicationDetailResponse)
def get_application_detail(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    app = db.query(Application).filter(Application.id == id).first()
    if not app:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Application not found")

    # Authorization
    if current_user.role == UserRole.CANDIDATE and app.candidate_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")
    if current_user.role == UserRole.RECRUITER and app.job.recruiter_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    base_resp = build_app_response(app, db)

    # Build history
    history_records = db.query(ApplicationStatusHistory).filter(
        ApplicationStatusHistory.application_id == app.id
    ).order_by(ApplicationStatusHistory.created_at.asc()).all()

    history_items = [
        StatusHistoryItem(
            id=h.id,
            previous_status=h.previous_status,
            new_status=h.new_status,
            notes=h.notes,
            timestamp=h.created_at
        )
        for h in history_records
    ]

    return ApplicationDetailResponse(
        **base_resp.dict(),
        history=history_items
    )

@router.put("/{id}/status", response_model=ApplicationResponse)
def update_application_status(
    id: int,
    status_update: ApplicationStatusUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([UserRole.RECRUITER, UserRole.ADMIN]))
):
    app = db.query(Application).filter(Application.id == id).first()
    if not app:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Application not found")

    if current_user.role != UserRole.ADMIN and app.job.recruiter_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    previous_status = app.status.value
    app.status = status_update.status
    app.current_stage = status_update.status.value.replace("_", " ").title()

    if status_update.notes:
        app.recruiter_notes = status_update.notes

    if status_update.is_shortlisted is not None:
        app.is_shortlisted = status_update.is_shortlisted
    elif status_update.status == ApplicationStatus.SHORTLISTED:
        app.is_shortlisted = True

    app.updated_at = datetime.now(timezone.utc)

    # Record history
    history = ApplicationStatusHistory(
        application_id=app.id,
        previous_status=previous_status,
        new_status=status_update.status.value,
        changed_by_user_id=current_user.id,
        notes=status_update.notes or f"Status transitioned to {status_update.status.value}"
    )
    db.add(history)

    # Notify candidate
    stage_friendly = status_update.status.value.replace("_", " ").title()
    cand_notif = Notification(
        user_id=app.candidate_id,
        title=f"Application Update: {app.job.title}",
        message=f"Your application status has been updated to: {stage_friendly}",
        notification_type="STATUS_UPDATE",
        link=f"/candidate/applications"
    )
    db.add(cand_notif)

    db.commit()
    db.refresh(app)

    log_audit(db, current_user.id, "UPDATE_APPLICATION_STATUS", "APPLICATION", app.id, f"Changed status to {status_update.status.value}")

    return build_app_response(app, db)

@router.post("/{id}/shortlist", response_model=ApplicationResponse)
def toggle_shortlist(
    id: int,
    shortlist: bool = Query(True),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([UserRole.RECRUITER, UserRole.ADMIN]))
):
    app = db.query(Application).filter(Application.id == id).first()
    if not app:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Application not found")

    if current_user.role != UserRole.ADMIN and app.job.recruiter_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    app.is_shortlisted = shortlist
    if shortlist and app.status == ApplicationStatus.APPLIED:
        app.status = ApplicationStatus.SHORTLISTED
        app.current_stage = "Shortlisted"

    db.commit()
    db.refresh(app)

    log_audit(db, current_user.id, "SHORTLIST_CANDIDATE", "APPLICATION", app.id, f"Shortlist status: {shortlist}")
    return build_app_response(app, db)

@router.post("/{id}/withdraw", response_model=ApplicationResponse)
def withdraw_application(
    id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([UserRole.CANDIDATE]))
):
    app = db.query(Application).filter(Application.id == id, Application.candidate_id == current_user.id).first()
    if not app:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Application not found")

    app.status = ApplicationStatus.WITHDRAWN
    app.current_stage = "Withdrawn by Candidate"
    app.updated_at = datetime.now(timezone.utc)

    history = ApplicationStatusHistory(
        application_id=app.id,
        previous_status=app.status.value,
        new_status=ApplicationStatus.WITHDRAWN.value,
        changed_by_user_id=current_user.id,
        notes="Candidate withdrew application"
    )
    db.add(history)
    db.commit()
    db.refresh(app)

    log_audit(db, current_user.id, "WITHDRAW_APPLICATION", "APPLICATION", app.id, "Candidate withdrew application")
    return build_app_response(app, db)
