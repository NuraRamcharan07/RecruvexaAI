from typing import List, Optional
from datetime import datetime
from pydantic import BaseModel
from app.models.user import UserRole

class AdminSystemOverview(BaseModel):
    total_users: int
    total_recruiters: int
    total_candidates: int
    total_jobs: int
    total_applications: int
    active_interviews: int
    system_health: str = "HEALTHY"
    ai_status: str = "ACTIVE"
    storage_used_mb: float = 12.4

class AdminUserItem(BaseModel):
    id: int
    email: str
    full_name: str
    role: UserRole
    is_active: bool
    is_verified: bool
    created_at: datetime
    applications_count: Optional[int] = 0
    jobs_count: Optional[int] = 0

    class Config:
        from_attributes = True

class AISettingsConfig(BaseModel):
    provider: str = "local"
    skills_weight: float = 0.35
    experience_weight: float = 0.25
    education_weight: float = 0.15
    project_weight: float = 0.15
    certification_weight: float = 0.10
    auto_tagging_enabled: bool = True
    minimum_shortlist_threshold: float = 75.0
