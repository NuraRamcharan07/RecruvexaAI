from typing import Optional, List
from datetime import datetime
from pydantic import BaseModel, Field
from app.models.job import EmploymentType, JobStatus

class JobBase(BaseModel):
    title: str = Field(..., min_length=2, max_length=255)
    department: str = Field(..., min_length=2, max_length=100)
    location: str = Field(..., min_length=2, max_length=255)
    employment_type: EmploymentType = EmploymentType.FULL_TIME
    experience_required: float = Field(..., ge=0.0)
    min_salary: Optional[int] = None
    max_salary: Optional[int] = None
    salary_currency: Optional[str] = "USD"
    description: str = Field(..., min_length=10)
    responsibilities: Optional[str] = None
    required_skills: str = Field(..., min_length=2)  # Comma-separated or JSON list
    preferred_skills: Optional[str] = None
    education_requirements: Optional[str] = None
    certifications: Optional[str] = None
    deadline: Optional[datetime] = None

class JobCreate(JobBase):
    status: JobStatus = JobStatus.PUBLISHED

class JobUpdate(BaseModel):
    title: Optional[str] = None
    department: Optional[str] = None
    location: Optional[str] = None
    employment_type: Optional[EmploymentType] = None
    experience_required: Optional[float] = None
    min_salary: Optional[int] = None
    max_salary: Optional[int] = None
    salary_currency: Optional[str] = None
    description: Optional[str] = None
    responsibilities: Optional[str] = None
    required_skills: Optional[str] = None
    preferred_skills: Optional[str] = None
    education_requirements: Optional[str] = None
    certifications: Optional[str] = None
    deadline: Optional[datetime] = None
    status: Optional[JobStatus] = None

class JobRecruiterInfo(BaseModel):
    id: int
    full_name: str
    email: str
    company_name: Optional[str] = "TechCorp Global"

class JobResponse(JobBase):
    id: int
    recruiter_id: int
    status: JobStatus
    views_count: int
    created_at: datetime
    updated_at: datetime
    applications_count: Optional[int] = 0
    recruiter: Optional[JobRecruiterInfo] = None

    class Config:
        from_attributes = True

class JobListResponse(BaseModel):
    items: List[JobResponse]
    total: int
    page: int
    page_size: int
