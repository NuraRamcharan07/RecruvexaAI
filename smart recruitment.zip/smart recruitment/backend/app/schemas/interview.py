from typing import Optional
from datetime import date, time, datetime
from pydantic import BaseModel, Field
from app.models.interview import InterviewType, InterviewStatus

class InterviewCreate(BaseModel):
    application_id: int
    interview_type: InterviewType = InterviewType.TECHNICAL
    title: str = Field(..., min_length=3, max_length=255)
    scheduled_date: date
    scheduled_time: time
    duration_minutes: int = Field(default=45, ge=15, le=180)
    interviewer_name: str = Field(..., min_length=2, max_length=255)
    interviewer_email: Optional[str] = None
    meeting_link: Optional[str] = None
    location: Optional[str] = None
    notes: Optional[str] = None

class InterviewUpdate(BaseModel):
    title: Optional[str] = None
    interview_type: Optional[InterviewType] = None
    scheduled_date: Optional[date] = None
    scheduled_time: Optional[time] = None
    duration_minutes: Optional[int] = None
    interviewer_name: Optional[str] = None
    interviewer_email: Optional[str] = None
    meeting_link: Optional[str] = None
    location: Optional[str] = None
    notes: Optional[str] = None
    status: Optional[InterviewStatus] = None
    feedback: Optional[str] = None
    rating: Optional[float] = None

class InterviewResponse(BaseModel):
    id: int
    application_id: int
    job_id: int
    candidate_id: int
    recruiter_id: int
    title: str
    interview_type: InterviewType
    scheduled_date: date
    scheduled_time: time
    duration_minutes: int
    interviewer_name: str
    interviewer_email: Optional[str] = None
    meeting_link: Optional[str] = None
    location: Optional[str] = None
    notes: Optional[str] = None
    status: InterviewStatus
    feedback: Optional[str] = None
    rating: Optional[float] = None
    created_at: datetime
    
    # Associated display items
    candidate_name: Optional[str] = None
    candidate_email: Optional[str] = None
    job_title: Optional[str] = None
    company_name: Optional[str] = None

    class Config:
        from_attributes = True
