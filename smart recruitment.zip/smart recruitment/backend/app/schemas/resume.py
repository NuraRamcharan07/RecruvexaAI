from typing import Optional, List, Any
from datetime import datetime
from pydantic import BaseModel

class ResumeParsedData(BaseModel):
    name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    skills: List[str] = []
    experience_years: float = 0.0
    education: List[str] = []
    certifications: List[str] = []
    projects: List[str] = []
    work_history: List[dict] = []

class ResumeResponse(BaseModel):
    id: int
    candidate_id: int
    filename: str
    original_name: str
    file_size: int
    content_type: str
    parsed_name: Optional[str] = None
    parsed_email: Optional[str] = None
    parsed_phone: Optional[str] = None
    parsed_skills: Optional[str] = None
    parsed_experience_years: float = 0.0
    parsed_education: Optional[str] = None
    parsed_certifications: Optional[str] = None
    parsed_projects: Optional[str] = None
    is_primary: bool
    created_at: datetime

    class Config:
        from_attributes = True
