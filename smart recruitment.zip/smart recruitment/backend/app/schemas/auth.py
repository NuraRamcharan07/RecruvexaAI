from typing import Optional
from pydantic import BaseModel, EmailStr, Field
from app.models.user import UserRole

class UserRegister(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=6)
    full_name: str = Field(..., min_length=2)
    role: UserRole = UserRole.CANDIDATE
    phone: Optional[str] = None
    # Recruiter specific fields
    company_name: Optional[str] = None
    company_website: Optional[str] = None
    industry: Optional[str] = None
    designatory_title: Optional[str] = None
    # Candidate specific fields
    headline: Optional[str] = None
    location: Optional[str] = None
    total_experience_years: Optional[float] = 0.0

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserResponse(BaseModel):
    id: int
    email: EmailStr
    full_name: str
    role: UserRole
    phone: Optional[str] = None
    is_active: bool
    is_verified: bool

    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse
