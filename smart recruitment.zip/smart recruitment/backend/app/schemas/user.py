from typing import Optional
from datetime import datetime
from pydantic import BaseModel, EmailStr
from app.models.user import UserRole

class RecruiterProfileUpdate(BaseModel):
    company_name: Optional[str] = None
    company_website: Optional[str] = None
    company_size: Optional[str] = None
    industry: Optional[str] = None
    designatory_title: Optional[str] = None
    company_logo_url: Optional[str] = None

class RecruiterProfileResponse(BaseModel):
    id: int
    company_name: str
    company_website: Optional[str] = None
    company_size: Optional[str] = None
    industry: Optional[str] = None
    designatory_title: Optional[str] = None
    company_logo_url: Optional[str] = None

    class Config:
        from_attributes = True

class CandidateProfileUpdate(BaseModel):
    headline: Optional[str] = None
    summary: Optional[str] = None
    location: Optional[str] = None
    total_experience_years: Optional[float] = None
    education_level: Optional[str] = None
    current_company: Optional[str] = None
    current_title: Optional[str] = None
    skills_text: Optional[str] = None
    github_url: Optional[str] = None
    linkedin_url: Optional[str] = None
    portfolio_url: Optional[str] = None
    is_open_to_work: Optional[bool] = None

class CandidateProfileResponse(BaseModel):
    id: int
    headline: Optional[str] = None
    summary: Optional[str] = None
    location: Optional[str] = None
    total_experience_years: float = 0.0
    education_level: Optional[str] = None
    current_company: Optional[str] = None
    current_title: Optional[str] = None
    skills_text: Optional[str] = None
    github_url: Optional[str] = None
    linkedin_url: Optional[str] = None
    portfolio_url: Optional[str] = None
    is_open_to_work: bool = True

    class Config:
        from_attributes = True

class UserProfileResponse(BaseModel):
    id: int
    email: EmailStr
    full_name: str
    phone: Optional[str] = None
    role: UserRole
    is_active: bool
    is_verified: bool
    created_at: datetime
    recruiter_profile: Optional[RecruiterProfileResponse] = None
    candidate_profile: Optional[CandidateProfileResponse] = None

    class Config:
        from_attributes = True
