from typing import List, Dict, Any, Optional
from pydantic import BaseModel

class PipelineStageCount(BaseModel):
    stage: str
    count: int
    percentage: float

class SkillDemandItem(BaseModel):
    skill: str
    demand_count: int

class TimelineDataPoint(BaseModel):
    date: str
    applications: int
    interviews: int

class JobPerformanceItem(BaseModel):
    job_id: int
    title: str
    department: str
    applications_count: int
    shortlisted_count: int
    interviews_count: int
    selected_count: int
    avg_ai_score: float

class DashboardAnalyticsResponse(BaseModel):
    total_jobs: int
    active_jobs: int
    total_applications: int
    shortlisted_candidates: int
    scheduled_interviews: int
    selected_candidates: int
    
    # Rates & Metrics
    screening_success_rate: float
    shortlisting_rate: float
    interview_rate: float
    selection_rate: float
    rejection_rate: float
    avg_time_to_shortlist_days: float
    avg_time_to_hire_days: float
    
    # Visualizations
    hiring_funnel: List[PipelineStageCount]
    applications_timeline: List[TimelineDataPoint]
    top_demanded_skills: List[SkillDemandItem]
    job_performance: List[JobPerformanceItem]
