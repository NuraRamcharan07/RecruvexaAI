from typing import Optional, List
from datetime import datetime
from pydantic import BaseModel
from app.models.application import ApplicationStatus
from app.schemas.screening import CandidateScoreResponse

class ApplicationCreate(BaseModel):
    job_id: int
    resume_id: Optional[int] = None
    cover_letter: Optional[str] = None

class ApplicationStatusUpdate(BaseModel):
    status: ApplicationStatus
    notes: Optional[str] = None
    is_shortlisted: Optional[bool] = None

class StatusHistoryItem(BaseModel):
    id: int
    previous_status: Optional[str] = None
    new_status: str
    notes: Optional[str] = None
    timestamp: datetime

    class Config:
        from_attributes = True

class ApplicationResponse(BaseModel):
    id: int
    job_id: int
    candidate_id: int
    resume_id: Optional[int] = None
    cover_letter: Optional[str] = None
    status: ApplicationStatus
    current_stage: str
    recruiter_notes: Optional[str] = None
    is_shortlisted: bool
    created_at: datetime
    updated_at: datetime
    
    # Nested Info
    job_title: Optional[str] = None
    job_department: Optional[str] = None
    candidate_name: Optional[str] = None
    candidate_email: Optional[str] = None
    candidate_phone: Optional[str] = None
    total_experience_years: Optional[float] = 0.0
    overall_match_score: Optional[float] = None
    screening_score: Optional[CandidateScoreResponse] = None

    class Config:
        from_attributes = True

class ApplicationDetailResponse(ApplicationResponse):
    history: List[StatusHistoryItem] = []
