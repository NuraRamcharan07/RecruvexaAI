from typing import Optional, List
from datetime import datetime
from pydantic import BaseModel

class CandidateScoreResponse(BaseModel):
    id: int
    application_id: int
    candidate_id: int
    job_id: int
    overall_score: float
    skills_match_score: float
    experience_match_score: float
    education_match_score: float
    project_match_score: float
    certification_match_score: float
    matching_skills: Optional[str] = "[]"
    missing_skills: Optional[str] = "[]"
    relevant_experience: Optional[str] = None
    relevant_projects: Optional[str] = None
    potential_concerns: Optional[str] = None
    ai_summary: Optional[str] = None
    recommendation: Optional[str] = "PROCEED_TO_REVIEW"
    analyzed_at: datetime

    class Config:
        from_attributes = True

class CandidateRankItem(BaseModel):
    application_id: int
    candidate_id: int
    candidate_name: str
    candidate_email: str
    headline: Optional[str] = None
    applied_at: datetime
    status: str
    is_shortlisted: bool
    total_experience_years: float = 0.0
    overall_score: float = 0.0
    skills_match_score: float = 0.0
    experience_match_score: float = 0.0
    education_match_score: float = 0.0
    project_match_score: float = 0.0
    certification_match_score: float = 0.0
    matching_skills: List[str] = []
    missing_skills: List[str] = []
    ai_summary: Optional[str] = None
    recommendation: Optional[str] = None
    rank: int = 1
