from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Text, Float, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from app.database.session import Base

class CandidateScore(Base):
    __tablename__ = "candidate_scores"

    id = Column(Integer, primary_key=True, index=True)
    application_id = Column(Integer, ForeignKey("applications.id", ondelete="CASCADE"), unique=True, nullable=False)
    job_id = Column(Integer, ForeignKey("jobs.id", ondelete="CASCADE"), nullable=False)
    candidate_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    
    # Overall score (0-100)
    overall_score = Column(Float, nullable=False, default=0.0)
    
    # Score Breakdown (0-100)
    skills_match_score = Column(Float, nullable=False, default=0.0)
    experience_match_score = Column(Float, nullable=False, default=0.0)
    education_match_score = Column(Float, nullable=False, default=0.0)
    project_match_score = Column(Float, nullable=False, default=0.0)
    certification_match_score = Column(Float, nullable=False, default=0.0)
    
    # Qualitative & Insight Fields (stored as structured JSON strings)
    matching_skills = Column(Text, nullable=True)     # JSON array: ["React", "Python", "Docker"]
    missing_skills = Column(Text, nullable=True)      # JSON array: ["Kubernetes", "GraphQL"]
    relevant_experience = Column(Text, nullable=True) # Summary of relevant experience years and alignment
    relevant_projects = Column(Text, nullable=True)   # Relevant project highlights
    potential_concerns = Column(Text, nullable=True)  # Highlighted areas for recruiter attention
    ai_summary = Column(Text, nullable=True)          # Executive AI summary
    recommendation = Column(String(50), default="PROCEED_TO_REVIEW") # STRONG_MATCH, GOOD_MATCH, PARTIAL_MATCH, LOW_MATCH
    
    analyzed_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

    # Relationships
    application = relationship("Application", back_populates="screening_score")
