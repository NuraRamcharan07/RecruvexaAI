from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Text, Float, DateTime, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from app.database.session import Base

class Resume(Base):
    __tablename__ = "resumes"

    id = Column(Integer, primary_key=True, index=True)
    candidate_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    filename = Column(String(255), nullable=False)
    original_name = Column(String(255), nullable=False)
    file_path = Column(String(500), nullable=False)
    file_size = Column(Integer, nullable=False)  # in bytes
    content_type = Column(String(100), nullable=False)  # application/pdf, etc.
    raw_text = Column(Text, nullable=True)
    
    # AI Extracted Data
    parsed_name = Column(String(255), nullable=True)
    parsed_email = Column(String(255), nullable=True)
    parsed_phone = Column(String(50), nullable=True)
    parsed_skills = Column(Text, nullable=True)  # JSON or comma-separated
    parsed_experience_years = Column(Float, default=0.0)
    parsed_education = Column(Text, nullable=True)
    parsed_certifications = Column(Text, nullable=True)
    parsed_projects = Column(Text, nullable=True)
    parsed_work_history = Column(Text, nullable=True)
    
    is_primary = Column(Boolean, default=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    # Relationships
    candidate = relationship("User", back_populates="resumes")
    applications = relationship("Application", back_populates="resume")
