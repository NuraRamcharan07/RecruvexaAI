import uvicorn
import os

if __name__ == "__main__":
    # Ensure current dir is in PYTHONPATH
    import sys
    sys.path.insert(0, os.path.abspath("."))
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
